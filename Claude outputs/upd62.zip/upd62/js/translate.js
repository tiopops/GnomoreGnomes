/* Gnomore Gnomes — traducción en tiempo de ejecución ES -> EN.
   Regla de oro: un archivo por mecánica. Este archivo SOLO sabe traducir el
   texto que el juego pinta en pantalla cuando el idioma es inglés:
     - Diccionario ES -> EN (EN_DICT). Las claves con {0}, {1}... son plantillas
       (números, nombres...) y se resuelven como patrones.
     - I18N.tr(texto): traduce un texto suelto (lo usa el tutorial antes de
       "escribirlo" letra a letra).
     - Un MutationObserver traduce el texto y los atributos (title, aria-label,
       placeholder, alt) que aparezcan o cambien en la página, y los DEVUELVE al
       original español al volver a ESPAÑOL.
   El español sigue siendo el idioma por defecto y la fuente de verdad: los
   archivos del juego no cambian, solo se traduce lo que sale por pantalla.
   Para añadir un texto nuevo: añade su línea "español": "inglés" abajo. */

const EN_DICT = {
"Golem de Espinas": "Thorn Golem",
"Se cura hasta su vida máxima de base y se envuelve de espinas hasta su próximo turno: mientras dure, cualquiera que lo golpee se hace 1 punto de daño a sí mismo. Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio.": "Heals to its base max health and wraps itself in thorns until its next turn: while active, anyone who hits it takes 1 damage themselves. Costs 1 action. One use: it recharges if you start your turn next to one of your own totems.",
"Visión Lejana": "Far Sight",
"Revela una zona cualquiera del mapa (3 casillas alrededor del punto elegido), esté donde esté. Tras activarla, el cursor se convierte en un ojo: el siguiente clic sobre el mapa la usa ahí mismo. Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio.": "Reveals any area of the map (3 tiles around the chosen point), wherever it is. Once activated, the cursor turns into an eye: your next click on the map uses it right there. Costs 1 action. One use: it recharges if you start your turn next to one of your own totems.",
"Hongo Trampa": "Trap Mushroom",
"Coloca una seta-trampa invisible para el enemigo en una casilla libre a hasta 4 casillas (la lanza). Si una unidad enemiga la pisa, explota: le quita 1 punto de vida y la deja inactiva hasta su siguiente turno. Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio.": "Places a mushroom trap, invisible to the enemy, on a free tile up to 4 tiles away (it throws it). If an enemy unit steps on it, it explodes: deals 1 damage and leaves the unit inactive until its next turn. Costs 1 action. One use: it recharges if you start your turn next to one of your own totems.",
"Voluntad Quebrada": "Broken Will",
"Toma el control total de una unidad enemiga adyacente durante el resto de este turno: se puede mover, atacar, coger/golpear/pasar su gnomo o incluso usar su propia habilidad, como si fuera propio. Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio.": "Takes total control of an adjacent enemy unit for the rest of this turn: it can move, attack, grab/hit/pass its gnome, or even use its own skill, as if it were yours. Costs 1 action. One use: it recharges if you start your turn next to one of your own totems.",
"Nudillos Rocosos": "Rocky Knuckles",
"Golpea y empuja 4 casillas en línea recta a un enemigo adyacente (se detiene en el primer obstáculo; si cae al agua sin ser anfibio, se ahoga); el golpeado queda agotado el siguiente turno. Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio. PuñoRroca es tan bruto que, si no tiene un aliado (cualquiera) justo al lado nada más empezar a andar, da tumbos al azar en vez de ir donde se le indica.": "Hits an adjacent enemy and shoves it 4 tiles in a straight line (stops at the first obstacle; if it falls into water without being amphibious, it drowns); the victim is exhausted next turn. Costs 1 action. One use: it recharges if you start your turn next to one of your own totems. PuñoRroca is so brutish that, if he has no ally (any ally) right next to him when he starts walking, he stumbles around at random instead of going where you tell him.",
"Resorte Goblin": "Goblin Spring",
"Agarra a una unidad adyacente (amiga o enemiga, incluso si lleva el gnomo cogido) y la lanza a cualquier casilla libre dentro de su propia área de movimiento, también al agua (quien no sea anfibio se ahoga). Gasta 1 acción. Un uso por partida: se recarga si empiezas el turno junto a un tótem propio.": "Grabs an adjacent unit (friend or foe, even if it's carrying the gnome) and hurls it to any free tile within its own movement range, including water (anyone not amphibious drowns). Costs 1 action. One use: it recharges if you start your turn next to one of your own totems.",
"¡ESPINAS!": "THORNS!",
"Elige un punto del mapa para revelarlo": "Pick a point on the map to reveal it",
"¡VISIÓN!": "VISION!",
"¡BOOM!": "BOOM!",
"Elige a qué rival controlar": "Pick which rival to control",
"¡CONTROLADO!": "CONTROLLED!",
"Elige a qué rival golpear": "Pick which rival to hit",
"Elige a quién lanzar": "Pick who to throw",
"Elige dónde lanzarlo": "Pick where to throw them",
"ARMERÍA": "ARMORY",
"No tienes suficientes recursos": "Not enough resources",
"Señuelo Explosivo": "Explosive Decoy",
"La comida favorita de los gnomos. Colócala junto a una de tus unidades: en dos turnos atraerá a un gnomo hambriento.": "The gnomes' favorite food. Place it next to one of your units: in two turns it will lure a hungry gnome.",
"Un brebaje revitalizante. Dáselo a una unidad aliada (pulsa sobre ella en el tablero) para restaurar toda su vida hasta su máximo de base, o úsalo sobre uno de tus tótems para repararlo por completo. No sirve con el Obelisco.": "A revitalizing brew. Give it to an allied unit (tap it on the board) to restore all its health up to its base max, or use it on one of your totems to fully repair it. It does not work on the Obelisk.",
"Un cepo goblin oxidado. Colócalo junto a una de tus unidades: el enemigo que caiga en su casilla o pase por encima pierde el turno, suelta cualquier gnomo que llevara encima y recibe 1 punto de daño.": "A rusty goblin bear trap. Place it next to one of your units: any enemy who lands on its tile or walks over it loses their turn, drops any gnome they were carrying and takes 1 damage.",
"Un cohete goblin casero. Elige a un rival a la vista: el misil vuela teledirigido hasta él y tira un dado de 6 al explotar: con 1-3 le hace 1 punto de daño, con 4-5 le hace 2 y con 6 le hace 3.": "A homemade goblin rocket. Pick a rival in sight: the missile flies guided straight to them and rolls a d6 on the explosion: 1-3 deals 1 damage, 4-5 deals 2, and 6 deals 3.",
"Un tótem tallado con un ojo tallado en su punta. Colócalo sobre una casilla libre: otorga visión permanente en un radio de 3 casillas. Tiene 1 punto de vida (cualquier golpe lo destruye) y, si se esconde dentro de un arbusto, se rompe en cuanto un rival entra en él.": "A carved totem with a carved eye on its tip. Place it on a free tile: grants permanent vision in a 3-tile radius. It has 1 health (any hit destroys it) and, if hidden inside a bush, it breaks the moment a rival steps into it.",
"Un muñeco de madera con forma de gnomo, cargado de pólvora. Colócalo sobre una casilla libre de terreno (nunca en un arbusto): tú lo ves como lo que es, pero el rival lo confunde con un gnomo suelto de verdad. En cuanto intente cogerlo... ¡PUM! Explota y le quita 2 puntos de vida.": "A wooden gnome-shaped doll stuffed with gunpowder. Place it on a free terrain tile (never in a bush): you see it for what it is, but the rival mistakes it for a real loose gnome. The moment they try to grab it... BOOM! It explodes and takes 2 health from them.",
"¡BEBEVIDA!": "BEBEVIDA!",
"¡REPARADO!": "REPAIRED!",
"¡MOCHILA LLENA!": "BACKPACK FULL!",
"Botas TrotaMontes": "TrotaMontes Boots",
"AcariciaGnomos": "GnomeCaresser",
"FeroGnomas": "GnomePheromones",
"GnomeVeo": "GnomeSight",
"Metal": "Metal",
"TotemVision": "VisionTotem",
"KataPum!": "KataBoom!",
"AtrapaPinreles": "FootTrap",
"BebeVida": "LifeSip",
"Setarcoiris": "Rainbowshroom",
"Pierde 1 de durabilidad cuando muere un aliado.": "Loses 1 durability whenever an ally dies.",
"Fragmento de roca": "Rock Fragment",
"Un trocito de roca caída del cielo. Púlsalo otra vez y apunta: tíraselo al volcán (+1), apaga con él una casilla de lava o quita un gnomo en llamas agarrado a una de tus unidades. No sirve contra el enemigo. Puedes lanzar todas las que quieras por turno.": "A little chunk of rock fallen from the sky. Tap it again and aim: toss it into the volcano (+1), put out a lava tile or remove a burning gnome clinging to one of your units. It can't be thrown at the enemy. Throw as many as you like each turn.",
"¡Habilidad recargada!": "Ability recharged!",
"Solo puedes lanzar una piedra por turno": "You can only throw one stone per turn",
"¡El volcán se enciende!": "The volcano lights up!",
"¡El volcán entra en erupción!": "The volcano erupts!",
"El volcán se apaga: vuelve a estar disponible": "The volcano dies down: it is available again",
"¡Llueven rocas!": "Rocks are falling!",
"¡Los tambores deciden!": "The drums decide!",
"¡Haces sonar los tambores con fuerza!": "You pound the drums hard!",
"¡El rival hace sonar los tambores!": "The rival sounds the drums!",
"Gnomeda de la Suerte": "Lucky Gnomeda",
"Oro puro de Rock'n'Troll, estampado contra un gnomo (sin querer). Te da +2 Puntos de Gloria por turno (cada moneda extra suma otros +2).": "Pure Rock'n'Troll gold, stamped onto a gnome (by accident). Gives you +2 Glory Points per turn (each extra coin adds another +2).",
"Gafas con nariz y bigote. Mirar al sol te quema la sombra; mirar gnomos, no. Te muestran un gnomo libre aunque haya niebla (cada par extra, uno más).": "Glasses with a nose and moustache. Staring at the sun burns your shadow; staring at gnomes doesn't. They show you a free gnome even through fog (each extra pair, one more).",
"Perfume de feromonas de barba gnoma. Los gnomos a 3 casillas o menos vienen solos hacia ti y no huyen (cada frasco extra suma 3 casillas).": "Perfume made of gnome-beard pheromones. Gnomes within 3 tiles walk to you on their own and don't run away (each extra bottle adds 3 tiles).",
"Un puño americano con pinchos dorados, para acariciar gnomos. Tus unidades hacen +1 de daño al pegarles (cada puño suma otro +1).": "Golden-spiked brass knuckles, for petting gnomes. Your units deal +1 damage when hitting them (each extra knuckle adds another +1).",
"Botas hechas para escalar montañas, no para mirar atrás. Todas tus unidades ganan +1 de Movimiento.": "Boots made for climbing mountains, not for looking back. All your units gain +1 Movement.",
"¡ATRAPADO!": "TRAPPED!",
"el mismo sonido de lanzamiento del gnomo algo mas agudo": "the same gnome-throw sound, a bit higher-pitched",
"¡EMBOSCADA!": "AMBUSH!",
"Ver el origen de tus puntos de gloria": "See where your glory points come from",
"Puntos de Gloria": "Glory Points",
"Vas a ganar esto al empezar tu próximo turno:": "You will gain this at the start of your next turn:",
"Próximo turno": "Next turn",
"Elige a quién pasarle el gnomo": "Pick who to pass the gnome to",
"Golpear al gnomo": "Hit the gnome",
"Pasar el gnomo": "Pass the gnome",
"Arrastra para cambiar el tamaño": "Drag to resize",
"right — · bottom — · tamaño (compartido) —": "right — · bottom — · size (shared) —",
"Arrastra el gnomo para moverlo (por unidad y por pose). Arrastra el puntito de su esquina para cambiar su tamaño — este es el MISMO para todas las unidades y las dos poses, se ajusta mirando a cualquiera.": "Drag the gnome to move it (per unit and per pose). Drag the little dot on its corner to resize it — this is the SAME for all units and both poses, so adjust it while looking at any one of them.",
"right {0} · bottom {1}% · tamaño (compartido) {2}px": "right {0} · bottom {1}% · size (shared) {2}px",
"Copia este texto a mano (Ctrl+C):": "Copy this text by hand (Ctrl+C):",
"[Gnomore Gnomes] Error al crear la partida:": "[Gnomore Gnomes] Error creating the match:",
"No se ha podido crear la partida": "Could not create the match",
"Población": "Population",
"Armería": "Armory",
"Vida del Obelisco": "Obelisk Health",
"Unidades reclutadas": "Units recruited",
"Pases de gnomo logrados": "Gnome passes completed",
"¡VICTORIA!": "VICTORY!",
"Se acabaron los {0} turnos y todo sigue exactamente igualado.": "The {0} turns are up and everything is still exactly tied.",
"Se acabaron los {0} turnos — gana quien más resistió.": "The {0} turns are up — whoever held out the longest wins.",
"Has destruido el Obelisco Ancestral rival.": "You destroyed the rival Ancestral Obelisk.",
"Tu Obelisco Ancestral ha sido destruido.": "Your Ancestral Obelisk has been destroyed.",
"TÚ": "YOU",
"VOLVER AL MENÚ": "BACK TO MENU",
"Aguante {0} · Movimiento {1} · Fuerza {2} · Agilidad {3} · Percepción {4}": "Toughness {0} · Movement {1} · Strength {2} · Agility {3} · Perception {4}",
"Reclutar cuesta {0} puntos de gloria.": "Recruiting costs {0} glory points.",
"Población al límite": "Population at limit",
"No tienes suficientes Puntos de Gloria": "Not enough Glory Points",
"Elige una casilla para colocar tu nueva unidad": "Pick a tile to place your new unit",
"Próximamente": "Coming soon",
"¡ALERTA! ¡Se acerca una plaga Gnoma!": "ALERT! A Gnome plague is coming!",
"Los gnomos se están escondiendo…": "The gnomes are hiding…",
"Roca": "Rock",
"Pino": "Pine",
"Mena de Hierro": "Iron Ore",
"Madera": "Wood",
"Madera recogida de los pinos. No se usa por sí sola: se gasta como moneda para mejorar arma y armadura en la Armería.": "Wood gathered from pines. Useless on its own: it's spent as currency to upgrade weapon and armor at the Armory.",
"Roca recogida de las canteras. No se usa por sí sola: se gasta como moneda para mejorar arma y armadura en la Armería.": "Rock gathered from quarries. Useless on its own: it's spent as currency to upgrade weapon and armor at the Armory.",
"Mena de hierro, mucho más escasa que la madera o la roca. Solo hace falta para el nivel 3 de mejoras en la Armería.": "Iron ore, far scarcer than wood or rock. Only needed for level 3 upgrades at the Armory.",
"Save corrupta, se ignora.": "Corrupt save, ignoring it.",
"Este objeto cuesta {2} puntos de gloria.": "This item costs {2} glory points.",
"La mochila está llena": "The backpack is full",
"¡La Tienda Goblin ha repuesto existencias!": "The Goblin Shop has restocked!",
"GUERRA": "WAR",
"PROTECCIÓN": "PROTECTION",
"SUPERVIVENCIA": "SURVIVAL",
"Raíces": "Roots",
"Tus tótems y tu Obelisco Ancestral echan raíces: a las unidades enemigas les cuesta 1 punto de movimiento extra por cada paso que den entrando, saliendo o moviéndose por las casillas adyacentes a ellos.": "Your totems and your Ancestral Obelisk take root: enemy units pay 1 extra movement point for every step they take entering, leaving or moving through the tiles adjacent to them.",
"Piel de Roca": "Rock Skin",
"Si un ataque fuese a matar a una de tus unidades y llevas al menos 1 Roca en la mochila, se consume esa Roca y la unidad se queda con 1 punto de vida. Cada unidad solo puede usarlo una vez por turno.": "If an attack would kill one of your units and you carry at least 1 Rock in your backpack, that Rock is consumed and the unit is left with 1 health. Each unit can only use this once per turn.",
"Codo con Codo": "Shoulder to Shoulder",
"Tus unidades ganan +1 de Aguante por cada aliado en una casilla adyacente, hasta un máximo de +{0} (+1 por nivel, hasta +3). El bonus desaparece en cuanto se separan.": "Your units gain +1 Toughness for each ally on an adjacent tile, up to a maximum of +{0} (+1 per level, up to +3). The bonus vanishes as soon as they separate.",
"Evasión": "Evasion",
"Tus unidades tienen un +{0}% de probabilidad de esquivar un ataque enemigo cuerpo a cuerpo (+10% por nivel, hasta +30%).": "Your units have a +{0}% chance to dodge an enemy melee attack (+10% per level, up to +30%).",
"Muralla": "Rampart",
"Aumenta la vida máxima de tu Obelisco Ancestral y de los tótems bajo tu control en un +{0}% (+10% por nivel, hasta +30%).": "Increases the max health of your Ancestral Obelisk and the totems under your control by +{0}% (+10% per level, up to +30%).",
"Armadura de Espinas": "Thorn Armor",
"Cada vez que un enemigo golpea cuerpo a cuerpo a una de tus unidades, recibe 1 punto de daño.": "Every time an enemy hits one of your units in melee, it takes 1 damage.",
"Escudos en Alto": "Shields Up",
"Tus unidades ganan un escudo que anula el próximo ataque que reciban y después desaparece. Si empiezas tu turno con una unidad sin escudo en una casilla adyacente a uno de tus tótems o a tu Obelisco, el escudo se rearma.": "Your units gain a shield that cancels the next attack they receive, then disappears. If you start your turn with a shieldless unit on a tile adjacent to one of your totems or your Obelisk, the shield is rearmed.",
"Embestir": "Charge",
"Una vez por turno, una de tus unidades puede moverse y atacar a la vez gastando una única acción en lugar de dos. Se aplica solo al acercarse a un enemigo, a un tótem o a un Obelisco para golpearlo.": "Once per turn, one of your units can move and attack at once for a single action instead of two. Only applies when closing in on an enemy, a totem or an Obelisk to hit it.",
"Camaradas": "Comrades",
"Tus ataques hacen +{0} de daño por cada aliado tuyo situado en una casilla adyacente al enemigo que vas a golpear (+1 por nivel, hasta +3 por aliado). El propio atacante no cuenta.": "Your attacks deal +{0} damage for each ally of yours standing on a tile adjacent to the enemy you're about to hit (+1 per level, up to +3 per ally). The attacker itself doesn't count.",
"Torretas": "Turrets",
"Al final de tu turno, cada tótem bajo tu control dispara una flecha a los enemigos situados en casillas adyacentes a él y les hace 1 punto de daño.": "At the end of your turn, each totem under your control fires an arrow at enemies on tiles adjacent to it, dealing 1 damage.",
"Sed de Sangre": "Bloodlust",
"Cada vez que una unidad mata a un enemigo, gana +1 de ataque durante su próximo turno. Se acumula hasta {0} {1} (+1 por nivel, hasta 3) y la unidad se va tiñendo de rojo. Un turno sin matar reinicia la sed de sangre.": "Every time a unit kills an enemy, it gains +1 attack during its next turn. Stacks up to {0} {1} (+1 per level, up to 3) and the unit gradually turns red. A turn without a kill resets the bloodlust.",
"Último Aliento": "Last Gasp",
"Una unidad tuya que se ha quedado con 1 punto de vida por haber recibido daño gana +1 de ataque. No se aplica a las unidades que tienen 1 de vida como vida máxima.": "A unit of yours left at 1 health from taking damage gains +1 attack. Doesn't apply to units whose max health is 1.",
"Emboscada": "Ambush",
"Una unidad tuya que ataca desde dentro de un arbusto (se haya movido hasta él o no) gana +1 de ataque en ese golpe.": "A unit of yours that attacks from inside a bush (whether or not it moved into it) gains +1 attack on that hit.",
"Una unidad tuya que ataca desde dentro de un arbusto (se haya movido hasta él o no) gana +2 de ataque en ese golpe (+1 por nivel, hasta +3).": "A unit of yours that attacks from inside a bush (whether or not it moved into it) gains +2 attack on that hit (+1 per level, up to +3).",
"Una unidad tuya que ataca desde dentro de un arbusto (se haya movido hasta él o no) gana +3 de ataque en ese golpe (+1 por nivel, hasta +3).": "A unit of yours that attacks from inside a bush (whether or not it moved into it) gains +3 attack on that hit (+1 per level, up to +3).",
"Una unidad tuya que ataca desde dentro de un arbusto (se haya movido hasta él o no) gana +1 de ataque en ese golpe (+1 por nivel, hasta +3).": "A unit of yours that attacks from inside a bush (whether or not it moved into it) gains +1 attack on that hit (+1 per level, up to +3).",
"Punto Estratégico": "Strategic Point",
"Los tótems bajo tu control te permiten reclutar aliados como si fueran el Obelisco Ancestral: pulsa un tótem tuyo y aparecerá el icono de reclutar; el nuevo aliado aparece en una casilla adyacente al tótem. La población máxima sigue siendo la que marca el Obelisco.": "Totems under your control let you recruit allies as if they were the Ancestral Obelisk: tap one of your totems and the recruit icon appears; the new ally appears on a tile adjacent to the totem. Max population is still set by the Obelisk.",
"Centinela": "Sentinel",
"Todas tus unidades, tus tótems y tu Obelisco Ancestral aumentan en 1 su percepción: ven una casilla más lejos y revelan más mapa.": "All your units, your totems and your Ancestral Obelisk gain +1 perception: they see one tile further and reveal more of the map.",
"Refuerzos": "Reinforcements",
"Aumenta en +{0} la población máxima de tu ejército, es decir, cuántas unidades puedes tener a la vez (+1 por nivel, hasta +3).": "Increases your army's max population by +{0}, that is, how many units you can have at once (+1 per level, up to +3).",
"Anfibio": "Amphibious",
"Tus unidades pueden caminar sobre las casillas de agua como si fueran de tierra: podrán moverse por ellas y atravesarlas.": "Your units can walk on water tiles as if they were land: they can move onto them and cross them.",
"Abundancia": "Abundance",
"Cada tótem que controlas te da +1 de gloria extra al empezar tu turno, hasta un máximo de 1 tótem por cada punto de esta habilidad.": "Each totem you control gives you +1 extra glory at the start of your turn, up to a maximum of 1 totem per point in this skill.",
"Regateo": "Haggling",
"Todos los productos de la Tienda Goblin cuestan la mitad, redondeando hacia abajo (nunca menos de 1 punto de gloria).": "All Goblin Shop products cost half, rounded down (never less than 1 glory point).",
"Recolector": "Gatherer",
"Todas las fuentes de recursos te dan +{0} unidad{1} extra al recogerlas (+1 por nivel, hasta +3).": "All resource sources give you +{0} extra unit{1} when collected (+1 per level, up to +3).",
"Uno con la Tierra": "One with the Earth",
"Al comienzo de cada uno de tus turnos, todas tus unidades se curan 1 punto de vida por cada tótem bajo tu control (sin superar su vida máxima).": "At the start of each of your turns, all your units heal 1 health for each totem under your control (without exceeding their max health).",
"Bloqueada: has elegido {0}.": "Locked: you chose {0}.",
"Bloqueada: lleva {0} al máximo primero.": "Locked: max out {0} first.",
"¡Embestida!": "Charge!",
"¡Escudo!": "Shield!",
"¡Esquiva!": "Dodge!",
"¡Bloqueado!": "Blocked!",
"¡Piel de Roca!": "Rock Skin!",
"Selecciona una habilidad para ver su descripción.": "Select a skill to see its description.",
"Habilidad por definir — esta rama todavía está vacía.": "Skill TBD — this branch is still empty.",
"por nivel": "per level",
"Pasar turno": "End turn",
"Turno rival…": "Rival's turn…",
"¡Todos listos!": "All set!",
"Vaya, otro verdugo. Perdón, «jugador»: así os llamamos antes de que nos aplastéis. Soy {0}, llevo media vida dedicándome a ser vuestra pelota en este deporte de majaras. Siempre digo que de algo hay que vivir. Bueno, vivir, vivir... Te enseñaré lo básico para que, al menos, me aplastes con cierta elegancia.": "Well, well, another executioner. Sorry, \"player\": that's what we call you before you squash us. I'm {0}, and I've spent half my life as your ball in this lunatic sport. I always say a gnome's gotta make a living. Well, living, living... I'll teach you the basics so you can at least squash me with some elegance.",
"Vale, viejales": "Fine, oldie",
"Esa roca mugrienta de 2 metros es tu Obelisco Ancestral: hogar, fábrica de reclutas y retrete, todo en uno. Pulsa sobre él. No muerde (nosotros los gnomos sí, pero de eso hablaremos en otro momento).": "That filthy 2-meter rock is your Ancestral Obelisk: home, recruit factory and toilet, all in one. Tap it. It doesn't bite (we gnomes do, but that's a story for another time).",
"Pulsa tu Obelisco": "Tap your Obelisk",
"Muy bien. Has tocado una piedra. Han dado diplomas por menos.": "Very good. You touched a rock. They've handed out diplomas for less.",
"Ahora pulsa sobre el icono de Reclutar, el primero de los tres. El de la izquierda… ¿Sabes cuál te digo, no?": "Now tap the Recruit icon, the first of the three. The one on the left… You know which one I mean, right?",
"Pulsa el icono de Reclutar": "Tap the Recruit icon",
"Perfecto. Ya estás en la sala de entrenamiento. La idea era reunir a los mejores, pero se nos iba el presupuesto.": "Perfect. You're now in the training hall. The plan was to gather the best, but we ran out of budget.",
"Elige a TruenoEspora, el del sombrero de seta: no está nada mal, es bastante versátil y esconde una seta-trampa bajo la manga. Cada uno cuesta Puntos de Gloria, ese número amarillo y reluciente de arriba, lo único bonito de todo este asunto.": "Pick TruenoEspora, the one in the mushroom hat: not bad at all, pretty versatile, and he's hiding a trap mushroom up his sleeve. Each one costs Glory Points, that shiny yellow number up top, the only pretty thing about this whole affair.",
"Elige a TruenoEspora": "Pick TruenoEspora",
"Mira qué sonrisa, ya sabe a lo que ha venido. Una lástima que los míos no estén tan contentos.": "Look at that smile, he knows what he signed up for. Shame mine aren't so happy.",
"Ahora pulsa RECLUTAR. Un clic más y tendrás bajo tus órdenes a otro pobre diablo que firma sin haber leído la letra pequeña.": "Now tap RECRUIT. One more click and you'll have another poor devil under your command who signed without reading the fine print.",
"Pulsa RECLUTAR": "Tap RECRUIT",
"¡Estupendo! Veo que has encontrado el botón. No despediremos al diseñador de interfaces… de momento.": "Great! Looks like you found the button. We won't fire the interface designer… for now.",
"Las casillas destacadas te indican los sitios disponibles donde colocarlo junto al Obelisco. Elige una y tu unidad aparecerá ahí, como un champiñón, pero con peor carácter.": "The highlighted tiles show the available spots next to the Obelisk to place it. Pick one and your unit will appear there, like a button mushroom, but with a worse temper.",
"Elige una casilla para colocarlo": "Pick a tile to place it",
"¡Ya tienes un compañero leal! A ver si la lealtad le dura mucho cuando empiece a salpicar la sangre.": "You've got yourself a loyal companion! Let's see how long that loyalty lasts once the blood starts splattering.",
"Antes de seguir, un truco útil: selecciona a TruenoEspora y mantén pulsada la cara de tu unidad, abajo a la izquierda, y verás todas sus estadísticas. Con las unidades enemigas funciona igual: selecciónalas y mira de qué pasta están hechas… antes de que te hagan pasta a ti.": "Before we go on, a handy trick: select TruenoEspora and hold down your unit's face, bottom left, and you'll see all its stats. It works the same with enemy units: select them and see what they're made of… before they make mincemeat of you.",
"Mantén pulsada su cara (3 s)": "Hold its face (3 s)",
"Ahora sabes cuánto aguanta, cuánto pega y cuánto le queda. Información de oro, y gratis.": "Now you know how much it can take, how hard it hits and how much it has left. Golden info, and free.",
"Uno solo se aburre, y yo me aburro con él. Recluta otro igual: Obelisco, Reclutar, unidad, RECLUTAR y casilla. Necesitarás a alguien a quien lanzar cosas (sí, cosas: yo soy una de ellas).": "One alone gets bored, and I get bored with it. Recruit another one just like it: Obelisk, Recruit, unit, RECRUIT and tile. You'll need someone to throw things at (yes, things: I'm one of them).",
"Recluta un segunda unidad": "Recruit a second unit",
"Dos pardillos mejor que uno. Así la culpa y los remordimientos se repartirán.": "Two suckers are better than one. That way the guilt and remorse get split.",
"Para dar instrucciones a una unidad hay que seleccionarla: pulsa sobre uno de tus aliados. Con cariño, no vayas a clavarle esa flecha puntiaguda voladora en el ojo.": "To give orders to a unit, you have to select it: tap one of your allies. Gently, please, unless you want to put that pointy flying arrow through its eye.",
"Selecciona una unidad": "Select a unit",
"¡Eso es! Qué sensación de poder, ¿verdad? Pues no te acostumbres.": "That's it! What a rush of power, huh? Don't get used to it.",
"Esos círculos del suelo te indican las zonas a donde puede moverse. Pulsa el que parpadea y se moverá. Ojo: andar gasta una de sus 2 acciones por turno; aquí hasta caminar tiene precio, como en la vida.": "Those circles on the ground show where it can move. Tap the blinking one and off it goes. Heads up: walking costs one of its 2 actions per turn. Even walking has a price here, just like in life.",
"Mueve la unidad hasta la zona marcada.": "Move the unit to the marked spot.",
"¡Está andando! Un milagro de la ingeniería orgánica, y sin tropezarse. Bueno, casi.": "It's walking! A miracle of organic engineering, and without tripping. Well, almost.",
"Ese arbusto tan mono no es decoración: es un escondite. Métete dentro y el rival dejará de verte (tú sí te ves, qué detalle). Eso sí: si alguien entra en un arbusto donde ya hay alguien escondido, se llevará un golpe y perderá sus acciones. Esconderse: el arte de no estar donde te buscan.": "That cute bush isn't decoration: it's a hiding spot. Get inside and your rival stops seeing you (you can still see yourself, how thoughtful). But beware: if someone enters a bush where someone is already hiding, they take a hit and lose their actions. Hiding: the art of not being where they look for you.",
"Escóndete en el arbusto": "Hide in the bush",
"Invisible. Como mi cuenta bancaria.": "Invisible. Just like my bank account.",
"¿Ves ese gnomo de ahí? El que tiembla como un flan. Es Tinkle, mi primo segundo. Aquí lo llamamos «balón». Acércate y pulsa la manita para cogerlo. Si hace falta, tu unidad caminará solo hasta él.": "See that gnome over there? The one shaking like jelly. That's Tinkle, my second cousin. Around here we call him \"the ball\". Walk up and tap the little hand to grab him. If needed, your unit will walk over by itself.",
"Coge a Tinkle": "Grab Tinkle",
"Tinkle, perdóname. Eras tú o yo.": "Tinkle, forgive me. It was you or me.",
"Y ahora lo MÁS ingenioso del juego: ¡Golpéalo! Cada golpe le suma puntos (cuanta más fuerza, más puntos) y esos puntos serán el daño de tu “estampada”. Nuestro deporte nacional, ¡yupi! Sí, ya sé que suena a locura. De hecho lo es.": "And now the MOST ingenious part of the game: Hit him! Every hit adds points to him (the more strength, the more points), and those points become the damage of your \"slam\". Our national sport, yippee! Yes, I know it sounds insane. Because it is.",
"Golpea al gnomo (icono del puño)": "Hit the gnome (fist icon)",
"¡Puntos! Tinkle, de toda la familia, tú siempre fuiste quien mejor encajaba los golpes. Bueno, el tío Klink era mejor, pero el tío Klink solo es un recuerdo, un recuerdo disperso sobre el césped...": "Points! Tinkle, of the whole family, you were always the one who took a beating best. Well, Uncle Klink was better, but Uncle Klink is just a memory now, a memory scattered across the grass...",
"Noticia: pasarse el balón también da puntos, por si en algún momento te duelen los nudillos. Pulsa el icono de lanzar y luego selecciona a tu amigo. Quien lanza gasta acción; quien recibe, no. Es lo más parecido a la justicia que verás por aquí.": "News flash: passing the ball also earns points, in case your knuckles start to ache. Tap the throw icon and then select your friend. The thrower spends an action; the receiver doesn't. It's the closest thing to justice you'll see around here.",
"Lánzale el gnomo a otra unidad.": "Throw the gnome to another unit.",
"¡Buen lanzamiento! Tinkle, ¿todo bien? Se te ve mareado.": "Nice throw! Tinkle, are you okay? You look dizzy.",
"Mientras uno carga con el gnomo no puede atacar, así que el que tenga las manos libres que se encargue de ese que te mira raro. Tranquilo, no devolverá el golpe (ni siquiera sabe, al pobre lo han programado para que no lo haga). Selecciona a tu unidad libre y pulsa al enemigo.": "While someone is carrying the gnome they can't attack, so whoever has free hands can deal with the guy giving you funny looks. Relax, he won't hit back (poor thing was programmed not to). Select your free unit and tap the enemy.",
"Ataca al enemigo": "Attack the enemy",
"Muy bien. Ahora seguro que le duele algo, y mañana también.": "Very good. Now something definitely hurts, and tomorrow too.",
"¿Ves ese pino? Y las rocas, y la mena de hierro: también se golpean. Tienen 2 puntos de resistencia y, al romperse, sueltan un recurso que vuela solito hasta tu mochila (abajo a la izquierda). Selecciona a tu unidad libre y pulsa el pino. Ojalá salga todo bien, toquemos madera.": "See that pine? And the rocks, and the iron ore: you can hit those too. They have 2 points of toughness and, when they break, they drop a resource that flies by itself to your backpack (bottom left). Select your free unit and tap the pine. Hopefully it all goes well, knock on wood.",
"Tala el pino (2 golpes)": "Chop down the pine (2 hits)",
"¡Madera conseguida! Ya puedes fabricarme un ataúd... o una mejora de armadura, que queda más elegante. En la armería de tu obelisco tienes las mejoras de equipo.": "Wood acquired! Now you can build me a coffin... or an armor upgrade, which is classier. Gear upgrades are in your obelisk's armory.",
"No hay nada mejor que conquistar un tótem con un gnomo cargado de puntos. Tu unidad lo estampa contra él y le resta tanta vida como puntos lleve. Si se queda sin puntos, el tótem es tuyo y te da +2 Puntos de Gloria cada turno. Siempre dos, se capture como se capture. Sí, dos, ya puedes ir pensando en la jubilación. ¿Por qué me miras a mí y al tótem de esa manera? Acércate con quien lleva el gnomo y pulsa la diana. Lo que la gente del gremio conoce como “estampada”.": "There's nothing better than conquering a totem with a gnome loaded with points. Your unit slams him against it and takes off as much health as the points he carries. If it runs out of points, the totem is yours and gives you +2 Glory Points every turn. Always two, however you capture it. Yes, two, you can start thinking about retirement. Why are you looking at me and the totem like that? Walk up with whoever is carrying the gnome and tap the target. What guild folk call a \"slam\".",
"Haz una “estampada” con el gnomo contra el tótem": "Slam the gnome into the totem",
"¡Un tótem conquistado! ¿Tinkle? ¿Alguien puede llamar a emergencias? O a una funeraria... Y un truco: si una de tus unidades empieza el turno pegada a un tótem tuyo, recarga su habilidad especial. Capturar tótems también sirve para eso.": "A totem conquered! Tinkle? Can someone call an ambulance? Or an undertaker... And a trick: if one of your units starts its turn right next to a totem of yours, its special ability recharges. Capturing totems is good for that too.",
"Tu Obelisco guarda más trucos. Selecciónalo y abre Habilidades: tres ramas (Guerra, Protección y Supervivencia) con mejoras permanentes que se compran con Puntos de Gloria. Échale un vistazo y ciérrala con la X. No te pido que entiendas nada, de momento con que sepas que está ahí, es suficiente.": "Your Obelisk hides more tricks. Select it and open Skills: three branches (War, Protection and Survival) with permanent upgrades bought with Glory Points. Take a look and close it with the X. I'm not asking you to understand anything, just knowing it's there is enough for now.",
"Abre Habilidades y ciérrala": "Open Skills and close it",
"Demasiado árbol de habilidades para tan poco bosque.": "Too much skill tree for so little forest.",
"Y por último, la Armería: aquí gastas esa madera, roca y metal en subir el Arma y la Armadura de todas tus unidades, nivel a nivel (el 1 cuesta una madera y una roca). Es el único sitio de este juego donde la madera sirve para algo bueno. Ábrela y ciérrala.": "And finally, the Armory: here you spend that wood, rock and metal to upgrade the Weapon and Armor of all your units, level by level (level 1 costs one wood and one rock). It's the only place in this game where wood is good for something. Open it and close it.",
"Abre la Armería y ciérrala": "Open the Armory and close it",
"Ahora sabes dónde gastar los restos de la deforestación.": "Now you know where to spend the leftovers of deforestation.",
"Cuando tus unidades se queden sin acciones (o sin ganas), pulsa PASAR TURNO. Luego jugará el rival y luego vuelves tú… Y así sucesivamente. Es como la vida: esperas tu turno, esperas, esperas, estampas un gnomo contra el césped, vuelves a esperar...": "When your units run out of actions (or willpower), tap END TURN. Then the rival plays, then you again... And so on. It's like life: you wait for your turn, wait, wait, slam a gnome into the grass, wait again...",
"Pulsa PASAR TURNO": "Tap END TURN",
"Y el rival... no hizo nada. Era de esperar, esto es un tutorial.": "And the rival... did nothing. Figures, this is a tutorial.",
"Por si no te parecía suficientemente satisfactorio reventar gnomos... ¿ves ese cofre escondido en un rincón? En las partidas de verdad hay un buen puñado repartidos por el mapa. Se abren haciendo clic sobre ellos y esconden reliquias, de las que dan ventajas de las buenas… Cuando las consigas, cada vez que muera una unidad tuya, perderán 1 punto de durabilidad, y cuando lleguen a 0 se rompen. Como la clavícula de mi tío Klink.": "In case bursting gnomes wasn't satisfying enough for you... see that chest hidden in a corner? In real matches there are quite a few scattered around the map. You open them by clicking on them, and they hide relics, the kind that give really good advantages… Once you get them, every time one of your units dies they lose 1 durability point, and when they hit 0 they break. Like my uncle Klink's collarbone.",
"¡Reliquia en la mochila! Son las Botas TrotaMontes: +1 de Movimiento para todas tus unidades. Fíjate en su marcador, ese 5/5 que tiene al lado: esa es su durabilidad. Cuida de tus unidades o las botas se gastarán antes de tiempo. Y no, no guardo el ticket de compra, así que olvídate de la garantía.": "Relic in the backpack! These are the TrotaMontes Boots: +1 Movement for all your units. Look at the 5/5 marker next to it: that's their durability. Look after your units or the boots will wear out early. And no, I didn't keep the receipt, so forget about the warranty.",
"Abre el cofre de reliquias": "Open the relic chest",
"Lo has conseguido. Ya sabes reclutar, mover, esconderte, coger gnomos, lanzarlos, estamparlos, atacar, talar, abrir cofres de reliquias, mejorar y conquistar. ¡Enhorabuena! Oficialmente ya eres todo un asesino de gnomos... aunque me parta lo poco que me queda de corazón o de lomo, según transcurra la partida. Y recuerda: si algún gnomo te mira raro, es que ya conoce tus intenciones.": "You did it. You now know how to recruit, move, hide, grab gnomes, throw them, slam them, attack, chop, open relic chests, upgrade and conquer. Congratulations! You're officially a full-blown gnome killer... even if it breaks what's left of my heart or my back, depending on how the match goes. And remember: if a gnome gives you funny looks, he already knows your intentions.",
"TERMINAR TUTORIAL": "FINISH TUTORIAL",
"MISIÓN {0}": "MISSION {0}",
"¡Listo!": "Done!",
"¡Eso no ha sido ni un segundo! Mantén pulsada la cara hasta que el contador llegue a cero, sin soltar. Tranquilo, yo no tengo prisa: es lo único que me sobra.": "That wasn't even a second! Keep the face pressed until the counter hits zero, without letting go. Relax, I'm in no hurry: it's the only thing I have plenty of.",
"¿Seguro? Pulsa otra vez": "Sure? Tap again",
"Un golem de corteza y musgo que nunca ha tenido prisa por llegar a ningún sitio, pero tampoco por caer.": "A bark-and-moss golem who has never been in a hurry to get anywhere, but never in a hurry to fall either.",
"Se desliza entre los árboles más rápido de lo que nadie puede seguirle la pista.": "Glides through the trees faster than anyone can track.",
"Experimenta con esporas explosivas y, milagrosamente, casi nunca se hace daño a sí mismo.": "Experiments with explosive spores and, miraculously, almost never hurts himself.",
"El mejor brazo de las Colinas Rock'n Troll — nadie lanza un gnomo más lejos ni más certero.": "The best arm of the Rock'n Troll Hills — nobody throws a gnome farther or more accurately.",
"Piensa cada jugada tres veces antes de moverse, lo cual explica por qué siempre llega tarde.": "Thinks every move through three times before acting, which explains why he's always late.",
"Sus puños son más duros que la piedra de la que sacó el nombre.": "His fists are harder than the stone he took his name from.",
"Mantén pulsado para ver las estadísticas dla unidad": "Hold to see the unit's stats",
"¡GOLPE MORTAL!": "DEADLY BLOW!",
"¡Conquistado!": "Conquered!",
"Gnomo": "Gnome",
"Nueva Partida": "New Game",
"Reanudar Partida": "Resume Game",
"Multijugador (próximamente)": "Multiplayer (coming soon)",
"Prototipo en construcción": "Prototype under construction",
"Volver": "Back",
"Elige el modo de juego": "Choose game mode",
"Elige tu raza": "Choose your race",
"Elige el nivel": "Choose the level",
"Elige el número de rivales": "Choose the number of rivals",
"Ajustes": "Settings",
"AJUSTES": "SETTINGS",
"Efectos de sonido": "Sound effects",
"Música": "Music",
"(próximamente)": "(coming soon)",
"Mostrar equipos": "Show teams",
"Modo rendimiento": "Performance mode",
"Sombras": "Shadows",
"Animación de niebla": "Fog animation",
"Vegetación": "Vegetation",
"Resolución adaptativa": "Adaptive resolution",
"Idioma": "Language",
"Salir de la partida": "Leave game",
"Cuenta": "Account",
"Cerrar": "Close",
"Equipo GuardaBosques": "Team GuardaBosques",
"Habitantes del bosque y expertos en setas explosivas: GolemCorteza, SurcaBosques y TruenoEspora.": "Forest dwellers and experts in explosive mushrooms: GolemCorteza, SurcaBosques and TruenoEspora.",
"Rápidos y ágiles: se mueven más casillas por turno y suelen golpear antes que el rival.": "Fast and agile: they move more tiles per turn and usually strike before the rival.",
"Poco aguante: caen en pocos golpes, hay que jugar con cuidado y no exponerlos de más.": "Low toughness: they fall in a few hits, so play carefully and don't overexpose them.",
"Equipo MascaRrocas": "Team MascaRrocas",
"Trolls de las colinas rocosas, tan duros de roer como su música: LanzaGnomos, UrgaMentes y PuñoRroca.": "Trolls from the rocky hills, as hard to crack as their music: LanzaGnomos, UrgaMentes and PuñoRroca.",
"Duros como la roca: aguantan mucho castigo y golpean con fuerza cuerpo a cuerpo.": "Hard as rock: they take a lot of punishment and hit hard in melee.",
"Más lentos: tardan más turnos en alcanzar la línea de combate.": "Slower: they take more turns to reach the front line.",
"Caza gnomos, cárgalos y machácalos en la base rival.": "Hunt gnomes, load them up and smash them at the enemy base.",
"Bosque MushBoom": "MushBoom Forest",
"Un bosque de ríos y lagos donde cualquier seta puede ser una bomba.": "A forest of rivers and lakes where any mushroom can be a bomb.",
"Setas explosivas: aparecen por el mapa de vez en cuando. Si recoges una, explota a los 3 turnos: 5 de daño al portador y a todo lo adyacente (unidades, tótems y Obeliscos, de cualquier bando).": "Explosive mushrooms: they appear on the map every now and then. If you pick one up, it explodes after 3 turns: 5 damage to the carrier and everything adjacent (units, totems and Obelisks, of any side).",
"Altar de Sacrificios: cada jugador tiene su propia barra de ofrendas. Entrega una seta o un gnomo junto al altar como ofrenda (una seta rellena 10 puntos); el primero en llenarla invoca al GnomOgro.": "Altar of Sacrifice: each player has their own offering bar. Deliver a mushroom or a gnome next to the altar as an offering (one mushroom fills 10 points); the first to fill it summons the GnomOgre.",
"GnomOgro: 30 de vida y 10 de ataque. Avanza hacia la base rival y la destruye si nadie lo detiene.": "GnomOgre: 30 health and 10 attack. It marches toward the enemy base and destroys it if nobody stops it.",
"Colinas Rock'n Troll": "Rock'n Troll Hills",
"Colinas rocosas con mecánicas propias, aún por revelar. Llegarán más adelante en el desarrollo.": "Rocky hills with their own mechanics, yet to be revealed. They'll arrive later in development.",
"Reclutar": "Recruit",
"Habilidades": "Skills",
"+2 / turno": "+2 / turn",
"Mochila": "Backpack",
"Turno 1 / 60": "Turn 1 / 60",
"RECLUTAR": "RECRUIT",
"HABILIDADES": "SKILLS",
"MEJORAR": "UPGRADE",
"ARMA": "WEAPON",
"Nivel 0/3": "Level 0/3",
"ARMADURA": "ARMOR",
"MOCHILA": "BACKPACK",
"Base de cada turno": "Base per turn",
"Sin bajas conseguidas este turno": "No kills this turn",
"Sin tótems conquistados": "No totems conquered",
"ENTRAR": "ENTER",
"REGISTRARSE": "SIGN UP",
"Correo o nombre de usuario": "Email or username",
"tu@correo.com o tu nombre": "you@email.com or your name",
"Contraseña": "Password",
"TIENDA GOBLIN": "GOBLIN SHOP",
"COMPRAR": "BUY",
"Este objeto cuesta 3 puntos de gloria.": "This item costs 3 glory points.",
"Este objeto cuesta 4 puntos de gloria.": "This item costs 4 glory points.",
"Este objeto cuesta 6 puntos de gloria.": "This item costs 6 glory points.",
"Totems capturados": "Totems captured",
"Bajas sufridas": "Casualties suffered",
"DERROTA": "DEFEAT",
"Se acabaron los 60 turnos — gana quien más resistió.": "The 60 turns are over — whoever endured the most wins.",
"EMPATE": "DRAW",
"Se acabaron los 60 turnos y todo sigue exactamente igualado.": "The 60 turns are over and everything is still exactly even.",
"Fuerza": "Strength",
"Aguante": "Toughness",
"Movimiento": "Movement",
"Agilidad": "Agility",
"Percepción": "Perception",
"Arma": "Weapon",
"Armadura": "Armor",
"Nivel {0}/{1}": "Level {0}/{1}",
"Habilidad especial": "Special skill",
"Turno {0} / {1}": "Turn {0} / {1}",
"+{0} / turno": "+{0} / turn",
"Vida": "Health",
"Ataque": "Attack",
"Daño": "Damage",
"Recursos": "Resources",
"Coste": "Cost",
"Nivel": "Level",
"Máximo": "Max",
"Aceptar": "Accept",
"Cancelar": "Cancel",
"Elige": "Choose",
"Equipo {0}": "Team {0}",
"{0} rivales": "{0} rivals",
"Nivel {0}": "Level {0}",
"Nivel máximo": "Max level",
"Gnomos": "Gnomes",
"— coste": "— cost",
"Recompensa": "Reward",
"Completada": "Completed",
"Continuar ▸": "Continue ▸",
"Sigue pulsando": "Keep holding",
"Demasiado pronto": "Too soon",
"Saltar tutorial": "Skip tutorial",
"Coste:": "Cost:",
"Coste: {0}": "Cost: {0}",
"Coste {0}": "Cost {0}",
"Bienvenido al Bosque MushBoom, antes llamado «Bosque de la Paz y la Armonía». Cambiaron el nombre el día que alguien descubrió que las setas de por aquí explotan. Desde entonces el turismo ha bajado bastante, y los gnomos, todavía más. Yo soy de los pocos que quedan: el último con ganas de hablar.": "Welcome to the MushBoom Forest, formerly known as the «Forest of Peace and Harmony». They renamed it the day someone found out the mushrooms around here explode. Tourism has dropped quite a bit since then, and gnomes even more. I'm one of the few left: the last one in the mood to chat.",
"Qué simpático": "How charming",
"Es un sitio precioso, si te gusta el olor a humo, a hongo chamuscado y a gnomo a la brasa. Dicen que, de vez en cuando, la tierra tiembla. No es un terremoto: es el hambre de un gigante que duerme bajo un altar. Hoy te enseñaré las tres cosas que hacen especial este bosque: las setas explosivas, el Altar de Sacrificios y el GnomOgro.": "It's a gorgeous place, if you like the smell of smoke, scorched fungus and grilled gnome. They say the ground shakes every now and then. It's not an earthquake: it's the hunger of a giant sleeping under an altar. Today I'll show you the three things that make this forest special: explosive mushrooms, the Sacrifice Altar and the GnomOgre.",
"Estoy deseando": "Can't wait",
"Primera atracción: las setas explosivas. Aparecen sueltas por el bosque y se cogen igual que un gnomo, con la manita (coger no gasta acción). Pero ojo: en cuanto la llevas encima empieza una cuenta atrás, y al llegar a 0 explota, con 5 de daño para quien la lleva y para todo lo que tenga alrededor. Te he dejado una cerquita de tu unidad. ¡Cógela!": "First attraction: explosive mushrooms. They show up loose around the forest and you pick them up just like a gnome, with the little hand (picking up costs no action). But careful: as soon as you carry one, a countdown starts, and at 0 it explodes, dealing 5 damage to whoever carries it and to everything around. I've left one right next to your unit. Grab it!",
"Coge la seta explosiva": "Pick up the explosive mushroom",
"¡Ya la tienes! Fíjate en el número que lleva encima: son los turnos que le quedan antes de estallar. Sí, la has cogido tú. Yo no me hago responsable.": "You've got it! Look at the number it carries: those are the turns left before it blows. Yes, you picked it up. I take no responsibility.",
"Ese número baja en uno cada vez que TÚ terminas tu turno (empieza en 3). Si llega a 0, adiós seta y adiós portador. Pulsa PASAR TURNO y compruébalo: tranquilo, aún te queda margen. Mientras no te lo pienses demasiado...": "That number drops by one every time YOU end your turn (it starts at 3). At 0, goodbye mushroom and goodbye carrier. Press END TURN and see for yourself: don't worry, you still have some margin. As long as you don't think about it too much...",
"Pasa turno y mira la cuenta atrás": "End turn and watch the countdown",
"Ahora le quedan 2 turnos. Si fueras listo, ya estarías pensando en cómo deshacerte de ella. Tranquilo, que te lo cuento.": "It now has 2 turns left. If you were smart, you'd already be thinking about how to get rid of it. Relax, I'll tell you how.",
"¿Ves ese altar tan acogedor? Es el Altar de Sacrificios y siempre tiene hambre: su barra tiene 30 espacios y, en vez de vaciarse, se llena con ofrendas. Una seta explosiva le da 10 puntos y, además, se desactiva sin explotar. Basta con que tu unidad con la seta acabe junto al altar, o con que pulses su diana, para ofrecérsela.": "See that cozy altar? It's the Sacrifice Altar and it's always hungry: its bar has 30 slots and, instead of emptying, it fills up with offerings. An explosive mushroom gives it 10 points and is also defused without exploding. It's enough for your unit carrying the mushroom to end up next to the altar, or to press its target icon, to offer it.",
"Ofrece la seta al altar": "Offer the mushroom to the altar",
"Diez puntos para el altar y cero heridos. Es el trato más justo que ha hecho nadie en este bosque.": "Ten points for the altar and zero casualties. The fairest deal anyone has made in this forest.",
"Pero el altar es un glotón y también se alimenta de gnomos. Si estampas a un gnomo contra él (con la diana, como contra un tótem), la barra se llena con TODOS los puntos que lleve encima el gnomo: cuantos más golpes haya recibido, más ofrenda. Tinkle, ven aquí… No te asustes, esto va a ser rápido. Para ti, claro. Coge a Tinkle.": "But the altar is a glutton and it also feeds on gnomes. If you smash a gnome against it (with the target icon, like against a totem), the bar fills with ALL the points the gnome carries: the more hits it took, the bigger the offering. Tinkle, come here… Don't be scared, this will be quick. For you, I mean. Pick up Tinkle.",
"Tinkle, ya sabes que te quiero. Lo suficiente como para que sufras pronto.": "Tinkle, you know I love you. Enough for you to suffer soon.",
"Tinkle se ha puesto muy nervioso y ya acumula 20 puntos. No me preguntes cómo: hay cosas que es mejor no saber. Con los 10 de la seta, 20 más dejan el altar en 30: lleno del todo. Selecciona a tu unidad y pulsa la diana del altar. Y ruega por su alma.": "Tinkle has gotten very nervous and now has 20 points. Don't ask me how: some things are better left unknown. With the mushroom's 10, 20 more leaves the altar at 30: completely full. Select your unit and press the altar's target icon. And pray for his soul.",
"Estampa a Tinkle contra el altar": "Smash Tinkle against the altar",
"¡Altar lleno! Ha desaparecido en medio de un temblor. ¿Has oído eso? Sí, ese crujido. Corre. Bueno, corre tú, que yo ya soy mayor.": "Altar full! It has vanished in a tremor. Did you hear that? Yes, that crunch. Run. Well, you run, I'm old.",
"Ese es el GnomOgro: un gigante que no obedece a nadie. Es del bando de quien llenó el altar (tú), pero va por su cuenta: al principio de CADA turno da un paso hacia el Obelisco rival y, si tiene a un enemigo al lado, lo mata de un golpe en vez de andar. Tiene 30 de vida, y si llega a la base rival la destruye de un solo golpe y se acaba la partida. Pasa turno y míralo caminar.": "That's the GnomOgre: a giant who obeys no one. It belongs to whoever filled the altar (you), but it does its own thing: at the start of EVERY turn it takes a step toward the rival Obelisk and, if an enemy is next to it, it kills it in one blow instead of walking. It has 30 health, and if it reaches the rival base it destroys it in a single hit and the game ends. End your turn and watch it walk.",
"Pasa turno y mira al GnomOgro": "End turn and watch the GnomOgre",
"Un paso más cerca de la victoria. Y fíjate qué temblor al caminar: da gusto verlo, mientras no vaya a por ti.": "One step closer to victory. And look at that tremor as it walks: a joy to watch, as long as it isn't coming for you.",
"Y eso es todo del Bosque MushBoom. Resumen: coge setas pero no te las quedes, llena el altar con setas y gnomos, y deja que el GnomOgro haga el trabajo sucio. Ojo: si el que llena el altar es el rival, el gigante irá a por TU Obelisco. Entonces ataca al gigante con todas tus unidades, o corre a llenar tú el altar antes. ¡Suerte, la vas a necesitar!": "And that's all for the MushBoom Forest. Summary: pick up mushrooms but don't keep them, fill the altar with mushrooms and gnomes, and let the GnomOgre do the dirty work. Careful: if the rival fills the altar, the giant will come for YOUR Obelisk. Then attack the giant with all your units, or run to fill the altar first. Good luck, you'll need it!",
"Colinas Rock'n Troll. Hace siglos, unos trols dieron aquí un concierto de rock tan ruidoso que las colinas se echaron a temblar... y nunca pararon. Los trols se quedaron a vivir, para los coros. Nadie se atreve a decirles que ya no cantan nada bien.": "Rock'n Troll Hills. Centuries ago, some trolls gave a rock concert here so loud that the hills started to shake... and never stopped. The trolls stayed to live here, for the backing vocals. Nobody dares tell them they can't sing anymore.",
"Qué ambiente": "What a vibe",
"Aquí lo oirás todo: tambores que retumban, rocas que caen del cielo y un volcán de muy mal carácter, harto de tanto ruido. Yo, que tengo buen oído, prefiero no acercarme. Hoy te enseñaré las tres cosas que hacen especial este sitio: los Tambores de Guerra, los Fragmentos de roca y el Volcán.": "You'll hear everything here: booming drums, rocks falling from the sky and a very ill-tempered volcano, fed up with all the noise. I have good hearing, so I prefer not to get close. Today I'll show you the three things that make this place special: the War Drums, the Rock Fragments and the Volcano.",
"A por ellos": "Let's go",
"Primero, los Tambores de Guerra. Si tienes MÁS unidades pegadas a un tambor que cualquier otro bando, al acabar tu turno llenas una porción de tu ruleta (la que flota sobre el tambor). Con empate o minoría, nada. Cuando tu ruleta llega al máximo, ¡llueven rocas sobre tus rivales! Acerca tu unidad al tambor.": "First, the War Drums. If you have MORE units next to a drum than any other side, at the end of your turn you fill one slice of your wheel (the one floating above the drum). With a tie or a minority, nothing. When your wheel reaches its maximum, rocks rain down on your rivals! Bring your unit next to the drum.",
"Acerca tu unidad al tambor": "Bring your unit next to the drum",
"Ahí está, bien pegadito. Si el rival trae a un colega, será empate y no puntuará nadie. Como en las mejores reuniones de familia.": "There it is, nice and close. If the rival brings a buddy, it'll be a tie and nobody scores. Like at the best family gatherings.",
"Hay un truco para que los tambores suenen más deprisa: cada golpe que des a un gnomo estando pegado a un tambor suma una porción extra. Tinkle viene justo hacia aquí, con la ilusión de siempre. Cógelo.": "There's a trick to make the drums sound faster: every hit you give a gnome while next to a drum adds an extra slice. Tinkle is coming right here, with his usual enthusiasm. Pick him up.",
"Tinkle, esta vez haz de baquetas. Mejor no te explico lo que significa.": "Tinkle, this time you're the drumsticks. I'd better not explain what that means.",
"Ahora golpéalo, con el puño, mientras sigues pegado al tambor. Cada golpe hace retumbar el cuero y deja pendiente una porción más para el final de tu turno.": "Now hit him, with your fist, while you stay next to the drum. Each hit makes the drumskin boom and leaves one more slice pending for the end of your turn.",
"Golpea a Tinkle junto al tambor": "Hit Tinkle next to the drum",
"¡Rum-pum-pum! Y Tinkle ha puesto el compás. Qué talento desaprovechado.": "Rum-pum-pum! And Tinkle has set the beat. What wasted talent.",
"Para no hacerte esperar, he dejado tu ruleta casi llena: con la porción del tambor y la del golpe, al acabar el turno se completa. También he puesto a un rival ahí cerquita, para que vea el espectáculo de cerca. Pulsa PASAR TURNO.": "So you don't have to wait, I've left your wheel almost full: with the drum's slice and the hit's slice, it completes at the end of the turn. I've also put a rival right nearby, so he can see the show up close. Press END TURN.",
"Pasa turno y mira la lluvia de rocas": "End turn and watch the rock rain",
"¡Lluvia de rocas! La primera hace 2 de daño y sube 1 cada vez que la consigues. Y fíjate: los tambores, avergonzados, se han mudado a otro sitio.": "Rock rain! The first one deals 2 damage and goes up by 1 each time you pull it off. And look: the drums, embarrassed, have moved somewhere else.",
"Cada roca que cae se rompe y suelta Fragmentos. Se recogen al pisarlos: van a tu mochila y se apilan. Cualquier bando puede cogerlos, así que date prisa antes de que se los lleve el rival. Te he dejado unos cuantos cerca. Pisa uno.": "Every rock that falls breaks and drops Fragments. You collect them by stepping on them: they go into your backpack and stack up. Any side can pick them up, so hurry before the rival takes them. I've left a few nearby. Step on one.",
"Recoge un fragmento": "Pick up a fragment",
"Una piedra en la mochila. Como tu carrera, pero más útil.": "A stone in the backpack. Like your career, but more useful.",
"Las piedras valen para tres cosas, y NUNCA contra unidades rivales: alimentar al volcán (+1), apagar una casilla de lava y quitar un gnomo en llamas agarrado a una de tus unidades. Puedes lanzar todas las que tengas, sin límite por turno. Abre la mochila, pulsa el fragmento dos veces (una elige, otra lo usa) y apunta al volcán, el de ahí enfrente.": "Stones are good for three things, and NEVER against enemy units: feeding the volcano (+1), putting out a lava tile, and removing a burning gnome clinging to one of your units. You can throw as many as you have, no limit per turn. Open the backpack, press the fragment twice (once to pick, once to use it) and aim at the volcano, the one right there.",
"Lanza el fragmento al volcán": "Throw the fragment at the volcano",
"El volcán ha subido a 10 y se ha encendido. Desde 10 está «encendido»; a 20, entra en erupción. No hace falta que lo mires con esa cara de interés.": "The volcano rose to 10 and lit up. From 10 it's «lit»; at 20, it erupts. No need to look so interested.",
"El volcán también se alimenta de gnomos, estampados o lanzados: suman sus puntos. Al llegar a 20 entra en erupción y suelta un gnomo en llamas por cada unidad rival, que corre hasta ella y se le agarra. Al acabar tu turno el gnomo explota: -1 de vida y lava en las casillas de alrededor. Tinkle ya trae 10 puntos de casa. Estámpalo contra el volcán. Y de paso, tienes a un rival justo para la ocasión.": "The volcano also feeds on gnomes, smashed or thrown: they add their points. At 20 it erupts and releases a burning gnome for every enemy unit, which runs to it and clings on. At the end of your turn the gnome explodes: -1 health and lava on the surrounding tiles. Tinkle already brings 10 points from home. Smash him against the volcano. And by the way, there's a rival right there for the occasion.",
"Estampa a Tinkle contra el volcán": "Smash Tinkle against the volcano",
"¡Erupción! Mira cómo corre ese gnomo en llamas hacia el pobre desgraciado. La vida del rival es dura.": "Eruption! Look at that burning gnome run toward the poor wretch. A rival's life is hard.",
"Pasa turno: el gnomo en llamas explotará y dejará lava, que quita 1 de vida por pisada hasta que desaparece. Una piedra puede apagar una casilla antes, o librar a una de tus unidades del gnomo en llamas antes de que estalle.": "End your turn: the burning gnome will explode and leave lava, which takes 1 health per step until it disappears. A stone can put out a tile earlier, or free one of your units from the burning gnome before it blows.",
"Pasa turno y mira la explosión": "End turn and watch the explosion",
"Lava por todas partes. Hogar, dulce hogar... de los trols.": "Lava everywhere. Home, sweet home... of the trolls.",
"Y eso es todo de las Colinas Rock'n Troll. Resumen: pega gnomos junto a los tambores para que llueva roca, recoge los fragmentos antes que el rival y úsalos con cabeza: al volcán, a la lava o contra un gnomo en llamas. Cuando alguien llegue a 20 en el volcán, prepárate: o corres, o te agarras a una piedra. ¡Suerte, la vas a necesitar!": "And that's all for the Rock'n Troll Hills. Summary: hit gnomes next to the drums to make rocks rain, collect the fragments before the rival does and use them wisely: on the volcano, on lava or against a burning gnome. When someone reaches 20 on the volcano, get ready: either you run, or you grab a stone. Good luck, you'll need it!",
"Primeros pasos": "First steps",
"Lo básico: reclutar, mover, gnomos y combate": "The basics: recruiting, moving, gnomes and combat",
"Tutorial Bosque MushBoom": "MushBoom Forest Tutorial",
"Setas explosivas, Altar de Sacrificios y GnomOgro": "Explosive mushrooms, Sacrifice Altar and GnomOgre",
"Tutorial Colinas Rock'n Troll": "Rock'n Troll Hills Tutorial",
"Tambores de Guerra, fragmentos y Volcán": "War Drums, fragments and Volcano",
"Tutorial": "Tutorial",
};

(function () {
  const norm = (s) => s.replace(/\s+/g, " ").trim();
  const exact = new Map();
  const patterns = [];
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  Object.keys(EN_DICT).forEach((k) => {
    const en = EN_DICT[k];
    if (/\{\d+\}/.test(k)) {
      const order = [];
      const src = esc(norm(k)).replace(/\\\{(\d+)\\\}/g, (m, n) => {
        order.push(+n);
        return "(.+?)";
      });
      patterns.push({ re: new RegExp("^" + src + "$"), order, en, len: k.length });
    } else exact.set(norm(k), en);
  });
  patterns.sort((a, b) => b.len - a.len);

  function tr(text) {
    if (!text || typeof text !== "string") return text;
    const m = text.match(/^(\s*)([\s\S]*?)(\s*)$/);
    const core = norm(m[2]);
    if (!core) return text;
    let out = exact.get(core);
    if (out === undefined) {
      for (const p of patterns) {
        const r = p.re.exec(core);
        if (!r) continue;
        out = p.en.replace(/\{(\d+)\}/g, (x, n) => {
          const idx = p.order.indexOf(+n);
          const v = idx >= 0 ? r[idx + 1] : "";
          return tr(v);
        });
        break;
      }
    }
    if (out === undefined) {
      // Listas de nombres unidas con " o " / " y " (p. ej. requisitos de habilidades).
      for (const [sep, en] of [[" o ", " or "], [" y ", " and "]]) {
        if (!core.includes(sep)) continue;
        const parts = core.split(sep).map((x) => tr(x));
        if (parts.every((x, i) => x !== core.split(sep)[i])) {
          out = parts.join(en);
          break;
        }
      }
    }
    return out === undefined ? text : m[1] + out + m[3];
  }

  const ATTRS = ["title", "aria-label", "placeholder", "alt"];
  const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "CODE", "PRE"]);
  const textMem = new WeakMap(); // nodo -> { orig, out }
  const attrMem = new WeakMap(); // elemento -> { attr: { orig, out } }
  let observer = null;
  const isEn = () => I18N.currentLang === "en";

  function doText(node) {
    const v = node.nodeValue;
    const rec = textMem.get(node);
    if (rec && v === rec.out) return;
    const out = tr(v);
    if (out !== v) {
      textMem.set(node, { orig: v, out });
      node.nodeValue = out;
    }
  }
  function doAttrs(el) {
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const v = el.getAttribute(a);
      const mem = attrMem.get(el) || {};
      if (mem[a] && v === mem[a].out) continue;
      const out = tr(v);
      if (out !== v) {
        mem[a] = { orig: v, out };
        attrMem.set(el, mem);
        el.setAttribute(a, out);
      }
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 || SKIP.has(root.tagName)) return;
    doAttrs(root);
    for (let n = root.firstChild; n; n = n.nextSibling) walk(n);
  }
  function restore(root) {
    if (!root) return;
    if (root.nodeType === 3) {
      const rec = textMem.get(root);
      if (rec && root.nodeValue === rec.out) root.nodeValue = rec.orig;
      textMem.delete(root);
      return;
    }
    if (root.nodeType !== 1) return;
    const mem = attrMem.get(root);
    if (mem) {
      for (const a in mem) if (root.getAttribute(a) === mem[a].out) root.setAttribute(a, mem[a].orig);
      attrMem.delete(root);
    }
    for (let n = root.firstChild; n; n = n.nextSibling) restore(n);
  }

  function start() {
    if (observer) return;
    walk(document.body);
    observer = new MutationObserver((muts) => {
      observer.disconnect();
      muts.forEach((m) => {
        if (m.type === "characterData") doText(m.target);
        else if (m.type === "attributes") doAttrs(m.target);
        else m.addedNodes.forEach(walk);
      });
      connect();
    });
    connect();
  }
  function connect() {
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  function stop() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    restore(document.body);
  }
  function sync() {
    if (isEn()) {
      if (observer) walk(document.body);
      else start();
    } else stop();
  }

  I18N.tr = (t) => (isEn() ? tr(t) : t);
  // Registra una traducción en caliente (lo usa js/tutorial-texts.js / el debug de diálogos).
  I18N.addTr = (es, en) => {
    if (!es || !en || /\{\d+\}/.test(es)) return;
    exact.set(norm(es), en);
  };
  document.addEventListener("gg:langchange", () => setTimeout(sync, 0));
  document.addEventListener("DOMContentLoaded", sync);
})();
