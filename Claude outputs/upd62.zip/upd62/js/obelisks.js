/* Gnomore Gnomes — Obeliscos Ancestrales.
   Regla de oro: un archivo por mecánica. Este archivo SOLO sabe:
     - Colocar UN Obelisco Ancestral por equipo al empezar cada partida (uno
       para "player", otro para "enemy"), más grande y llamativo que un
       tótem neutral (js/villages.js), con el sprite de la raza de su dueño.
     - Pintarlo (sprite + barra de vida de 30 segmentos) y resolver los
       golpes que reciba, reutilizando el mismo salto épico que un tótem
       (Villages._playEpicSmash) — a diferencia de un tótem, NO hace falta
       llevar un gnomo cogido para golpearlo, cualquier ataque cuerpo a
       cuerpo normal sirve, y su daño es la FUERZA del atacante (igual que
       Combat.attack), no los puntos de un gnomo.
     - Si un Obelisco llega a 0 de vida, ese equipo queda ELIMINADO de la
       partida: si con eso solo queda un equipo en pie, ese gana la partida
       (pantalla de victoria/derrota, ver _endGame más abajo).
     - El menú propio de cada Obelisco (solo se abre con un clic del dueño,
       en SU turno, sin necesitar tener ninguna unidad al lado): "Reclutar"
       (comprar una unidad nueva de su raza con Puntos de Gloria y elegir en
       qué loseta adyacente aparece) y "Habilidades" (de momento un simple
       "Próximamente", el propio pedido lo deja para más adelante).
     - Cuántas unidades puede tener cada equipo A LA VEZ sobre el tablero
       ("población"): empieza en 3 y sube +1 por cada tótem que posea ese
       equipo (Villages.ownedCount) — perder un tótem nunca elimina
       unidades ya reclutadas, solo bloquea reclutar una nueva mientras la
       población esté al límite.
     - Una unidad recién reclutada aparece con 1 SOLA acción disponible en
       el turno en el que se recluta (Turns.actionsUsed se deja ya en 1),
       recuperando las 2 normales a partir de su siguiente turno.

   Pedido explícito: "vamos a añadir una nueva mecanica, los Obeliscos
   Ancestrales. cada equipo tiene un obelisco ancestral, es como los
   totems pero mas grande y vistoso...cuando se hace clic en el aparece un
   menu (arriba del obelisco, desaparece al deseleccionar) con la opcion de
   reclutar unidades de dicho equipo, y otro menu de habilidades (este
   ultimo lo definiremos mas adelante)...cada obelisco tiene un indicador de
   poblacion (solo lo ve su propio jugador) iniciado en 3, +1 por cada totem
   capturado, si pierdes un totem no se eliminan las unidades ya
   reclutadas, solo no puedes reclutar mas si estas al limite...el obelisco
   tiene 30 puntos de vida, al llegar a 0 se destruye y ese jugador queda
   eliminado de la partida, cuando solo quede un jugador ese gana...cada
   unidad a reclutar tiene un precio, configurable desde el debug de
   configurar personajes (ver RECRUIT_PRICES/Units.recruitPriceFor en
   js/units.js)...cada equipo empieza en su obelisco sin ninguna unidad
   reclutada todavía, la unidad recién reclutada aparece en una casilla
   adyacente elegida por el jugador, y solo tiene 1 accion en su primer
   turno."

   Se registra como "proveedor de rango" igual que Movement/Combat/Villages/
   Shops (ver cabecera de units.js) para ofrecer la mira de ataque, y como
   oyente de inicio de turno (js/turns.js) para la IA rival (auto-reclutar de
   forma simple) — ninguno de esos archivos sabe que este existe. */

const OBELISK_MAX_HP = 30;
const OBELISK_BASE_POPULATION = 3; // "iniciado en 3"
const OBELISK_ATTACK_RANGE = 1; // cuerpo a cuerpo, igual que Combat/Villages

// Sprite de cada Obelisco según la raza de su dueño — mismas dos razas que
// Villages.VILLAGE_SPRITES (js/villages.js), pero su propio arte "más
// grande y vistoso" (pedido explícito), nunca comparte archivo con un tótem.
const OBELISK_SPRITES = {
  mushboom_forest: "assets/edificios/obelisco_mushboom_forest.png",
  colinas_rockntroll: "assets/edificios/obelisco_colinas_rockntroll.png",
};

// Iconos de los dos botones que asoman sobre el Obelisco al seleccionarlo
// (pedido explícito, imágenes adjuntas) — "respetaremos el tamaño y medidas
// del icono de habilidad especial", ver Abilities._refreshButton/CSS.
const OBELISK_MENU_ICONS = {
  recruit: "assets/iconos/obelisco_reclutar.png",
  abilities: "assets/iconos/obelisco_habilidades.png",
  // Pedido explícito: "Añadimos icono de la armeria...en el obelisco...en
  // esta interfaz con el mismo estilo visual que la de la tienda
  // goblin...el jugador puede aumentar su ataque y aguante base" — ver
  // js/armory.js (Armory.openPopup), un archivo aparte por mecánica.
  armory: "assets/iconos/armeria.png",
};

const Obelisks = {
  list: [],
  _raceIds: { player: null, enemy: null },
  _nextId: 1,
  _selectedId: null, // id del Obelisco PROPIO con el menú abierto ahora mismo, o null
  _targetedIds: [], // mismo patrón que Villages._targetedIds (mira de ataque al alcance)
  _pendingRecruit: null, // { obelisk, typeId, price } mientras se elige loseta de aparición
  _placementMarkers: [],
  gameOver: false,

  // ---------- Popup de reclutar (mismas clases .backpack-* que Shops) ----------
  _overlayEl: null,
  _slotsEl: null,
  _descEl: null,
  _recruitBtnEl: null,
  _activeRecruitObelisk: null,
  _selectedTypeId: null,

  // ---------- Popup de habilidades (placeholder) ----------
  _abilitiesOverlayEl: null,

  // ---------- Pantalla de fin de partida ----------
  _gameOverEl: null,

  // Estadísticas para el resumen comparativo de fin de partida (pedido
  // explícito: "TOTEMS CAPTURADOS, NUMERO DE PASES, MUERTES...ETC") — los
  // totems capturados se leen en vivo de Villages.ownedCount (nunca hace
  // falta llevar la cuenta aparte), pero pases/muertes no viven en ningún
  // sitio todavía, así que se cuentan aquí (Gnome.executePass/
  // Units.removeUnit avisan vía recordPass/recordDeath).
  _passes: { player: 0, enemy: 0 },
  _deaths: { player: 0, enemy: 0 },

  recordPass(team) {
    if (this._passes[team] != null) this._passes[team]++;
  },

  recordDeath(team) {
    if (this._deaths[team] != null) this._deaths[team]++;
  },

  // Se llama junto a Villages.init/Glory.init (newgame-flow.js) — mismo
  // patrón que esos dos: guarda qué raza pinta cada equipo.
  init(playerRaceId, enemyRaceId) {
    this._raceIds = Object.assign({}, Teams.raceIds);
    this.gameOver = false;
    this._initMouseTracking();
  },

  resetAll() {
    this.closeRecruitPopup();
    this.closeAbilitiesPopup();
    this._hideGameOverOverlay();
    this._cancelPlacementMode();
    this.list.forEach((o) => o.el.remove());
    this.list = [];
    this._selectedId = null;
    this._targetedIds = [];
    this.gameOver = false;
    this._passes = Teams.keyed(0);
    this._deaths = Teams.keyed(0);
  },

  at(row, col) {
    return this.list.find((o) => o.row === row && o.col === col) || null;
  },

  byTeam(team) {
    return this.list.find((o) => o.team === team) || null;
  },

  spriteFor(raceId) {
    return OBELISK_SPRITES[raceId] || OBELISK_SPRITES.mushboom_forest;
  },

  // "iniciado en 3, +1 por cada totem capturado" — se recalcula siempre en
  // vivo a partir de Villages.ownedCount (nunca se "descuenta" nada al
  // perder un tótem: si baja, simplemente deja de sumar, ver cabecera).
  populationFor(team) {
    const owned = typeof Villages !== "undefined" ? Villages.ownedCount(team) : 0;
    return OBELISK_BASE_POPULATION + owned + (typeof Skills !== "undefined" ? Skills.rank(team, "refuerzos") : 0);
  },

  // Población EN USO ahora mismo — con el roster inicial vacío (pedido
  // explícito: "cada equipo empieza sin ninguna unidad reclutada"), toda
  // unidad de `team` sobre el tablero es, por definición, una reclutada
  // desde su Obelisco, así que basta con contar Units.list.
  recruitedCountFor(team) {
    return typeof Units !== "undefined" ? Units.list.filter((u) => u.team === team).length : 0;
  },

  // Pedido explícito: "ningun jugador debe aparecer en el centro del mapa,
  // siempre en las esquinas del mismo" — antes el jugador arrancaba cerca
  // del centro exacto y el rival simplemente "lo más lejos posible"
  // (podía caer en cualquier punto, no necesariamente una esquina). Ahora
  // ambos arrancan siempre cerca de una esquina del mapa.
  //
  // CORRECCIÓN (pedido explícito, pasada posterior): "el rival puede
  // aparecer en cualquiera de las otras 3 esquinas restantes a donde
  // apareces en la partida, no siempre tiene porque ser en la opuesta" —
  // antes SIEMPRE se elegía la pareja en diagonal (máxima separación
  // posible), así que el rival caía siempre en la esquina opuesta al
  // jugador. Ahora el jugador se lleva una esquina al azar de las 4 y el
  // rival, por separado, una al azar de las 3 que quedan libres — la
  // opuesta sigue siendo una posibilidad (1 entre 3), pero ya no la única.
  _cornerInset(size) {
    // Mismo cálculo que CORNER_INSET en generateMap (js/mapgen.js), que es
    // quien garantiza esa zona libre de agua — deben coincidir.
    return Math.min(3, Math.max(1, Math.floor(size / 8)));
  },

  _corners(size) {
    const inset = this._cornerInset(size);
    return [
      { row: inset, col: inset }, // arriba-izquierda
      { row: inset, col: size - 1 - inset }, // arriba-derecha
      { row: size - 1 - inset, col: inset }, // abajo-izquierda
      { row: size - 1 - inset, col: size - 1 - inset }, // abajo-derecha
    ];
  },

  _pickCorners(size) {
    const corners = this._corners(size);
    // Baraja las 4 esquinas: el jugador y cada rival toman una distinta.
    for (let i = corners.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [corners[i], corners[j]] = [corners[j], corners[i]];
    }
    return corners;
  },

  // Coloca los DOS Obeliscos, cada uno cerca de una esquina distinta (la
  // loseta libre más próxima a esa esquina, buscando en espiral igual que
  // Gnome.spawnNear).
  spawn(size, playerRaceId, enemyRaceId) {
    const corners = this._pickCorners(size);
    Teams.all.forEach((team, i) => {
      const spot = this._findFreeTileNear(corners[i].row, corners[i].col, size);
      if (spot) this._create(team, spot.row, spot.col, Teams.raceIds[team]);
    });
  },

  _tileFree(row, col) {
    if (typeof TerrainMap !== "undefined" && !TerrainMap.isWalkable(row, col)) return false;
    if (typeof Units !== "undefined" && Units.unitAt(row, col)) return false;
    if (typeof Gnome !== "undefined" && Gnome.isAt(row, col)) return false;
    if (typeof Villages !== "undefined" && Villages.at(row, col)) return false;
    if (typeof Shops !== "undefined" && Shops.at(row, col)) return false;
    if (this.at(row, col)) return false;
    return true;
  },

  // Espiral saliente desde (row, col) hasta encontrar la primera loseta
  // libre — mismo patrón que GnomeInstance.spawnNear (gnome.js).
  // Pedido explícito: "tiene que ser una zona donde todas las casillas
  // adyacentes estén disponibles para poder reclutar" — primero se busca una
  // loseta con sus 8 vecinas libres y dentro del mapa; si no existe ninguna,
  // se cae al comportamiento de antes.
  isAdjacent(row, col) {
    return this.list.some((o) => Math.max(Math.abs(o.row - row), Math.abs(o.col - col)) <= 1);
  },

  _hasFreeRing(row, col, size) {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const r = row + dr, c = col + dc;
        if (r < 0 || c < 0 || r >= size || c >= size) return false;
        if (!this._tileFree(r, c)) return false;
      }
    }
    return true;
  },

  _findFreeTileNear(row, col, size) {
    return this._findFreeTileNearImpl(row, col, size, true) || this._findFreeTileNearImpl(row, col, size, false);
  },

  _findFreeTileNearImpl(row, col, size, ring) {
    const ok = (r, c) => this._tileFree(r, c) && (!ring || this._hasFreeRing(r, c, size));
    if (ok(row, col)) return { row, col };
    for (let radius = 1; radius <= size; radius++) {
      for (let dr = -radius; dr <= radius; dr++) {
        for (let dc = -radius; dc <= radius; dc++) {
          const r = row + dr;
          const c = col + dc;
          if (r < 0 || c < 0 || r >= size || c >= size) continue;
          if (ok(r, c)) return { row: r, col: c };
        }
      }
    }
    return null;
  },

  _create(team, row, col, raceId) {
    // Reutiliza "unit" solo por el posicionamiento base, igual que
    // Villages/Shops — nunca entra en Units.list.
    const el = document.createElement("div");
    el.className = `unit obelisk ${Teams.cls("obelisk", team).join(" ")} ${Teams.variantClass(team)}`.trim();

    const spriteEl = document.createElement("img");
    spriteEl.decoding = "async"; // pedido de rendimiento: no bloquear el hilo principal decodificando
    spriteEl.className = "obelisk__sprite";
    // Calidad de sprite dinámica según el zoom (pedido explícito, ver
    // js/spritequality.js) — el Obelisco propio siempre está percibido
    // (ver Fog._recomputePerception), así que esto solo importa cuando la
    // cámara se aleja lo bastante como para verlo pequeño en pantalla.
    if (typeof SpriteQuality !== "undefined") SpriteQuality.register(spriteEl, this.spriteFor(raceId));
    else spriteEl.src = this.spriteFor(raceId);
    spriteEl.alt = "";
    spriteEl.draggable = false;
    el.appendChild(spriteEl);
    if (typeof Shadows !== "undefined") Shadows.attach(spriteEl);

    // Pedido explícito: "si hago clic en la parte baja del obelisco,
    // deberia dejarme seleccionarlo. se hace transparente cuando hay un
    // personaje/enemigo detras y no me deja hacerlo. pueden coexistir
    // ambas cosas?" — .obelisk--occluding pone pointer-events:none en TODO
    // el .obelisk para que los clics atraviesen hasta la unidad escondida
    // (ver esa regla en style.css), pero eso también bloqueaba clicar el
    // propio obelisco por su base, que casi nunca tapa a nadie (la unidad
    // se esconde detrás de la parte ALTA/tallada, no de la peana). Esta
    // franja invisible cubre solo el tramo inferior del sprite, por
    // encima de él en z-index, con pointer-events:auto explícito — un
    // valor propio en un hijo siempre gana al "none" heredado del
    // contenedor (ver .obelisk__base-hit en style.css), así que sigue
    // pudiendo pulsarse (y el clic sigue burbujeando hasta el listener de
    // `el` de más abajo, sin tocarlo) aunque el resto del obelisco esté
    // atravesándose por la transparencia.
    const baseHitEl = document.createElement("div");
    baseHitEl.className = "obelisk__base-hit";
    el.appendChild(baseHitEl);

    // Barra de vida — mismas piezas que Units.updateHpBar espera, 30
    // segmentos (VILLAGE_MAX_HP tenía 10; el marco/segmentos se encogen por
    // CSS para que quepan sin desbordar, ver .obelisk .unit__hpbar).
    const hpBarEl = document.createElement("div");
    hpBarEl.className = "unit__hpbar obelisk__hpbar";
    const hpSegmentEls = [];
    for (let i = 0; i < OBELISK_MAX_HP; i++) {
      const seg = document.createElement("div");
      seg.className = "unit__hpbar-segment";
      hpBarEl.appendChild(seg);
      hpSegmentEls.push(seg);
    }
    el.appendChild(hpBarEl);

    // Indicador de población — SOLO existe/se pinta para el equipo "player"
    // (pedido explícito: "solo lo ve su propio jugador"); el del rival ni
    // siquiera se crea, así nunca hay riesgo de que un cambio de CSS futuro
    // lo deje visible sin querer.
    let popEl = null;
    let popLabelEl = null;
    if (team === "player") {
      popEl = document.createElement("div");
      popEl.className = "obelisk__pop-badge";
      // Pedido explícito: "el cuadro irregular esta contenido dentro de
      // una mascara, esto no debe ser asi, debe ser como el resto de
      // elementos similares de la interfaz" — el recorte con clip-path
      // directo sobre el propio elemento (borde + drop-shadow encima de
      // una forma ya recortada) es justo el patrón que en TODo el resto
      // del HUD se evita a propósito (ver .shop-restock-msg/.ui-hint en
      // style.css): doble capa ::before (contorno)/::after (relleno)
      // recortadas con clip-path, y el CONTENIDO en un hijo aparte con
      // z-index propio para quedar por encima de las dos. Aquí van dos
      // hijos: el icono y la etiqueta con el número.
      const iconEl = document.createElement("i");
      iconEl.className = "ph-fill ph-user obelisk__pop-badge-icon";
      popEl.appendChild(iconEl);
      popLabelEl = document.createElement("span");
      popLabelEl.className = "obelisk__pop-badge-label";
      popEl.appendChild(popLabelEl);
      el.appendChild(popEl);
      // Pedido explícito: "si se hace mouseover debe indicar 'Población'"
      // — mismo mecanismo que ya usan Gnome._hitBtn/_passBtn (js/gnome.js)
      // y el botón de habilidad (js/abilities.js): Tooltip.attach.
      if (typeof Tooltip !== "undefined") Tooltip.attach(popEl, "Población");
    }

    // Los dos iconos de menú (reclutar/habilidades) — "aparecen arriba del
    // obelisco al seleccionarlo, desaparecen al deseleccionar" (pedido
    // explícito); viven siempre en el DOM, su visibilidad la decide
    // "obelisk--selected" en el propio `el` (ver CSS), nunca se crean/
    // destruyen en cada clic.
    const menuEl = document.createElement("div");
    menuEl.className = "obelisk__menu";

    const recruitBtn = document.createElement("button");
    recruitBtn.className = "obelisk__menu-btn obelisk__menu-btn--recruit";
    recruitBtn.setAttribute("aria-label", "Reclutar");
    recruitBtn.innerHTML = `<img src="${OBELISK_MENU_ICONS.recruit}" class="obelisk__menu-icon" alt="">`;
    recruitBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.openRecruitPopup(obelisk);
    });
    // Pedido explícito: "al pasar el raton por los iconos de RECLUTAR,
    // HABILIDADES, ARMERIA los nombres saliesen arriba de cada icono" —
    // mismo módulo/patrón ya usado en el resto del proyecto (ver el badge
    // de población un poco más abajo, o el botón de habilidad especial en
    // js/abilities.js): Tooltip.attach ya posiciona la etiqueta junto al
    // cursor en escritorio y ARRIBA del dedo en móvil (mantener pulsado),
    // así que basta con enchufar cada botón, sin reinventar nada.
    if (typeof Tooltip !== "undefined") Tooltip.attach(recruitBtn, "Reclutar");
    menuEl.appendChild(recruitBtn);

    const abilitiesBtn = document.createElement("button");
    abilitiesBtn.className = "obelisk__menu-btn obelisk__menu-btn--abilities";
    abilitiesBtn.setAttribute("aria-label", "Habilidades");
    abilitiesBtn.innerHTML = `<img src="${OBELISK_MENU_ICONS.abilities}" class="obelisk__menu-icon" alt="">`;
    abilitiesBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.openAbilitiesPopup(obelisk);
    });
    if (typeof Tooltip !== "undefined") Tooltip.attach(abilitiesBtn, "Habilidades");
    menuEl.appendChild(abilitiesBtn);

    const armoryBtn = document.createElement("button");
    armoryBtn.className = "obelisk__menu-btn obelisk__menu-btn--armory";
    armoryBtn.setAttribute("aria-label", "Armería");
    armoryBtn.innerHTML = `<img src="${OBELISK_MENU_ICONS.armory}" class="obelisk__menu-icon" alt="">`;
    armoryBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (typeof Armory !== "undefined") Armory.openPopup(obelisk);
    });
    if (typeof Tooltip !== "undefined") Tooltip.attach(armoryBtn, "Armería");
    menuEl.appendChild(armoryBtn);

    el.appendChild(menuEl);

    // Clic sobre el propio sprite: ataca directamente si está marcado como
    // objetivo (mismo patrón que Villages._create), o si no, y es el dueño
    // en su propio turno, abre/cierra su menú — sin exigir ninguna unidad
    // adyacente (a propósito: un equipo con 0 unidades en juego tiene que
    // poder reclutar la primera desde cero, ver cabecera del archivo).
    el.addEventListener("click", (e) => {
      if (el.classList.contains("obelisk--targeted") && typeof Units !== "undefined" && Units.selectedId) {
        e.stopPropagation();
        const attacker = Units.list.find((u) => u.id === Units.selectedId);
        if (attacker) this.approachAndAttack(attacker, obelisk);
        return;
      }
      if (this.gameOver) return;
      if (obelisk.team !== "player") return; // solo se "abre" el propio, nunca el del rival
      // Pulsar el Obelisco propio centra la vista en él (todo lo que permita la cámara).
      if (typeof BoardView !== "undefined" && typeof getTileCenter === "function" && typeof Units !== "undefined") {
        const c = getTileCenter(obelisk.row, obelisk.col, Units.boardSize);
        BoardView.panToContentPoint(c.x, c.y);
      }
      if (typeof Turns !== "undefined" && Turns.activeTeam !== obelisk.team) return;
      e.stopPropagation();
      this.toggleSelect(obelisk);
    });

    if (typeof Units !== "undefined") Units.container.appendChild(el);

    const obelisk = {
      id: `obelisk-${this._nextId++}`,
      team,
      raceId,
      row,
      col,
      hp: OBELISK_MAX_HP,
      maxHp: OBELISK_MAX_HP,
      el,
      spriteEl,
      hpBarEl,
      hpSegmentEls,
      popEl,
      popLabelEl,
      menuEl,
    };
    this._placeInstant(obelisk);
    if (typeof Units !== "undefined") Units.updateHpBar(obelisk);
    this.list.push(obelisk);
    this._refreshEmptyPulse(obelisk);
    this._refreshPopBadge(obelisk);
    return obelisk;
  },

  _placeInstant(obelisk) {
    if (typeof getTileCenter === "undefined" || typeof Units === "undefined") return;
    const { x, y } = getTileCenter(obelisk.row, obelisk.col, Units.boardSize);
    obelisk.el.style.left = `${x}px`;
    obelisk.el.style.top = `${y}px`;
    obelisk.el.style.zIndex = String((obelisk.row + obelisk.col) * 10 + 5);
  },

  // ---------- Ocultar personajes propios/rivales escondidos detrás de un
  // Obelisco (mismo mecanismo que Villages.refreshOcclusion, js/villages.js
  // — pedido explícito: "cuando un personaje esta detras de un obelisco,
  // este debe hacerse transparente al igual que ocurre con los totems").
  // Los tótems ya funcionan para AMBOS equipos, no solo el propio (ver la
  // nota "v3" en Villages.refreshOcclusion: cualquier unidad ya VISIBLE
  // cuenta, sea aliada o rival, para poder interactuar con ella igual —
  // seleccionarla o atacarla) — aquí se replica exactamente ese mismo
  // criterio, sin distinción de equipo. ----------
  _lastMouseX: null,
  _lastMouseY: null,
  _mouseTrackingReady: false,
  _initMouseTracking() {
    if (this._mouseTrackingReady) return;
    this._mouseTrackingReady = true;
    window.addEventListener("mousemove", (e) => {
      this._lastMouseX = e.clientX;
      this._lastMouseY = e.clientY;
      this.refreshOcclusion(e.clientX, e.clientY);
    });
    // Pedido explícito: "el obelisco y los totems han dejado de ponerse
    // transparentes para permitir seleccionar un personaje que este detras
    // de ellos" — este mecanismo dependía SOLO de "mousemove", que un
    // móvil nunca dispara al tocar (no hay "ratón sobrevolando"). Antes
    // colaba porque, sin ningún listener de touchstart registrado, iOS/
    // Android generan eventos de ratón "de compatibilidad" tras cada
    // toque — pero el arreglo del doble-toque (ver el touchstart vacío en
    // index.html) cambió esa heurística y esos eventos sintéticos dejaron
    // de llegar. Arreglo: alimentar refreshOcclusion también con las
    // coordenadas reales del dedo.
    const handleTouch = (e) => {
      const t = e.touches && e.touches[0];
      if (!t) return;
      this._lastMouseX = t.clientX;
      this._lastMouseY = t.clientY;
      this.refreshOcclusion(t.clientX, t.clientY);
    };
    window.addEventListener("touchstart", handleTouch, { passive: true });
    window.addEventListener("touchmove", handleTouch, { passive: true });
  },

  // Pedido explícito (v2): "la transparencia tambien funciona cuando el
  // personaje esta en la casilla de arriba a la derecha adyacente y arriba
  // a la izquierda adyacente y arriba 2 casillas del propio totem/
  // obelisco, ya que se solapa sobre los personajes" — mismas 4 casillas
  // que Villages._OCCLUSION_OFFSETS (js/villages.js) y Fog.
  // _UP_NEIGHBOR_OFFSETS (js/fog.js) para el mismo problema geométrico: un
  // Obelisco es más ancho/alto que su propia loseta.
  _OCCLUSION_OFFSETS: [
    [-1, -1],
    [-1, 0],
    [0, -1],
    [-2, -2],
  ],
  // Pedido explícito: "si una zona seleccionable del terreno o personaje
  // adyacente o algo asi por un objeto o habilidad cae en una casilla de
  // las que hemos nombrado de transparencia de totem u obelisco, este
  // tambien debe comportarse con el sistema de transparencia" — hasta
  // ahora solo una UNIDAD en esas 4 casillas activaba la transparencia al
  // pasar el ratón; ahora cualquier marcador de zona seleccionable
  // (movimiento, ataque, alcance de habilidad/objeto, lanzar/pasar gnomo...
  // TODOS pasan por Units.addMarker, ver js/units.js) que caiga en esas
  // mismas casillas cuenta igual, con la misma lógica de "pasar el ratón
  // por encima para verlo".
  _behindElsFor(obelisk) {
    const els = [];
    // Además de las 4 casillas fijas, cualquier cosa más atrás (menor
    // profundidad fila+columna) cuyo recuadro se solape de verdad con el
    // sprite del Obelisco cuenta como "detrás" (el sprite es muy alto y
    // tapa casillas lejanas).
    const oRect = obelisk.spriteEl ? obelisk.spriteEl.getBoundingClientRect() : null;
    const depth = obelisk.row + obelisk.col;
    const overlapsSprite = (r, c, el) => {
      if (!oRect || r + c >= depth) return false;
      const b = el.getBoundingClientRect();
      const w = Math.min(b.right, oRect.right) - Math.max(b.left, oRect.left);
      const h = Math.min(b.bottom, oRect.bottom) - Math.max(b.top, oRect.top);
      return w > 24 && h > 24;
    };
    Units.list.forEach((unit) => {
      if (!unit.el || unit.el.classList.contains("unit--fog-hidden")) return;
      if (this._OCCLUSION_OFFSETS.some(([dr, dc]) => unit.row === obelisk.row + dr && unit.col === obelisk.col + dc) || overlapsSprite(unit.row, unit.col, unit.el)) {
        els.push(unit.el);
      }
    });
    Units.markerEls.forEach((m) => {
      if (!m || !m.isConnected) return;
      const r = Number(m.dataset.row);
      const c = Number(m.dataset.col);
      if (Number.isNaN(r) || Number.isNaN(c)) return;
      if (this._OCCLUSION_OFFSETS.some(([dr, dc]) => r === obelisk.row + dr && c === obelisk.col + dc) || overlapsSprite(r, c, m)) {
        els.push(m);
      }
    });
    return els;
  },

  refreshOcclusion(mouseX, mouseY) {
    if (typeof Units === "undefined") return;
    const mx = typeof mouseX === "number" ? mouseX : this._lastMouseX;
    const my = typeof mouseY === "number" ? mouseY : this._lastMouseY;
    this.list.forEach((obelisk) => {
      if (!obelisk.spriteEl) return;
      if (obelisk.el.classList.contains("unit--fog-hidden") || mx === null || my === null) {
        obelisk.el.classList.remove("obelisk--occluding");
        return;
      }
      const behindEls = this._behindElsFor(obelisk);
      let occluding = false;
      if (behindEls.length) {
        const oRect = obelisk.spriteEl.getBoundingClientRect();
        const mouseOverObelisk = mx >= oRect.left && mx <= oRect.right && my >= oRect.top && my <= oRect.bottom;
        const mouseOverBehind = behindEls.some((el) => {
          const r = el.getBoundingClientRect();
          return mx >= r.left && mx <= r.right && my >= r.top && my <= r.bottom;
        });
        occluding = mouseOverObelisk || mouseOverBehind;
      }
      obelisk.el.classList.toggle("obelisk--occluding", occluding);
    });
  },

  // ---------- Selección propia (menú reclutar/habilidades) ----------

  toggleSelect(obelisk) {
    if (this._selectedId === obelisk.id) {
      this.deselect();
      return;
    }
    this.select(obelisk);
  },

  select(obelisk) {
    this.deselect();
    if (typeof Units !== "undefined") Units.deselect();
    if (typeof Villages !== "undefined") Villages.deselect();
    SFX.click();
    this._selectedId = obelisk.id;
    obelisk.el.classList.add("obelisk--selected");
    this._refreshPopBadge(obelisk);
  },

  deselect() {
    if (!this._selectedId) return;
    const prev = this.list.find((o) => o.id === this._selectedId);
    if (prev) prev.el.classList.remove("obelisk--selected");
    this._selectedId = null;
  },

  // ---------- Menú del Obelisco (RECLUTAR/HABILIDADES/ARMERÍA) ----------
  // Pedido explícito (primera pasada): "en el modo escritorio cuando el
  // obelisco aparece en la esquina superior los iconos se quedan tan al
  // limite que se cortan...margenes en todas las direcciones...30px?" — se
  // probó reposicionando el menú en JS cada frame de cámara (dx/dy
  // calculados contra los bordes de pantalla) para que nunca se saliera
  // del viewport, sea cual sea el punto del mapa donde esté el Obelisco.
  //
  // Pedido explícito (pasada posterior, RETIRA lo anterior): "la solucion
  // para los iconos de RECLUTAR, Habilidades y armeria no me ha gustado,
  // se desplazan a lugares sin sentido los iconos, deberian tener una
  // posicion fija, el juego deberia dejar moverse un poco mas hacia la
  // periferia del escenario, de manera que ese problema se arreglase
  // solo" — el reposicionamiento dinámico se sentía errático porque
  // recalculaba dx/dy en cada frame según la posición de pantalla actual
  // del Obelisco: al panear la cámara ese desplazamiento cambiaba de
  // continuo, así que el menú "flotaba" en vez de quedarse pegado al
  // Obelisco. Se retira por completo (el menú vuelve a su posición fija de
  // siempre: bottom:100%, centrado, ver .obelisk__menu en style.css) y en
  // su lugar el límite de paneo de la cámara se amplía (ver
  // BoardView._PAN_EXTRA_MARGIN) para que SIEMPRE se pueda alejar
  // cualquier Obelisco lo bastante del borde de pantalla como para que su
  // menú, ya con posición fija, no llegue a cortarse en primer lugar.

  // ---------- Población / pulso de "obelisco vacío" ----------
  // Se llama tras cualquier cambio que pueda afectar a alguno de los dos: un
  // reclutamiento, una baja (ver el hook en Units.removeUnit), perder/ganar
  // un tótem (Villages._capture ya avisa a Glory; aquí basta con refrescar
  // en cada inicio de turno, ver onTurnStart más abajo) o al arrancar la
  // partida.
  refreshAll() {
    this.list.forEach((o) => {
      this._refreshEmptyPulse(o);
      this._refreshPopBadge(o);
    });
  },

  // "el obelisco debe palpitar cuando su equipo tiene 0 unidades reclutadas
  // en juego" — feedback visual nivel Triple A del proyecto (mismo espíritu
  // que end-turn-btn--ready), para que un equipo recién eliminado de
  // unidades sepa de un vistazo que le urge reclutar.
  _refreshEmptyPulse(obelisk) {
    const empty = this.recruitedCountFor(obelisk.team) === 0;
    obelisk.el.classList.toggle("obelisk--empty", empty);
  },

  _refreshPopBadge(obelisk) {
    if (!obelisk.popEl) return; // solo existe para "player" (ver _create)
    const used = this.recruitedCountFor(obelisk.team);
    const max = this.populationFor(obelisk.team);
    // El texto va en popLabelEl, no en popEl directamente (ver _create):
    // popEl ahora solo es el marco de doble capa, con el icono y la
    // etiqueta como hijos.
    if (obelisk.popLabelEl) obelisk.popLabelEl.textContent = `${used} / ${max}`;
  },

  // Pedido explícito: "cuando un jugador cualquiera captura o pierde un
  // totem, automaticamente deben actualizarse todos los marcadores de
  // poblacion de los obeliscos" — lo llama Villages._capture cada vez que
  // un tótem cambia de dueño (conquistado o destruido), para los DOS
  // obeliscos a la vez; _refreshPopBadge ya no hace nada si el obelisco no
  // tiene badge propio (el rival, ver cabecera de ese método), así que
  // recorrer this.list entero es seguro sin comprobación extra.
  refreshAllPopBadges() {
    this.list.forEach((o) => this._refreshPopBadge(o));
  },

  // ---------- Proveedor de rango (mira de ataque) ----------
  // Igual que Villages.showFor, pero SIN exigir llevar un gnomo cogido —
  // cualquier unidad puede atacar un Obelisco rival con un golpe normal.
  showFor(unit) {
    if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return;
    // Un Obelisco SOLO pierde vida por estampadas de gnomo, el GnomOgro o
    // explosiones de seta: sin gnomo cogido no hay mira de ataque.
    if (!(typeof Gnome !== "undefined" && Gnome.list.some((g) => g.heldBy === unit.id))) return;
    this.list.forEach((obelisk, i) => {
      if (obelisk.team === unit.team) return;
      if (typeof Fog !== "undefined" && Fog.isFogged(obelisk.row, obelisk.col)) return;
      const approach = this.findApproachTile(unit, obelisk);
      if (!approach) return;
      // Pedido explícito: "eso son dos acciones" — mismo criterio que
      // Combat.attackableEnemies/Villages.showFor.
      const needsMove = approach.row !== unit.row || approach.col !== unit.col;
      if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return; // mover + estampar = 1 sola acción
      // Pedido explícito: "si un totem o el obelisco esta dentro del rango
      // de movimiento del personaje seleccionado se puede machacar el
      // gnomo contra el, siempre y cuando tenga 2 acciones" — el clic
      // directo sobre el propio Obelisco (ver "obelisk--targeted" más
      // abajo/el listener en _create) SOLO funciona cuando ya está
      // adyacente (dist <= OBELISK_ATTACK_RANGE): si hace falta moverse
      // primero, esta mira es el ÚNICO sitio donde se puede hacer clic. Pero
      // obelisk.el se pinta con z-index (row+col)*10+5 (ver _create) y esta
      // mira, sin alwaysOnTop, se quedaba en (row+col)*10+2 — POR DEBAJO del
      // propio Obelisco en su misma loseta, así que el sprite (260px, mucho
      // más grande que la mira) la tapaba entera y se comía el clic sin
      // hacer nada. alwaysOnTop la sube muy por encima de cualquier loseta.
      Units.addMarker({
        className: "attack-marker obelisk-attack-marker",
        row: obelisk.row,
        col: obelisk.col,
        zOffset: 2,
        delayIndex: i,
        visibleClass: "attack-marker--visible",
        owner: "obelisks",
        alwaysOnTop: true,
        onClick: () => this.approachAndAttack(unit, obelisk),
        buildContent: (marker) => {
          const icon = document.createElement("i");
          icon.className = "ph ph-crosshair-simple attack-marker__icon";
          marker.appendChild(icon);
        },
      });

      const dist = Math.max(Math.abs(obelisk.row - unit.row), Math.abs(obelisk.col - unit.col));
      if (dist <= OBELISK_ATTACK_RANGE) {
        obelisk.el.classList.add("obelisk--targeted");
        this._targetedIds.push(obelisk.id);
      }
    });
  },

  onClear() {
    this._targetedIds.forEach((id) => {
      const obelisk = this.list.find((o) => o.id === id);
      if (obelisk) obelisk.el.classList.remove("obelisk--targeted");
    });
    this._targetedIds = [];
  },

  // Igual que Villages.findApproachTile/Shops.findApproachTile.
  findApproachTile(unit, obelisk) {
    const type = UNIT_TYPES[unit.typeId];
    const moveRange = Units.moveRangeOf(unit);

    const distToObelisk = (row, col) =>
      Math.max(Math.abs(row - obelisk.row), Math.abs(col - obelisk.col));

    if (distToObelisk(unit.row, unit.col) <= OBELISK_ATTACK_RANGE) {
      return { row: unit.row, col: unit.col };
    }

    let best = null;
    let bestDist = Infinity;
    for (let row = 0; row < Units.boardSize; row++) {
      for (let col = 0; col < Units.boardSize; col++) {
        if (row === unit.row && col === unit.col) continue;
        if (distToObelisk(row, col) > OBELISK_ATTACK_RANGE) continue;
        if (Units.unitAt(row, col)) continue;
        if (typeof Gnome !== "undefined" && Gnome.isAt(row, col)) continue;
        if (this.at(row, col)) continue;
        if (typeof Villages !== "undefined" && Villages.at(row, col)) continue;
        if (typeof Shops !== "undefined" && Shops.at(row, col)) continue;
        if ((typeof Resources !== "undefined" && Resources.at(row, col)) || (typeof Drums !== "undefined" && Drums.at(row, col))) continue; // Recursos de escenario (js/resources.js)
        if (typeof TerrainMap !== "undefined" && !(typeof Skills !== "undefined" ? Skills.walkableFor(unit.team, row, col) : TerrainMap.isWalkable(row, col))) continue;
        const moveDist = Math.max(Math.abs(row - unit.row), Math.abs(col - unit.col));
        if (moveDist > moveRange || (typeof Skills !== "undefined" && Skills.moveCost(unit, row, col) > moveRange)) continue;
        if (!Units.pathIsWalkable(unit.row, unit.col, row, col, unit.team)) continue;
        if (moveDist < bestDist) {
          bestDist = moveDist;
          best = { row, col };
        }
      }
    }
    return best;
  },

  async approachAndAttack(unit, obelisk) {
    if (this.gameOver) return;
    Units.clearRangeOverlays();
    const approach = this.findApproachTile(unit, obelisk);
    if (!approach) return;
    if (approach.row !== unit.row || approach.col !== unit.col) {
      // Pedido explícito: "eso son dos acciones" — ver la misma nota en
      // Combat.approachAndAttack.
      if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return;
      const path = Units.stepPath(unit.row, unit.col, approach.row, approach.col);
      await Units.walkPath(unit, path);
      // Embestir (js/skills.js): mover + golpear por una sola acción, 1 vez por turno.
      // acercarse no gasta acción: la gasta la estampada
      if (typeof Fog !== "undefined" && unit.team === "player") Fog.revealForUnit(unit);
    }
    await this.attack(unit, obelisk);
  },

  // Igual que Combat.attack pero contra un Obelisco: por defecto daño =
  // FUERZA del atacante (un Obelisco no exige llevar un gnomo cogido para
  // golpearlo, a diferencia de un tótem, ver cabecera). Reutiliza el mismo
  // salto épico que un tótem (Villages._playEpicSmash) para no duplicar la
  // animación.
  //
  // Pedido explícito: "no se puede atacar, se tiene que descontar sus
  // puntos de vida como ocurre con los tótems, machacando el gnomo" —
  // _playEpicSmash ya destruye CUALQUIER gnomo que lleve encima quien
  // ataca, sea contra un tótem o un Obelisco (busca por unit.id sin
  // distinguir el objetivo, ver esa función en villages.js). Sin este
  // cambio, un portador que atacaba un Obelisco perdía su gnomo igualmente
  // pero solo a cambio de su fuerza — en vez del valor que llevaba
  // acumulado, como sí ocurre correctamente contra un tótem. Ahora, si
  // quien ataca lleva un gnomo cogido, el daño pasa a ser sus PUNTOS
  // acumulados (igual que Villages.attack); sin gnomo cogido, sigue siendo
  // la fuerza del atacante, como siempre.
  async attack(unit, obelisk) {
    if (this.gameOver) return;
    if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return;
    if (obelisk.team === unit.team) return;

    Units.clearRangeOverlays();
    Units.faceTowardsTile(unit, obelisk.row, obelisk.col);

    const carriedGnome = typeof Gnome !== "undefined" ? Gnome.list.find((g) => g.heldBy === unit.id) : null;
    if (!carriedGnome) return; // sin gnomo no hay daño a estructuras
    const attackBonus = typeof Armory !== "undefined" ? Armory.attackBonus(unit.team) : 0;
    const skillBonus = typeof Skills !== "undefined" ? Skills.attackBonus(unit, obelisk, { announce: true }) : 0;
    const damage = carriedGnome.points;
    const wasFullHp = obelisk.hp >= obelisk.maxHp;
    obelisk.hp = Math.max(0, obelisk.hp - damage);
    const oneHitKill = wasFullHp && obelisk.hp <= 0;

    if (typeof Turns !== "undefined") Turns.useAction(unit);
    if (oneHitKill && unit.el) unit.el.classList.remove("unit--exhausted");

    await Villages._playEpicSmash(unit, obelisk, damage, oneHitKill);

    if (oneHitKill && typeof Turns !== "undefined") Turns.refreshExhaustedClass(unit);

    if (obelisk.hp <= 0) {
      await this._destroy(obelisk);
    } else {
      Units.refreshRange(unit);
    }
  },

  // El Obelisco llega a 0: ese equipo queda eliminado de la partida —
  // pedido explícito. Se quita del tablero con el mismo "destello" que
  // Villages/Shops reutilizan (Villages._flashScreen ya sonó dentro de
  // _playEpicSmash si fue un golpe mortal de un solo tiro) y se comprueba
  // si con esto ya solo queda un equipo en pie.
  async _destroy(obelisk) {
    obelisk.el.classList.add("obelisk--destroyed");
    if (typeof SFX !== "undefined") SFX.death();
    await new Promise((resolve) => setTimeout(resolve, 420));
    obelisk.el.remove();
    this.list = this.list.filter((o) => o.id !== obelisk.id);
    this._checkWinLose(obelisk.team);
  },

  // Con el motor actual estrictamente a 2 bandos ("player"/"enemy", ver
  // cabecera de turns.js) basta con mirar si queda solo un Obelisco en pie:
  // ese equipo es el ganador. Escrito para poder crecer el día que haya más
  // de 2 equipos (cuenta cuántos siguen vivos, no asume "el otro" a ciegas).
  _checkWinLose(destroyedTeam) {
    if (this.gameOver) return;
    const alive = Teams.all.filter((team) => this.byTeam(team));
    if (!this.byTeam("player") || alive.length <= 1) {
      this._endGame(this.byTeam("player") && alive.length === 1 ? alive[0] : alive.find((t) => t !== "player") || null);
      return;
    }
    if (destroyedTeam && destroyedTeam !== "player") this._eliminateTeam(destroyedTeam);
  },

  // Un rival sin Obelisco queda eliminado: sus unidades caen y sus tótems
  // vuelven a ser neutrales. La partida continúa con el resto.
  _eliminateTeam(team) {
    Units.list.filter((u) => u.team === team).forEach((u) => Units.removeUnit(u));
    if (typeof Villages !== "undefined") {
      Villages.list.filter((v) => v.owner === team).forEach((v) => {
        v.owner = "neutral";
        v.hp = v.maxHp || v.hp;
        v.el.classList.remove(...Teams.cls("village", team), "team-variant-1", "team-variant-2", "team-variant-3");
        v.el.classList.add("village--neutral");
        if (typeof SpriteQuality !== "undefined") SpriteQuality.register(v.spriteEl, Villages.spriteFor("neutral"));
      });
    }
    if (typeof Turns !== "undefined" && typeof Turns.showBanner === "function") {
      Turns.showBanner("RIVAL " + Teams.rivalIndex(team) + " ELIMINADO");
    }
  },

  _endGame(winnerTeam, reason) {
    this.gameOver = true;
    this.closeRecruitPopup();
    this.closeAbilitiesPopup();
    this._cancelPlacementMode();
    if (typeof Units !== "undefined") Units.deselect();
    if (typeof Turns !== "undefined") Turns.hideButton();
    this._showGameOverOverlay(winnerTeam, reason || "destroyed");
  },

  // Pedido explícito: "de momento habran un maximo de 30 turnos por
  // partida...cuando acaben los turnos el equipo con mas vida en su
  // obelisco gana la partida, en caso de empate se tendran en cuenta
  // tambien el numero de totems conquistados y en caso de empate, la vida
  // de los mismos" — se llama desde Turns.endTurn justo después de subir
  // roundNumber (ver turns.js); si ninguno de los 3 criterios desempata de
  // verdad, es un EMPATE de verdad (winnerTeam = null, ver _showGameOverOverlay).
  checkTurnLimit(roundNumber) {
    if (this.gameOver) return;
    if (roundNumber <= TURNS_MAX_ROUNDS) return;

    const hpOf = (team) => {
      const o = this.byTeam(team);
      return o ? o.hp : 0;
    };
    const totemsOf = (team) => (typeof Villages !== "undefined" ? Villages.ownedCount(team) : 0);
    const totemHpOf = (team) =>
      typeof Villages !== "undefined"
        ? Villages.list.filter((v) => v.owner === team).reduce((sum, v) => sum + v.hp, 0)
        : 0;

    const score = (t) => [hpOf(t), totemsOf(t), totemHpOf(t)];
    const alive = Teams.all.filter((t) => this.byTeam(t));
    let winner = null;
    let best = null;
    let tie = false;
    alive.forEach((t) => {
      const sc = score(t);
      if (!best) { best = { t, sc }; return; }
      let c = 0;
      for (let i = 0; i < sc.length && !c; i++) c = sc[i] - best.sc[i];
      if (c > 0) { best = { t, sc }; tie = false; } else if (c === 0) tie = true;
    });
    if (best && !tie) winner = best.t;
    this._endGame(winner, "turnLimit");
  },

  // Tabla comparativa (pedido explícito: "un popup...resumiendo los datos
  // mas relevantes de la partida comparando un equipo con el otro. (ejemplo:
  // TOTEMS CAPTURADOS, NUMERO DE PASES, MUERTES...ETC)") — se muestra en
  // CUALQUIER final de partida, no solo por límite de turnos, así el
  // jugador siempre ve el mismo resumen sea cual sea el motivo.
  _statsRowsHtml() {
    const rows = [
      ["Vida del Obelisco", (t) => `${Math.max(0, this.byTeam(t)?.hp ?? 0)} / ${this.byTeam(t)?.maxHp ?? OBELISK_MAX_HP}`],
      ["Totems capturados", (t) => (typeof Villages !== "undefined" ? Villages.ownedCount(t) : 0)],
      ["Unidades reclutadas", (t) => this.recruitedCountFor(t)],
      ["Pases de gnomo logrados", (t) => this._passes[t] || 0],
      ["Bajas sufridas", (t) => this._deaths[t] || 0],
    ];
    const cls = (t) => (t === "player" ? "player" : "enemy");
    return rows
      .map(
        ([label, fn]) => `
        <div class="obelisk-gameover-stats__row obelisk-gameover-stats__row--n" style="grid-template-columns: 62px 1fr repeat(${Teams.rivalCount}, 62px)">
          <span class="obelisk-gameover-stats__value obelisk-gameover-stats__value--player">${fn("player")}</span>
          <span class="obelisk-gameover-stats__label">${label}</span>
          ${Teams.ai().map((t) => `<span class="obelisk-gameover-stats__value obelisk-gameover-stats__value--${cls(t)}">${fn(t)}</span>`).join("")}
        </div>`
      )
      .join("");
  },

  _showGameOverOverlay(winnerTeam, reason) {
    if (this._gameOverEl) this._gameOverEl.remove();

    const won = winnerTeam === "player";
    const draw = winnerTeam == null;
    const variantClass = draw ? "obelisk-gameover-panel--draw" : won ? "obelisk-gameover-panel--win" : "obelisk-gameover-panel--lose";
    const icon = draw ? "ph-scales" : won ? "ph-trophy" : "ph-skull";
    // Nombre del equipo ganador (p. ej. "Equipo GuardaBosques") para el título.
    const raceOf = (team) => (typeof RACES !== "undefined" ? RACES.find((r) => r.id === this._raceIds[team]) : null);
    const winRace = draw ? null : raceOf(winnerTeam);
    const winName = winRace ? I18N.t(winRace.nameKey).toUpperCase() : "";
    const teamName = winName.replace(/^EQUIPO\s+/, "");
    const titleHtml = draw
      ? "EMPATE"
      : winName
        ? `<small>GANA EL EQUIPO</small><span class="gameover-team">${teamName}</span>`
        : won ? "¡VICTORIA!" : "DERROTA";
    const tone = winRace ? winRace.titleColor || winRace.color : "";
    let msg;
    if (reason === "turnLimit") {
      msg = draw
        ? `Se acabaron los ${TURNS_MAX_ROUNDS} turnos y todo sigue exactamente igualado.`
        : `Se acabaron los ${TURNS_MAX_ROUNDS} turnos — gana quien más resistió.`;
    } else if (reason === "resigned") {
      msg = I18N.t("mp_resigned");
    } else {
      msg = (won ? (Teams.rivalCount > 1 ? "Has destruido todos los Obeliscos rivales." : "Has destruido el Obelisco Ancestral rival.") : "Tu Obelisco Ancestral ha sido destruido.");
    }

    // Logo del equipo ganador (el de ambos en un empate) y jingle del resultado.
    const logoOf = (team) => {
      const rc = raceOf(team);
      const lv = rc ? { logoImg: rc.iconImg } : null;
      return lv && lv.logoImg ? `<img class="obelisk-gameover-panel__logo" src="${lv.logoImg}" alt="" draggable="false">` : "";
    };
    const logos = draw
      ? `<img class="obelisk-gameover-panel__logo obelisk-gameover-panel__logo--draw" src="assets/niveles/logo_empate.png" alt="" draggable="false">`
      : logoOf(winnerTeam);
    if (typeof SFX !== "undefined") {
      if (draw) SFX.draw && SFX.draw();
      else if (won) SFX.victory && SFX.victory();
      else SFX.defeat && SFX.defeat();
    }

    const overlay = document.createElement("div");
    overlay.className = "obelisk-gameover-overlay";
    overlay.innerHTML = `
      <div class="p5-banner obelisk-gameover-panel ${variantClass}">
        <div class="obelisk-gameover-panel__logos">${logos}</div>
        <i class="ph ${icon} obelisk-gameover-panel__icon"></i>
        ${draw ? "" : `<div class="obelisk-gameover-kicker">${won ? "¡VICTORIA!" : "DERROTA"}</div>`}
        <div class="p5-banner__label obelisk-gameover-panel__title">${titleHtml}</div>
        <div class="obelisk-gameover-panel__msg">${msg}</div>
        <div class="obelisk-gameover-stats">
          <div class="obelisk-gameover-stats__row obelisk-gameover-stats__row--header obelisk-gameover-stats__row--n" style="grid-template-columns: 62px 1fr repeat(${Teams.rivalCount}, 62px)">
            <span class="obelisk-gameover-stats__value obelisk-gameover-stats__value--player">TÚ</span>
            <span class="obelisk-gameover-stats__label"></span>
            ${Teams.ai().map((t) => `<span class="obelisk-gameover-stats__value obelisk-gameover-stats__value--enemy">${Teams.rivalCount > 1 ? "RIVAL " + Teams.rivalIndex(t) : "RIVAL"}</span>`).join("")}
          </div>
          ${this._statsRowsHtml()}
        </div>
        <button type="button" class="p5-banner p5-banner--action obelisk-gameover-panel__btn">
          <span class="p5-banner__label">VOLVER AL MENÚ</span>
        </button>
      </div>
    `;
    overlay.querySelector(".obelisk-gameover-panel__btn").addEventListener("click", () => {
      if (typeof MPLobby !== "undefined") MPLobby.finishMatch(false);
      this._hideGameOverOverlay();
      if (typeof Glory !== "undefined") Glory.hideHud();
      if (typeof SettingsMenu !== "undefined") SettingsMenu.hideButton();
      if (typeof Backpack !== "undefined") Backpack.hideButton();
      if (typeof showScreen === "function") showScreen("main-menu");
      if (typeof screenHistory !== "undefined") {
        screenHistory.length = 0;
        screenHistory.push("main-menu");
      }
    });
    if (tone) overlay.querySelector(".obelisk-gameover-panel").style.setProperty("--go-tone", tone);
    document.body.appendChild(overlay);
    this._gameOverEl = overlay;
    requestAnimationFrame(() => overlay.classList.add("obelisk-gameover-overlay--visible"));
  },

  _hideGameOverOverlay() {
    if (!this._gameOverEl) return;
    const el = this._gameOverEl;
    this._gameOverEl = null;
    el.remove();
  },

  // ---------- Popup de reclutar (mismas clases .backpack-* que Shops) ----------

  openRecruitPopup(obelisk) {
    if (this.gameOver || this._overlayEl) return;
    if (typeof Turns !== "undefined" && Turns.activeTeam !== obelisk.team) return;
    SFX.click();
    this._activeRecruitObelisk = obelisk;
    this._selectedTypeId = null;

    const overlay = document.createElement("div");
    overlay.className = "backpack-overlay";
    overlay.addEventListener("click", () => this.closeRecruitPopup());

    const panel = document.createElement("div");
    panel.className = "backpack-panel";
    panel.addEventListener("click", (e) => e.stopPropagation());

    const panelBg = document.createElement("div");
    panelBg.className = "p5-banner backpack-panel__bg";
    panel.appendChild(panelBg);

    const closeBtn = document.createElement("button");
    closeBtn.className = "backpack-close-btn";
    closeBtn.setAttribute("aria-label", "Cerrar");
    closeBtn.innerHTML = '<i class="ph ph-x backpack-close-btn__icon"></i>';
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.closeRecruitPopup();
    });
    panel.appendChild(closeBtn);

    const title = document.createElement("div");
    title.className = "p5-banner__label backpack-panel__title";
    title.textContent = "RECLUTAR";
    panelBg.appendChild(title);

    const slots = document.createElement("div");
    // Pedido explícito: "La interfaz de reclutar debe ajustar el ancho
    // total del numero de unidades al del texbox donde se muestra la
    // descripcion...si decidimos añadir una nueva se ajustara
    // automaticamente tambien" — a diferencia de la mochila/tienda (rejilla
    // fija de 4 columnas, con huecos vacíos de relleno), aquí NUNCA hay
    // huecos vacíos (un hueco por unidad de la raza, ver _renderRecruitSlots
    // más abajo), así que un modificador propio (ver .backpack-slots--recruit
    // en style.css) cambia a auto-fit: siempre reparte el ancho disponible
    // (el mismo que .backpack-desc, ambos hijos directos de .backpack-panel__bg
    // con align-items:stretch) entre las columnas que hagan falta, ni una
    // fila a medias ni límite fijo si el roster crece.
    slots.className = "backpack-slots backpack-slots--recruit";
    panelBg.appendChild(slots);
    this._slotsEl = slots;

    const desc = document.createElement("div");
    desc.className = "backpack-desc";
    desc.innerHTML = '<p class="backpack-desc__text"></p>';
    panelBg.appendChild(desc);
    this._descEl = desc.querySelector(".backpack-desc__text");

    const recruitBtn = document.createElement("button");
    recruitBtn.className = "p5-banner p5-banner--action shop-buy-btn";
    recruitBtn.innerHTML = '<span class="p5-banner__label">RECLUTAR</span>';
    recruitBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this._confirmRecruit();
    });
    panelBg.appendChild(recruitBtn);
    this._recruitBtnEl = recruitBtn;

    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    this._overlayEl = overlay;

    this._renderRecruitSlots();
    requestAnimationFrame(() => overlay.classList.add("backpack-overlay--visible"));
  },

  closeRecruitPopup() {
    if (!this._overlayEl) return;
    const el = this._overlayEl;
    this._overlayEl = null;
    this._slotsEl = null;
    this._descEl = null;
    this._recruitBtnEl = null;
    this._activeRecruitObelisk = null;
    this._selectedTypeId = null;
    el.classList.remove("backpack-overlay--visible");
    setTimeout(() => el.remove(), 220);
  },

  // Un hueco por tipo de unidad de la raza de este Obelisco — a diferencia
  // de Shops (existencias limitadas que se agotan), aquí siempre hay las
  // mismas opciones disponibles, solo cambia si se puede pagar/hay sitio.
  _renderRecruitSlots() {
    if (!this._slotsEl || !this._activeRecruitObelisk) return;
    const obelisk = this._activeRecruitObelisk;
    const roster = Object.keys(UNIT_TYPES).filter((typeId) => UNIT_TYPES[typeId].raceId === obelisk.raceId);
    this._slotsEl.innerHTML = "";
    roster.forEach((typeId) => {
      const def = UNIT_TYPES[typeId];
      const price = Units.recruitPriceFor(typeId);
      const slotEl = document.createElement("button");
      slotEl.className = "backpack-slot";
      slotEl.innerHTML =
        `<img src="${def.spriteUrl}" class="backpack-slot__icon" alt="${def.name}">` +
        `<span class="shop-slot__price"><span class="shop-slot__price__num">${price}</span></span>`;
      slotEl.classList.toggle("backpack-slot--selected", typeId === this._selectedTypeId);
      // Tutorial (js/tutorial.js): solo TruenoEspora se puede elegir; el
      // resto aparece desactivado.
      const lockedByTutorial = typeof Tutorial !== "undefined" && Tutorial.active && typeId !== "seta_artificiero";
      if (lockedByTutorial) {
        slotEl.disabled = true;
        slotEl.classList.add("backpack-slot--disabled");
      }
      slotEl.addEventListener("click", (e) => {
        e.stopPropagation();
        if (lockedByTutorial) return;
        this._onRecruitSlotClick(typeId);
      });
      this._slotsEl.appendChild(slotEl);
    });
    this._updateRecruitDescAndButton();
  },

  _onRecruitSlotClick(typeId) {
    SFX.click();
    this._selectedTypeId = this._selectedTypeId === typeId ? null : typeId;
    this._renderRecruitSlots();
  },

  _updateRecruitDescAndButton() {
    if (!this._descEl || !this._activeRecruitObelisk) return;
    const obelisk = this._activeRecruitObelisk;
    const typeId = this._selectedTypeId;
    const def = typeId ? UNIT_TYPES[typeId] : null;
    const price = typeId ? Units.recruitPriceFor(typeId) : 0;

    if (def) {
      // Pedido explícito: "el texto de la descripcion...no habla sobre las
      // habilidades de los personajes ni nada...le falta 'chicha'" — antes
      // solo mostraba las estadísticas en crudo. Ahora reutiliza el mismo
      // texto de sabor que ya existe para el popup de información
      // (UNIT_DESCRIPTIONS, js/unitinfo.js) y añade el nombre de la
      // habilidad especial (ABILITIES, js/abilities.js) cuando la tiene, así
      // sí se habla de verdad de sus habilidades antes de reclutarlo.
      const flavor = typeof UNIT_DESCRIPTIONS !== "undefined" ? UNIT_DESCRIPTIONS[typeId] : null;
      const ability = typeof ABILITIES !== "undefined" ? ABILITIES[typeId] : null;
      // Estructura en bloques (rediseño): cabecera nombre + precio, frase de
      // sabor, ficha de estadísticas y, aparte, la habilidad especial.
      const firstSentence = (t) => {
        const m = /^.*?[.!?](\s|$)/.exec(t || "");
        return m ? m[0].trim() : t || "";
      };
      const abilityIcon = ability
        ? ability.iconImg
          ? `<img class="rc__ability-icon" src="${ability.iconImg}" alt="">`
          : `<i class="ph ${ability.icon} rc__ability-icon"></i>`
        : "";
      this._descEl.innerHTML =
        `<div class="rc">` +
        `<div class="rc__head"><strong class="recruit-name rc__name">${def.name}</strong>` +
        `<span class="rc__price" title="Coste de reclutar"><i class="ph ph-trophy"></i><b>${price}</b><span>gloria</span></span></div>` +
        (flavor ? `<p class="rc__flavor">${flavor}</p>` : "") +
        `<div class="unit-info-stats rc__stats">` +
        `${UnitInfo.statRow("ph-shield", "Aguante", def.aguante)}` +
        `${UnitInfo.statRow("ph-footprints", "Movimiento", def.movimiento)}` +
        `${UnitInfo.statRow("ph-boxing-glove", "Fuerza", def.fuerza)}` +
        `${UnitInfo.statRow("ph-wind", "Agilidad", def.agilidad)}` +
        `${UnitInfo.statRow("ph-eye", "Percepción", def.percepcion)}` +
        `</div>` +
        (ability
          ? `<div class="rc__ability">${abilityIcon}<div><b>${ability.name}</b><span>${firstSentence(ability.description)}</span></div></div>`
          : "") +
        `</div>`;
    } else {
      this._descEl.textContent = "";
    }

    if (this._recruitBtnEl) {
      const points = typeof Glory !== "undefined" ? Glory.points[obelisk.team] : 0;
      const canAfford = !!def && points >= price;
      const used = this.recruitedCountFor(obelisk.team);
      const max = this.populationFor(obelisk.team);
      const hasRoom = used < max;
      this._recruitBtnEl.disabled = !def || !canAfford || !hasRoom;
      if (!def) this._recruitBtnEl.title = "";
      else if (!hasRoom) this._recruitBtnEl.title = "Población al límite";
      else if (!canAfford) this._recruitBtnEl.title = "No tienes suficientes Puntos de Gloria";
      else this._recruitBtnEl.title = "";
    }
  },

  // Confirma la elección y pasa al modo "elegir casilla adyacente" — el
  // Glory/población todavía no se gastan aquí (pueden cambiar mientras el
  // jugador elige dónde colocar la unidad si algo más ocurre entre medias),
  // se comprueban y descuentan de verdad al hacer clic en la loseta elegida
  // (ver _spawnRecruit más abajo).
  _confirmRecruit() {
    const obelisk = this._activeRecruitObelisk;
    const typeId = this._selectedTypeId;
    if (!obelisk || !typeId || !this._recruitBtnEl || this._recruitBtnEl.disabled) return;
    const price = Units.recruitPriceFor(typeId);
    this.closeRecruitPopup();
    this._startPlacementMode(obelisk, typeId, price);
  },

  // ---------- Modo "elegir casilla adyacente" para la unidad reclutada ----------

  _startPlacementMode(obelisk, typeId, price) {
    this._cancelPlacementMode();
    this._pendingRecruit = { obelisk, typeId, price };
    if (typeof UiHint !== "undefined") UiHint.show("Elige una casilla para colocar tu nueva unidad");
    const tiles = this._adjacentFreeTiles(obelisk);
    tiles.forEach((tile, i) => {
      const marker = Units.addMarker({
        className: "range-marker obelisk-placement-marker",
        row: tile.row,
        col: tile.col,
        zOffset: 2,
        alwaysOnTop: true,
        delayIndex: i,
        visibleClass: "range-marker--visible",
        onClick: () => this._spawnRecruit(tile.row, tile.col),
      });
      this._placementMarkers.push(marker);
    });
  },

  _cancelPlacementMode() {
    this._placementMarkers.forEach((m) => m.remove());
    this._placementMarkers = [];
    this._pendingRecruit = null;
    if (typeof UiHint !== "undefined") UiHint.hide();
  },

  _adjacentFreeTiles(obelisk) {
    const tiles = [];
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const row = obelisk.row + dr;
        const col = obelisk.col + dc;
        if (row < 0 || col < 0 || row >= Units.boardSize || col >= Units.boardSize) continue;
        if (!this._tileFree(row, col)) continue;
        tiles.push({ row, col });
      }
    }
    return tiles;
  },

  async _spawnRecruit(row, col) {
    const pending = this._pendingRecruit;
    if (!pending) return;
    const { obelisk, typeId, price } = pending;
    // Se reconfirma todo justo antes de gastar nada (pudo cambiar mientras
    // el jugador elegía casilla: otra unidad murió/nació, se gastó gloria
    // en la tienda, etc.) — mismo criterio defensivo que el resto del
    // proyecto (ver Combat.attack, Villages.approachAndAttack).
    const points = typeof Glory !== "undefined" ? Glory.points[obelisk.team] : 0;
    const used = this.recruitedCountFor(obelisk.team);
    const max = this.populationFor(obelisk.team);
    if (points < price || used >= max || !this._tileFree(row, col)) {
      this._cancelPlacementMode();
      return;
    }

    if (typeof Glory !== "undefined") Glory.spend(obelisk.team, price);
    const unit = Units.spawnUnit({ typeId, row, col, team: obelisk.team });
    // Los marcadores de casilla (alwaysOnTop) se quitan YA, no tras esperar a
    // que los gnomos terminen de huir (más abajo): mientras seguían ahí
    // tapaban a la unidad recién reclutada y no dejaban seleccionarla.
    this._cancelPlacementMode();
    // "solo tiene 1 accion en su primer turno en juego" — se deja ya
    // gastada 1 de las TURNS_MAX_ACTIONS (2) de este turno; Turns
    // ._resetTeamActions la devolverá a las 2 normales en su PRÓXIMO turno,
    // sin que este archivo necesite saber nada de esa mecánica.
    if (typeof Turns !== "undefined") {
      Turns.actionsUsed[unit.id] = 1;
      Turns.refreshExhaustedClass(unit);
    }
    // Pedido explícito: "al reclutar a un personaje debe revelarse la
    // niebla alrededor de el teniendo en cuenta su percepcion" y "si hay un
    // gnomo cerca de la base y recluto a un personaje, el gnomo tiene que
    // huir de el...siempre y cuando este dentro de su percepcion" — mismo
    // par de llamadas, mismo orden, que Movement.moveTo ya hace tras
    // cualquier desplazamiento normal (ver ese archivo): un personaje
    // reclutado "aparece" en el tablero igual que si acabara de llegar
    // andando, así que revela y espanta a los gnomos sueltos exactamente
    // igual, aunque nunca haya dado un paso.
    if (typeof Fog !== "undefined") Fog.revealForUnit(unit);
    if (typeof Gnome !== "undefined") await Gnome.reactToPlayerMove(unit);
    SFX.captureVillage();
    this.refreshAll();
  },

  // ---------- Popup de habilidades (placeholder) ----------
  // "este ultimo lo definiremos mas adelante" — pedido explícito: de momento
  // solo un aviso de "Próximamente", mismo lenguaje visual que el resto de
  // popups (.p5-banner) pero sin ninguna interacción real todavía.
  openAbilitiesPopup(obelisk) {
    if (this.gameOver || this._abilitiesOverlayEl) return;
    if (typeof Turns !== "undefined" && Turns.activeTeam !== obelisk.team) return;
    SFX.click();

    // Árbol de habilidades (js/skillsui.js) — sustituye al aviso de
    // "Próximamente" de antes.
    if (typeof SkillsUI !== "undefined") {
      const skillsOverlay = SkillsUI.build(obelisk, () => this.closeAbilitiesPopup());
      document.body.appendChild(skillsOverlay);
      this._abilitiesOverlayEl = skillsOverlay;
      requestAnimationFrame(() => skillsOverlay.classList.add("backpack-overlay--visible"));
      SkillsUI.afterMount();
      return;
    }

    const overlay = document.createElement("div");
    overlay.className = "backpack-overlay";
    overlay.addEventListener("click", () => this.closeAbilitiesPopup());

    const panel = document.createElement("div");
    panel.className = "backpack-panel obelisk-abilities-panel";
    panel.addEventListener("click", (e) => e.stopPropagation());

    const panelBg = document.createElement("div");
    panelBg.className = "p5-banner backpack-panel__bg";
    panel.appendChild(panelBg);

    const closeBtn = document.createElement("button");
    closeBtn.className = "backpack-close-btn";
    closeBtn.setAttribute("aria-label", "Cerrar");
    closeBtn.innerHTML = '<i class="ph ph-x backpack-close-btn__icon"></i>';
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.closeAbilitiesPopup();
    });
    panel.appendChild(closeBtn);

    const title = document.createElement("div");
    title.className = "p5-banner__label backpack-panel__title";
    title.textContent = "HABILIDADES";
    panelBg.appendChild(title);

    const msg = document.createElement("div");
    msg.className = "obelisk-abilities-panel__soon";
    msg.innerHTML = '<i class="ph ph-hourglass-simple"></i><span>Próximamente</span>';
    panelBg.appendChild(msg);

    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    this._abilitiesOverlayEl = overlay;
    requestAnimationFrame(() => overlay.classList.add("backpack-overlay--visible"));
  },

  closeAbilitiesPopup() {
    if (!this._abilitiesOverlayEl) return;
    const el = this._abilitiesOverlayEl;
    this._abilitiesOverlayEl = null;
    if (typeof SkillsUI !== "undefined") SkillsUI.onClose();
    el.classList.remove("backpack-overlay--visible");
    setTimeout(() => el.remove(), 220);
  },

  // ---------- IA rival: auto-reclutar de forma simple ----------
  // Pedido implícito (sin esto la IA rival, ahora sin roster inicial,
  // jamás pondría una sola unidad en juego): en cada inicio de SU turno, si
  // tiene sitio y puntos, recluta al azar UN tipo de unidad que pueda
  // pagar, en una loseta adyacente libre al azar — deliberadamente simple,
  // mismo espíritu que Turns._aiActOnce ("con el tiempo definiremos una IA
  // más compleja").
  onTurnStart(team) {
    if (this.gameOver || team === "player" || (typeof Net !== "undefined" && Net.active)) return; // (en multijugador recluta el humano)
    const obelisk = this.byTeam(team);
    if (!obelisk) return;
    const used = this.recruitedCountFor(team);
    const max = this.populationFor(team);
    if (used >= max) return;
    const points = typeof Glory !== "undefined" ? Glory.points[team] : 0;
    const roster = Object.keys(UNIT_TYPES).filter((typeId) => UNIT_TYPES[typeId].raceId === obelisk.raceId);
    const affordable = roster.filter((typeId) => Units.recruitPriceFor(typeId) <= points);
    if (affordable.length === 0) return;
    const typeId = affordable[Math.floor(Math.random() * affordable.length)];
    const tiles = this._adjacentFreeTiles(obelisk);
    if (tiles.length === 0) return;
    const tile = tiles[Math.floor(Math.random() * tiles.length)];
    const price = Units.recruitPriceFor(typeId);

    if (typeof Glory !== "undefined") Glory.spend(team, price);
    const unit = Units.spawnUnit({ typeId, row: tile.row, col: tile.col, team });
    if (typeof Turns !== "undefined") {
      Turns.actionsUsed[unit.id] = 1;
      Turns.refreshExhaustedClass(unit);
    }
    this.refreshAll();
  },
};

Units.registerRangeProvider(Obelisks);
if (typeof Turns !== "undefined") Turns.registerTurnStartListener(Obelisks);
