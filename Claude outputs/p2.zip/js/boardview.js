/* Gnomore Gnomes — cámara del tablero: zoom (rueda del ratón / pellizco táctil)
   y desplazamiento (arrastrar con ratón o con el dedo), con límites para no
   poder alejarse o desplazarse fuera del escenario.
   Regla de oro: un archivo por mecánica — esto solo controla la cámara del
   tablero, no genera ni pinta las losetas (eso vive en mapgen.js).
   Regla de oro: comodidad e intuitividad de controles en cualquier dispositivo
   (ratón, pantalla táctil) y nivel Triple A en la sensación de manejo.

   La cámara funciona con un valor "objetivo" (target) que se actualiza al
   instante con cada gesto, y un valor "mostrado" que persigue a ese objetivo
   con una pequeña suavización (lerp) en cada frame — así el movimiento de la
   cámara se siente suave y ligeramente "lazy" en vez de saltar de golpe. */

// Desplazamiento con teclado (pedido explícito: "me gustaria que la camara
// pudiera moverse con las flechas del teclado y WASD") — cada tecla apunta
// a la dirección en la que se mueve la CÁMARA (lo que ve el jugador), no el
// contenido: por eso "derecha"/"flecha derecha" resta a panX (el contenido
// se desplaza a la izquierda para revelar lo que hay a la derecha), mismo
// criterio que cualquier editor/juego 2D con desplazamiento de cámara.
// Minúsculas siempre (e.key.toLowerCase()) para que sea indiferente a Bloq
// Mayús. Flechas y WASD comparten exactamente la misma dirección cada una.
const BOARD_PAN_KEYS = {
  arrowup: [0, 1],
  arrowdown: [0, -1],
  arrowleft: [1, 0],
  arrowright: [-1, 0],
  w: [0, 1],
  s: [0, -1],
  a: [1, 0],
  d: [-1, 0],
};

const BoardView = {
  viewportEl: null,
  cameraEl: null,

  // Rango de zoom acotado para que nunca se pueda alejar hasta perder de
  // vista el tablero. El límite superior está calculado a propósito para no
  // pasarse de la resolución real del arte de las losetas: se renderizan a
  // TILE_WIDTH=188px pero el archivo fuente mide 250px de ancho, así que
  // hasta 250/188 ≈ 1.33x todavía hay margen de sobra en la imagen; pasado
  // eso, el navegador tiene que ampliar la imagen más allá de su resolución
  // real y se ve borrosa. 1.3 se queda justo por debajo de ese límite.
  minScale: 0.6,
  maxScale: 1.3,

  // Valores objetivo: a dónde tiene que llegar la cámara.
  targetScale: 1,
  targetPanX: 0,
  targetPanY: 0,

  // Valores mostrados: lo que realmente se pinta, persiguiendo al objetivo.
  scale: 1,
  panX: 0,
  panY: 0,

  // Cuanto más bajo, más "lazy"/suave; cuanto más alto, más directo/inmediato.
  // El zoom usa un valor más bajo que el desplazamiento porque, al ser un
  // cambio de escala mucho más pequeño en números, con el mismo suavizado
  // que el desplazamiento apenas se notaba el "retraso" — así se percibe
  // igual de lazy que arrastrar.
  PAN_EASE: 0.2,
  SCALE_EASE: 0.1,
  SETTLE_EPSILON: 0.02,
  SETTLE_EPSILON_SCALE: 0.0005,

  contentWidth: 0,
  contentHeight: 0,

  // Mientras no sea null, el zoom en curso está "anclado" a un punto fijo del
  // contenido bajo el cursor/dedos (ver _zoomAt): el desplazamiento se deriva
  // de este ancla en cada frame en vez de perseguir su propio objetivo por
  // separado, para que el punto bajo el cursor no se mueva ni un pixel
  // mientras el zoom "alcanza" su valor final (aunque ese alcance sea lazy).
  _zoomAnchor: null,

  _dragState: null,
  _touchState: null,
  _rafId: null,

  // ---------- Desplazamiento con teclado (flechas/WASD) ----------
  // Velocidad en píxeles de PANTALLA por segundo (no de contenido): igual
  // de rápida se mueva la cámara esté como esté el zoom, igual que ya pasa
  // al arrastrar con el ratón (_panBy recibe deltas de pantalla tal cual).
  KEY_PAN_SPEED: 700,
  _keysPressed: null,
  _keyLoopId: null,
  _lastKeyFrameTime: 0,

  init() {
    this.viewportEl = document.getElementById("board-viewport");
    this.cameraEl = document.getElementById("board-camera");
    if (!this.viewportEl || !this.cameraEl) return;
    this._keysPressed = new Set();
    this._bindEvents();
    this._bindKeyboard();
  },

  /* Se llama cada vez que se genera/carga un escenario nuevo, con el tamaño
     real (en px) del contenido a mostrar, para poder centrarlo y calcular
     los límites de desplazamiento y zoom. `focusPoint` opcional ({x, y} en
     coordenadas de contenido, ver getTileCenter en js/mapgen.js) — pedido
     explícito: "al empezar la partida la camara debe centrarse lo maximo
     posible en la base del jugador" — sin él se centra en la mitad
     geométrica del mapa entero como siempre (ver _centerContent). */
  setContent(width, height, focusPoint) {
    this.contentWidth = width;
    this.contentHeight = height;
    this.targetScale = 1;
    this._zoomAnchor = null;
    if (focusPoint) this.centerOnContentPoint(focusPoint.x, focusPoint.y);
    else this._centerContent();
  },

  // Centra el contenido y, a diferencia de un gesto del jugador, lo hace
  // al instante (sin suavizado) para que la pantalla no empiece "flotando".
  _centerContent() {
    if (!this.viewportEl) return;
    const vw = this.viewportEl.clientWidth;
    const vh = this.viewportEl.clientHeight;
    this.targetPanX = (vw - this.contentWidth * this.targetScale) / 2;
    this.targetPanY = (vh - this.contentHeight * this.targetScale) / 2;
    this._clampTargetPan();
    this.scale = this.targetScale;
    this.panX = this.targetPanX;
    this.panY = this.targetPanY;
    this._apply();
  },

  // Mismo centrado instantáneo que _centerContent, pero alrededor de un
  // punto concreto del contenido en vez de su centro geométrico — usado
  // para que la cámara arranque sobre el Obelisco del jugador (ver
  // newgame-flow.js, syncBoardCamera) en vez de la mitad exacta del mapa,
  // ahora que los jugadores arrancan en una esquina (Obelisks.spawn, js/
  // obelisks.js) y no cerca del centro. Sigue pasando por _clampTargetPan:
  // si el punto está pegado a un borde/esquina del mapa la cámara se queda
  // lo más cerca posible sin salirse del contenido — el "lo maximo
  // posible" del propio pedido, no siempre cabe un centrado exacto.
  centerOnContentPoint(contentX, contentY) {
    if (!this.viewportEl) return;
    const vw = this.viewportEl.clientWidth;
    const vh = this.viewportEl.clientHeight;
    this.targetPanX = vw / 2 - contentX * this.targetScale;
    this.targetPanY = vh / 2 - contentY * this.targetScale;
    this._clampTargetPan();
    this.scale = this.targetScale;
    this.panX = this.targetPanX;
    this.panY = this.targetPanY;
    this._apply();
  },

  _clampScale(scale) {
    return Math.min(this.maxScale, Math.max(this.minScale, scale));
  },

  // Límites de desplazamiento para una escala dada (no necesariamente la
  // mostrada ni la objetivo — el ancla de zoom los necesita para cualquier
  // escala intermedia mientras el zoom "alcanza" su valor final).
  //
  // HISTORIAL (dos intentos fallidos, por si se retoma esto): "cuando la
  // ventana del navegador no esta en modo maximizado hay errores graficos"
  // resultó ser que el tablero, en isométrico, es un rombo inscrito en el
  // rectángulo que lo envuelve (contentWidth x contentHeight) — toca cada
  // lado del rectángulo solo en su punto medio, así que las 4 ESQUINAS del
  // rectángulo quedan siempre fuera del rombo, sin loseta que pintar ahí, y
  // el fondo oscuro de body se veía como un hueco negro en cuanto la cámara
  // alcanzaba a cubrir una de esas esquinas (en cualquier tamaño de
  // ventana, con una más pequeña hace falta desplazar menos para llegar).
  // El primer intento (_clampPanForDiamond, ya retirado) recortaba el
  // desplazamiento con matemática exacta para que las 4 esquinas del
  // VIEWPORT cayeran siempre dentro del rombo real — pero cuando el
  // viewport abarca más filas/columnas de las que el mapa tiene a ese zoom
  // (el caso NORMAL con un mapa no gigantesco y una ventana corriente, no
  // una rareza de esquina) no hay ningún desplazamiento que lo consiga, y
  // el primer intento recortaba ESE caso a un punto fijo → cámara clavada.
  // El segundo intento dejaba ese caso sin recortar → el hueco volvía en
  // cuanto se llegaba a una esquina, que es el caso normal de juego, no una
  // rareza. Ambos fallaban porque intentaban resolverlo con matemática de
  // desplazamiento (o se puede evitar el hueco del todo, o no se puede — no
  // hay término medio que no sea o clavar la cámara o dejar el hueco).
  //
  // Se ha vuelto al recorte simple de rectángulo de siempre (déjalo así si
  // se retoma esto) y en su lugar se tapa el hueco por el lado VISUAL: ver
  // el fondo de niebla en #board-tiles (css/style.css) — el rectángulo que
  // envuelve al tablero se pinta siempre con la misma textura de niebla que
  // ya se usa para lo no explorado, así que cualquier esquina fuera del
  // rombo se ve como "más niebla" (coherente con el propio juego: ahí no
  // hay nada que explorar) en vez de un hueco negro que lee como un fallo.
  // Pedido explícito (pasada posterior, sustituye al reposicionamiento
  // dinámico que tenía el menú del Obelisco — ver la nota larga en
  // Obelisks, sección "menú del Obelisco"): "el juego deberia dejar
  // moverse un poco mas hacia la periferia del escenario, de manera que
  // ese problema se arreglase solo" — margen extra (en los 4 lados, a
  // cualquier zoom) sobre el recorte normal de abajo, para que SIEMPRE
  // quepa desplazar cualquier punto del mapa (incluida una esquina, donde
  // vive un Obelisco) lo bastante lejos del borde de pantalla como para
  // que su menú de posición fija (bottom:100% en CSS, nunca se mueve del
  // Obelisco) quede con sitio de sobra por encima sin recortarse. El hueco
  // que deja ese margen de más ya se pinta como "más niebla" por el lado
  // visual (ver la nota larga más arriba sobre las esquinas fuera del
  // rombo), así que no hace falta nada más para que se vea bien.
  _PAN_EXTRA_MARGIN: 180,

  _clampPanFor(x, y, scale) {
    const vw = this.viewportEl.clientWidth;
    const vh = this.viewportEl.clientHeight;
    const scaledW = this.contentWidth * scale;
    const scaledH = this.contentHeight * scale;
    const m = this._PAN_EXTRA_MARGIN;

    const minX = Math.min(0, vw - scaledW) - m;
    const maxX = Math.max(0, vw - scaledW) + m;
    const minY = Math.min(0, vh - scaledH) - m;
    const maxY = Math.max(0, vh - scaledH) + m;

    return { x: Math.min(maxX, Math.max(minX, x)), y: Math.min(maxY, Math.max(minY, y)) };
  },

  _clampTargetPan() {
    if (!this.viewportEl) return;
    const { x, y } = this._clampPanFor(this.targetPanX, this.targetPanY, this.targetScale);
    this.targetPanX = x;
    this.targetPanY = y;
  },

  // Zooms repetidos acaban acumulando texturas de la capa GPU enorme de la
  // cámara (errores gráficos). Tras ~8 cambios de escala y 600ms de calma se
  // suelta la capa (will-change:auto) y se vuelve a pedir en el siguiente
  // frame, lo que obliga al navegador a liberar y re-rasterizar limpio.
  _zoomChanges: 0,
  _lastScaleSeen: null,
  _flushTimer: null,
  _trackZoomForFlush() {
    if (this._lastScaleSeen !== null && Math.abs(this.scale - this._lastScaleSeen) > 0.002) {
      this._zoomChanges++;
      clearTimeout(this._flushTimer);
      this._flushTimer = setTimeout(() => {
        if (this._zoomChanges < 8) { this._zoomChanges = 0; return; }
        this._zoomChanges = 0;
        const el = this.cameraEl;
        el.style.willChange = "auto";
        void el.offsetWidth;
        requestAnimationFrame(() => { el.style.willChange = ""; });
      }, 600);
    }
    this._lastScaleSeen = this.scale;
  },

  _apply() {
    this._trackZoomForFlush();
    this.cameraEl.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.scale})`;
    // Pedido explícito: "¿se podrían desactivar las losetas de niebla que
    // no aparecen en pantalla?" — recalcula qué losetas de niebla caen
    // dentro del viewport (+margen de seguridad, ver Fog.updateCulling)
    // en cada frame de cámara. Solo cuando la animación está activada
    // (medido: con la animación desactivada, que ya es tan barata de
    // pintar de por sí, recorrer las 289 losetas en cada frame cuesta MÁS
    // de lo que ahorra).
    if (typeof Fog !== "undefined" && Fog.updateCulling && Fog.animEnabled) {
      Fog.updateCulling(this.panX, this.panY, this.scale, this.viewportEl.clientWidth, this.viewportEl.clientHeight);
    } else if (typeof Fog !== "undefined" && Fog._cullCount && !Fog.animEnabled) {
      Fog.clearCulling();
    }
    // Pedido explícito: "si alejo mucho la camara aparecen errores
    // graficos...tengo idea de hacer los escenarios mucho mas grandes y
    // detallados, asi que esto va a suponer un problema grave...como lo
    // arreglamos?" — virtualización del tablero (ver TerrainMap.
    // updateCulling en js/mapgen.js): a diferencia del culling de niebla de
    // arriba, este SIEMPRE se recalcula, no solo con la animación de
    // niebla activada — el coste que ahorra (pintar de golpe cientos de
    // losetas de terreno fuera de pantalla) no tiene nada que ver con esa
    // animación, y el propio cálculo está pensado para no crecer con el
    // tamaño del mapa (ver la nota larga en updateCulling).
    if (typeof TerrainMap !== "undefined" && TerrainMap.updateCulling) {
      TerrainMap.updateCulling(this.panX, this.panY, this.scale, this.viewportEl.clientWidth, this.viewportEl.clientHeight);
    }
    // Pedido explícito: "qué harías para mejorar el rendimiento al doble?"
    // — la virtualización de arriba solo cubría losetas/niebla; esto
    // extiende el mismo mecanismo a unidades, tótems, Obeliscos, tienda,
    // arbustos, recursos e hierbajos (ver js/entitycull.js para el porqué
    // completo). SIEMPRE, mismo criterio que TerrainMap justo arriba (el
    // coste que ahorra no depende de ninguna animación en concreto).
    if (typeof EntityCulling !== "undefined" && EntityCulling.updateCulling) {
      EntityCulling.updateCulling(this.panX, this.panY, this.scale, this.viewportEl.clientWidth, this.viewportEl.clientHeight);
    }
    // Pedido explícito: "contra más lejos se ve la cámara, cambiar sprites
    // por los mismos como resolución más baja" — ver js/spritequality.js.
    // Comprobación barata (dos comparaciones de número) en cada frame;
    // solo hace trabajo de verdad al cruzar alguno de los dos umbrales.
    if (typeof SpriteQuality !== "undefined" && SpriteQuality.updateForScale) {
      SpriteQuality.updateForScale(this.scale);
    }
    // El menú del Obelisco (RECLUTAR/HABILIDADES/ARMERÍA) YA NO se
    // reposiciona aquí a mano — ver la nota larga en obelisks.js, sección
    // "menú del Obelisco", y _PAN_EXTRA_MARGIN más arriba en este mismo
    // archivo: el reposicionamiento dinámico se retiró porque el jugador
    // lo notaba como saltos a sitios sin sentido; en su lugar el menú
    // vuelve a tener posición fija (CSS) y es el límite de paneo el que se
    // ha ampliado para que nunca haga falta moverlo.
  },

  // Aplica el ancla de zoom activa (this._zoomAnchor) a una escala concreta:
  // recalcula el desplazamiento necesario para que el punto de contenido
  // anclado se quede exactamente bajo el cursor/dedos para ESA escala.
  // Se llama tanto con la escala mostrada (cada frame, mientras el zoom
  // "alcanza" su objetivo) como con la escala objetivo (para que el límite
  // final quede bien calculado desde el principio) — así el punto anclado
  // nunca se desplaza, solo crece/decrece con el zoom.
  _applyZoomAnchor(scale, isTarget) {
    if (!this._zoomAnchor) return;
    const rawX = this._zoomAnchor.screenX - this._zoomAnchor.contentX * scale;
    const rawY = this._zoomAnchor.screenY - this._zoomAnchor.contentY * scale;
    const { x, y } = this._clampPanFor(rawX, rawY, scale);
    if (isTarget) {
      this.targetPanX = x;
      this.targetPanY = y;
    } else {
      this.panX = x;
      this.panY = y;
    }
  },

  // Convierte un punto en coordenadas del VIEWPORT (relativas a su propia
  // esquina superior-izquierda, ver getBoundingClientRect) al espacio de
  // "contenido" — el mismo sistema de coordenadas que usa getTileCenter/
  // getTileFromPoint (mapgen.js), antes de aplicar el pan/zoom de la
  // cámara. Misma fórmula que ya usaba _zoomAt para anclar el punto bajo el
  // cursor al hacer zoom (contentX/contentY ahí abajo) — expuesta aquí como
  // método público para que cualquier mecánica que necesite saber "a qué
  // punto del mapa corresponde este clic de pantalla" (p.ej. la habilidad
  // Visión Lejana, js/abilities.js) no tenga que duplicar la cuenta ni
  // conocer panX/panY/scale por su cuenta.
  clientToContent(cx, cy) {
    return {
      x: (cx - this.panX) / this.scale,
      y: (cy - this.panY) / this.scale,
    };
  },

  _zoomAt(cx, cy, factor) {
    const newScale = this._clampScale(this.targetScale * factor);
    if (newScale === this.targetScale) return;
    // Ancla usando la escala/posición REALMENTE mostradas (no el objetivo):
    // así el punto de contenido que había bajo el cursor se queda fijo ahí
    // durante todo el "alcance" suavizado del zoom, no solo al final.
    this._zoomAnchor = {
      screenX: cx,
      screenY: cy,
      contentX: (cx - this.panX) / this.scale,
      contentY: (cy - this.panY) / this.scale,
    };
    this.targetScale = newScale;
    this._applyZoomAnchor(this.targetScale, true);
    this._startLoop();
  },

  _panBy(dx, dy) {
    // Un arrastre manual cancela cualquier ancla de zoom en curso: a partir
    // de ahora el desplazamiento lo controla el jugador, no el zoom.
    this._zoomAnchor = null;
    this.targetPanX += dx;
    this.targetPanY += dy;
    this._clampTargetPan();
    this._startLoop();
  },

  // Bucle de suavizado: en cada frame acerca el valor mostrado al objetivo.
  _startLoop() {
    if (this._rafId) return;
    const step = () => {
      const ds = this.targetScale - this.scale;
      const scaleDone = Math.abs(ds) < this.SETTLE_EPSILON_SCALE;
      this.scale = scaleDone ? this.targetScale : this.scale + ds * this.SCALE_EASE;

      if (this._zoomAnchor) {
        // Con un ancla de zoom activa, el desplazamiento no persigue su
        // propio objetivo por separado: se deriva directamente del ancla
        // para la escala mostrada de este frame, así el punto bajo el
        // cursor nunca "se reposiciona", solo acompaña al zoom.
        this._applyZoomAnchor(this.scale, false);
        this._applyZoomAnchor(this.targetScale, true);
        if (scaleDone) this._zoomAnchor = null;
      } else {
        const dx = this.targetPanX - this.panX;
        const dy = this.targetPanY - this.panY;
        this.panX = Math.abs(dx) < this.SETTLE_EPSILON ? this.targetPanX : this.panX + dx * this.PAN_EASE;
        this.panY = Math.abs(dy) < this.SETTLE_EPSILON ? this.targetPanY : this.panY + dy * this.PAN_EASE;
      }

      this._apply();

      const settled =
        scaleDone &&
        !this._zoomAnchor &&
        this.panX === this.targetPanX &&
        this.panY === this.targetPanY;

      if (settled) {
        this._rafId = null;
        return;
      }
      this._rafId = requestAnimationFrame(step);
    };
    this._rafId = requestAnimationFrame(step);
  },

  _bindEvents() {
    const vp = this.viewportEl;
    vp.style.touchAction = "none";

    // ---- Zoom con la rueda del ratón ----
    vp.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        const rect = vp.getBoundingClientRect();
        const cx = e.clientX - rect.left;
        const cy = e.clientY - rect.top;
        const factor = Math.exp(-e.deltaY * 0.0015);
        this._zoomAt(cx, cy, factor);
      },
      { passive: false }
    );

    // ---- Arrastrar con el ratón (clic y arrastrar) ----
    vp.addEventListener("mousedown", (e) => {
      if (e.button !== 0) return;
      // BUG encontrado y corregido: "este error grafico aparece a veces,
      // es como si estuvieran seleccionados como texto" — sin esto, un
      // clic-y-arrastre normal para mover la cámara TAMBIÉN disparaba el
      // gesto nativo del navegador de seleccionar texto arrastrando (no
      // hay ningún texto de verdad bajo el cursor, pero el navegador igual
      // arranca una selección y la pinta como un rectángulo azul
      // translúcido encima de lo que haya debajo — una loseta, un gnomo...
      // ver también el user-select:none en .board-viewport, CSS, como
      // segunda barrera). preventDefault() en el propio mousedown ataja el
      // problema de raíz: nunca llega a iniciarse esa selección.
      e.preventDefault();
      this._dragState = { lastX: e.clientX, lastY: e.clientY, startX: e.clientX, startY: e.clientY };
      vp.classList.add("dragging");
    });

    // Bug reportado: "a veces seleccionar un jugador falla...hago clic
    // sobre el sprite y no lo escoge" — antes _dragMoved se marcaba a true
    // con el primer mousemove por mínimo que fuera (incluso 1px), algo que
    // pasa constantemente en un clic real y quieto (temblor natural de la
    // mano, más aún con trackpad); eso bastaba para que el bloqueo de
    // abajo (pensado solo para un arrastre de cámara de verdad) tratara
    // cualquier clic normal como si fuera el final de un arrastre y lo
    // anulara entero, incluso cayendo justo encima de un personaje. Ahora
    // hace falta superar un pequeño margen de tolerancia (en píxeles de
    // pantalla, medido desde el propio mousedown, no paso a paso) antes de
    // considerarlo un arrastre real — un clic con temblor normal nunca lo
    // alcanza, un arrastre de cámara de verdad lo supera enseguida.
    const DRAG_THRESHOLD_PX = 4;

    // Pedido explícito (investigación de "sigo teniendo que hacer doble clic
    // con mi dedo para casi todo en la interfaz desde el smartphone"): un
    // dedo sobre una pantalla capacitiva tiembla mucho más que un ratón o un
    // trackpad al quedarse "quieto" — 4px es un margen realista para un
    // clic de ratón, pero en un toque normal con el dedo es MUY fácil
    // superarlo sin querer arrastrar nada. Como el bloqueo de "click" de más
    // abajo usa la MISMA bandera (_dragMoved) tanto para ratón como para
    // dedo, ese temblor normal marcaba _dragMoved=true en el propio toque
    // que el jugador solo quería usar para seleccionar una unidad o pulsar
    // un botón del tablero — y el guardia de "click" en captura anulaba ESE
    // mismo toque con stopImmediatePropagation, dejándolo sin efecto. El
    // jugador lo interpretaba como que hacía falta un segundo toque (que sí
    // funcionaba, por pura suerte de que esa segunda vez el temblor fue
    // menor) cuando en realidad el primero SÍ se registraba, solo que se
    // descartaba por error al confundirlo con un arrastre de cámara. Un
    // margen mayor y propio para dedo (no para ratón, que no lo necesita)
    // soluciona la causa raíz sin tocar nada del arrastre de cámara real.
    const TOUCH_DRAG_THRESHOLD_PX = 14;

    window.addEventListener("mousemove", (e) => {
      if (!this._dragState) return;
      const dx = e.clientX - this._dragState.lastX;
      const dy = e.clientY - this._dragState.lastY;
      this._dragState.lastX = e.clientX;
      this._dragState.lastY = e.clientY;
      // Bug encontrado y corregido: "arrastrar el escenario para mover la
      // cámara no deselecciona el personaje seleccionado" — el arrastre
      // termina en un mouseup sobre el propio #board-viewport, y ese
      // elemento también escucha "click" (ver units.js, deselecciona al
      // hacer clic en una casilla vacía). Soltar tras arrastrar SIGUE
      // disparando ese "click" nativo (mismo elemento en mousedown y
      // mouseup), así que sin esta marca cualquier arrastre de cámara
      // deseleccionaba al personaje como si hubiera sido un clic en vacío.
      // Solo se marca cuando el desplazamiento TOTAL desde el mousedown
      // (no el de este solo frame) supera el margen de tolerancia de
      // arriba — ver DRAG_THRESHOLD_PX.
      if (!this._dragMoved) {
        const totalDx = e.clientX - this._dragState.startX;
        const totalDy = e.clientY - this._dragState.startY;
        if (Math.hypot(totalDx, totalDy) > DRAG_THRESHOLD_PX) this._dragMoved = true;
      }
      this._panBy(dx, dy);
    });

    window.addEventListener("mouseup", () => {
      if (!this._dragState) return;
      this._dragState = null;
      vp.classList.remove("dragging");
    });

    // Bloquea el "click" de deseleccionar (ver units.js) cuando en realidad
    // es el final de un arrastre de cámara, no un toque real sobre una
    // casilla vacía. capture:true para que se ejecute ANTES que el listener
    // de units.js, que está en fase de burbuja sobre este mismo elemento.
    vp.addEventListener(
      "click",
      (e) => {
        if (this._dragMoved) {
          e.stopImmediatePropagation();
          this._dragMoved = false;
        }
      },
      { capture: true }
    );

    // ---- Táctil: un dedo para desplazar, dos dedos (pellizco) para zoom ----
    const touchDist = (t1, t2) =>
      Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);

    vp.addEventListener(
      "touchstart",
      (e) => {
        if (e.touches.length === 1) {
          const t = e.touches[0];
          this._touchState = { mode: "pan", lastX: t.clientX, lastY: t.clientY, startX: t.clientX, startY: t.clientY };
        } else if (e.touches.length === 2) {
          const [t1, t2] = e.touches;
          this._touchState = {
            mode: "pinch",
            startDist: touchDist(t1, t2),
            startScale: this.targetScale,
          };
        }
      },
      { passive: false }
    );

    vp.addEventListener(
      "touchmove",
      (e) => {
        if (!this._touchState) return;
        e.preventDefault();

        if (this._touchState.mode === "pan" && e.touches.length === 1) {
          const t = e.touches[0];
          const dx = t.clientX - this._touchState.lastX;
          const dy = t.clientY - this._touchState.lastY;
          this._touchState.lastX = t.clientX;
          this._touchState.lastY = t.clientY;
          // Mismo margen de tolerancia que el arrastre con ratón (ver
          // DRAG_THRESHOLD_PX más arriba) — un toque quieto con el dedo
          // también tiembla un poco, no cualquier movimiento cuenta como
          // arrastre real.
          if (!this._dragMoved) {
            const totalDx = t.clientX - this._touchState.startX;
            const totalDy = t.clientY - this._touchState.startY;
            if (Math.hypot(totalDx, totalDy) > TOUCH_DRAG_THRESHOLD_PX) this._dragMoved = true;
          }
          this._panBy(dx, dy);
        } else if (this._touchState.mode === "pinch" && e.touches.length === 2) {
          // getBoundingClientRect() solo hace falta aquí (para convertir el
          // punto medio del pellizco a coordenadas locales del viewport) —
          // antes se llamaba en CADA touchmove sin importar el modo,
          // incluyendo el arrastre normal de un dedo, que no lo necesita
          // para nada; en un móvil de gama baja, con eventos táctiles
          // disparando a 60-120Hz durante un arrastre, ese cálculo de más
          // en cada evento suma (pedido explícito de optimizar el
          // rendimiento en smartphone).
          const rect = vp.getBoundingClientRect();
          const [t1, t2] = e.touches;
          const dist = touchDist(t1, t2);
          const midX = (t1.clientX + t2.clientX) / 2 - rect.left;
          const midY = (t1.clientY + t2.clientY) / 2 - rect.top;
          const factor = (dist / this._touchState.startDist) * (this._touchState.startScale / this.targetScale);
          this._zoomAt(midX, midY, factor);
        }
      },
      { passive: false }
    );

    vp.addEventListener("touchend", (e) => {
      if (e.touches.length === 0) {
        this._touchState = null;
      } else if (e.touches.length === 1) {
        const t = e.touches[0];
        this._touchState = { mode: "pan", lastX: t.clientX, lastY: t.clientY };
      }
    });

    // Si la ventana cambia de tamaño, reajustamos los límites de desplazamiento
    // al instante (no es un gesto del jugador, no necesita suavizado).
    // Pedido de rendimiento: "mejorar mucho el rendimiento en navegador" —
    // arrastrar el borde de la ventana para redimensionarla dispara el
    // evento "resize" muchísimas veces por segundo (no solo una vez al
    // soltar), y cada uno de estos recalcula el culling de niebla/terreno
    // de TODO el tablero visible (ver _apply). Coalescer con
    // requestAnimationFrame hace como mucho un recálculo por fotograma real
    // en vez de uno por cada evento "resize" bruto, sin cambiar el
    // resultado (el último tamaño es el que siempre gana).
    let resizeRafId = null;
    window.addEventListener("resize", () => {
      if (resizeRafId) return;
      resizeRafId = requestAnimationFrame(() => {
        resizeRafId = null;
        this._clampTargetPan();
        this.panX = this.targetPanX;
        this.panY = this.targetPanY;
        this._apply();
      });
    });
  },

  // ---- Desplazamiento con teclado (flechas/WASD) ----
  _bindKeyboard() {
    window.addEventListener("keydown", (e) => {
      const key = e.key.toLowerCase();
      if (!(key in BOARD_PAN_KEYS)) return;
      // No robar la tecla si el foco está en un campo de texto de verdad
      // (el juego no tiene ninguno ahora mismo, pero es la comprobación
      // estándar por si algún día lo hay) — así nunca compite con escribir.
      const tag = document.activeElement && document.activeElement.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      e.preventDefault();
      this._keysPressed.add(key);
      this._startKeyboardLoop();
    });

    window.addEventListener("keyup", (e) => {
      this._keysPressed.delete(e.key.toLowerCase());
    });

    // Si la ventana/pestaña pierde el foco con una tecla a medio pulsar
    // (p.ej. Alt+Tab), sin este "soltar" a la fuerza la cámara se quedaría
    // desplazándose sola para siempre — el keyup real nunca llega a
    // disparase porque la tecla se soltó fuera de esta página.
    window.addEventListener("blur", () => this._keysPressed.clear());

    // Bucle propio (independiente del de suavizado de _startLoop): solo
    // corre mientras haya alguna tecla de desplazamiento pulsada, y en cada
    // fotograma llama a _panBy con la distancia de ESE fotograma (velocidad
    // constante en px/segundo, no en px/fotograma, para no depender de la
    // frecuencia de refresco de cada pantalla).
    this._startKeyboardLoop = () => {
      if (this._keyLoopId) return;
      this._lastKeyFrameTime = performance.now();
      const step = (now) => {
        if (this._keysPressed.size === 0) {
          this._keyLoopId = null;
          return;
        }
        // dt limitado a 100ms: si la pestaña estuvo un rato inactiva entre
        // dos fotogramas (p.ej. cambiando de ventana), evita un salto de
        // cámara enorme de golpe al volver.
        const dt = Math.min(now - this._lastKeyFrameTime, 100) / 1000;
        this._lastKeyFrameTime = now;

        let dx = 0;
        let dy = 0;
        this._keysPressed.forEach((key) => {
          const dir = BOARD_PAN_KEYS[key];
          if (!dir) return;
          dx += dir[0];
          dy += dir[1];
        });
        // Normalizado: dos teclas a la vez (p.ej. W+D, diagonal) no deben
        // moverse más rápido que una sola por ir sumando componentes.
        if (dx !== 0 || dy !== 0) {
          const len = Math.hypot(dx, dy);
          const dist = this.KEY_PAN_SPEED * dt;
          this._panBy((dx / len) * dist, (dy / len) * dist);
        }

        this._keyLoopId = requestAnimationFrame(step);
      };
      this._keyLoopId = requestAnimationFrame(step);
    };
  },
};

document.addEventListener("DOMContentLoaded", () => BoardView.init());
