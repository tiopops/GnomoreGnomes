/* Gnomore Gnomes — turnos por equipo.
   Regla de oro: un archivo por mecánica. Este archivo NO sabe cómo se mueve,
   se ataca, se coge o se pasa el gnomo — eso sigue viviendo tal cual en
   js/movement.js, js/combat.js y js/gnome.js. Lo único que sabe es:
     - A quién le toca ahora mismo (Turns.activeTeam).
     - Cuántas acciones lleva gastadas cada unidad esta ronda suya
       (Turns.actionsUsed) y si todavía puede actuar (Turns.canAct).
   Cada mecánica llama a Turns.canAct(unit) antes de ofrecer sus marcadores
   (ver el gate al principio de showFor en movement.js/combat.js/gnome.js) y
   a Turns.useAction(unit) justo cuando la acción se confirma de verdad
   (Movement.moveTo, Combat.attack, GnomeInstance.hit/executePass/catchBy) —
   así este archivo no necesita saber CUÁNDO ocurre cada una, solo que se lo
   avisen.

   Pedido explícito: "cada personaje tiene 2 acciones, las acciones son...
   moverse una vez, pegar una vez a un enemigo, pegar al gnomo una vez, pasar
   el gnomo una vez o usar una habilidad una vez cuando las haya, una vez un
   personaje haya usado 2 acciones... perderá un poco de saturación para
   indicar que está inactivo (un jugador inactivo puede recibir un pase)...
   el jugador deberá pulsar el botón PASAR TURNO... entonces será el turno de
   mover del jugador enemigo... el ordenador simulará el turno del enemigo
   moviendo a los personajes, cogiendo gnomos... con el tiempo definiremos
   una IA más compleja." — la IA de aquí es deliberadamente simple (ver
   _runEnemyTurn/_aiActOnce más abajo), a la espera de esa IA más completa
   futura que el propio pedido ya anticipa. */

const TURNS_MAX_ACTIONS = 2;

// Pedido explícito: "de momento habran un maximo de 30 turnos por partida".
// Un "turno" aquí es una RONDA COMPLETA (jugador + rival, un único pulso del
// botón PASAR TURNO) — mismo criterio que ya usa registerTurnEndListener/
// onRoundEnd (ver su comentario más abajo), así el contador que se muestra
// sobre el botón cuenta lo mismo que ya cuentan los oyentes existentes.
const TURNS_MAX_ROUNDS = 60;

// Pedido explícito (original, en pruebas): "de momento para hacer pruebas,
// que los enemigos no ataquen estamos en modo sandbox" — la IA rival
// (_aiActOnce más abajo) seguía moviéndose y cogiendo/golpeando/pasando
// gnomos con total normalidad, solo se le desactivaba la prioridad de
// ATACAR a los personajes del jugador.
// Pedido explícito (segunda vuelta, ya fuera de pruebas): "ahora quiero que
// los enemigos tambien puedan atacar a mis unidades cuando lo precisen o lo
// vean necesario para ganar la partida" — a false, tal cual anticipaba el
// comentario original ("poner a false el día que se quiera que el rival
// ataque de verdad"). A partir de ahora _aiActOnce SÍ entra en la rama de
// Combat.attackableEnemies (ver más abajo): un rival sin gnomo cogido que
// tenga a algún personaje del jugador a su alcance (quedándose quieto o
// moviéndose) lo ataca, con la misma prioridad que ya tenía esa rama antes
// de desactivarse (por delante de perseguir un gnomo suelto, por detrás de
// la rama de "llevo un gnomo cogido" que sigue intacta y sin tocar).
const TURNS_SANDBOX_NO_ENEMY_ATTACK = false;

const Turns = {
  activeTeam: "player", // "player" | "enemy"
  actionsUsed: {}, // unitId -> nº de acciones gastadas en SU turno actual
  _btn: null,
  _btnLabelEl: null,
  _aiRunning: false,
  _turnEndListeners: [],

  // Igual que Units.registerSelectionListener pero para cualquier mecánica
  // que necesite contar RONDAS COMPLETAS (jugador + rival, un único pulso
  // del botón de pasar turno) sin tener que reimplementar ese conteo por su
  // cuenta — ver js/backpack.js (cuenta atrás de la Setarcoiris). Se avisa
  // al final de endTurn(), cuando ya ha vuelto a ser el turno del jugador.
  registerTurnEndListener(listener) {
    this._turnEndListeners.push(listener);
  },

  // Igual que registerTurnEndListener pero para el INICIO de CADA turno
  // individual (el del jugador Y el del rival, no solo una vez por ronda
  // completa) — lo usa js/shops.js para la reposición de existencias cada
  // 5 turnos ("se avisara con un mensaje en pantalla al empezar el turno").
  // Se llama con el equipo (team) al que le toca justo ahora: una vez en
  // reset() (el primer turno de la partida, del jugador) y dos veces por
  // cada vuelta de endTurn() (al pasar al rival y al volver al jugador).
  _turnStartListeners: [],
  registerTurnStartListener(listener) {
    this._turnStartListeners.push(listener);
  },
  // Devuelve una promesa que se resuelve cuando TODOS los oyentes que hayan
  // devuelto una promesa terminan (p.ej. GnomOgro.onTurnStart, que anima su
  // paso/golpe) — endTurn la espera para no solapar animaciones.
  // Igual que _fireTurnStart pero al FINAL del turno de `team` (antes de
  // pasar al otro equipo): los oyentes con onTurnEnd(team) pueden devolver
  // una promesa (p.ej. las flechas de las Torretas, js/skills.js).
  async _fireTurnEnd(team) {
    for (const l of this._turnStartListeners) {
      if (l.onTurnEnd) await l.onTurnEnd(team);
    }
  },

  _fireTurnStart(team) {
    const results = this._turnStartListeners.map((l) => (l.onTurnStart ? l.onTurnStart(team) : null));
    return Promise.all(results);
  },

  // Se llama al empezar cada partida nueva (spawnTestUnits, ver
  // newgame-flow.js), DESPUÉS de crear todos los personajes y gnomos —
  // deja limpio el contador, siempre empieza el jugador, y (re)crea/muestra
  // el botón de PASAR TURNO.
  reset() {
    this.activeTeam = "player";
    this.actionsUsed = {};
    this._aiRunning = false;
    // "de momento habran un maximo de 30 turnos por partida" — empieza en
    // el turno 1, sube una vez por cada ronda completa (ver endTurn).
    this.roundNumber = 1;
    // Habilidades especiales (js/abilities.js) — partida nueva, quita
    // cualquier mina/apuntado/control mental que hubiera quedado de una
    // partida anterior.
    if (typeof Abilities !== "undefined") Abilities.resetAll();
    Units.list.forEach((u) => this._applyExhaustedClass(u));
    this._ensureButton();
    this._updateButtonState();
    // Puntos de Gloria (js/glory.js) — pedido explícito: "al comienzo de
    // cada turno se generan automaticamente 2 puntos de gloria", y el
    // primer turno de la partida (el del jugador) no es una excepción.
    if (typeof Glory !== "undefined") Glory.grantTurnStart("player");
    this._fireTurnStart("player");
  },

  // true si `unit` puede gastar todavía alguna de sus 2 acciones ESTE turno
  // — falso tanto si ya las gastó como si no es el turno de su equipo. Toda
  // mecánica (Movement/Combat/Gnome) comprueba esto antes de ofrecer nada.
  canAct(unit) {
    if (!unit || !unit.el) return false;
    if (unit.team !== this.activeTeam) return false;
    return (this.actionsUsed[unit.id] || 0) < TURNS_MAX_ACTIONS;
  },

  // Cuántas de sus 2 acciones le quedan por gastar ESTE turno a `unit` —
  // pedido explícito: "si un enemigo esta dentro del area de movimiento y
  // pulso atacar, el personaje se mueve y ataca, eso son dos acciones" —
  // Combat/Villages/Obelisks lo consultan para NO ofrecer siquiera la mira
  // de ataque sobre un objetivo que exige moverse primero si a la unidad
  // solo le queda 1 acción (no le llegaría para las dos), aunque sí
  // seguirían pudiendo atacar sin moverse (esa sigue constando de una sola
  // acción, como siempre) con esa única acción restante.
  remainingActions(unit) {
    if (!unit) return 0;
    return Math.max(0, TURNS_MAX_ACTIONS - (this.actionsUsed[unit.id] || 0));
  },

  // Descuenta una acción de `unit` — lo llama cada mecánica justo cuando la
  // acción se confirma de verdad (ver cabecera del archivo). Si con esto
  // llega a las 2 y esa unidad es la seleccionada ahora mismo, se
  // deselecciona sola para que sus marcadores/botones desaparezcan sin que
  // cada mecánica tenga que acordarse de ocultarlos a mano.
  useAction(unit) {
    this.actionsUsed[unit.id] = (this.actionsUsed[unit.id] || 0) + 1;
    this._applyExhaustedClass(unit);
    if (Units.selectedId === unit.id && !this.canAct(unit)) {
      Units.deselect();
    }
    // Pedido explícito: "cuando todos los personajes se hayan movido estaría
    // bien que palpitase para avisar visualmente al jugador" — se comprueba
    // después de CADA acción (no solo al cambiar de turno) para que el botón
    // se ponga a palpitar en el instante exacto en que la ÚLTIMA unidad del
    // jugador se queda sin acciones, no un paso más tarde.
    this._updateButtonState();
  },

  // Pedido explícito (cepo "AtrapaPinreles", js/backpack.js): "pierde
  // automaticamente el turno" al caer en la trampa — a diferencia de
  // useAction (descuenta UNA acción de las 2, la mecánica normal de cada
  // turno), esto le quita TODAS las que le quedaran de golpe, sin esperar
  // a que las gaste una a una. Reutiliza _applyExhaustedClass (mismo único
  // punto de paso que useAction) para que el aviso visual/indicador de
  // acciones/botón de habilidad se pongan al día igual que con cualquier
  // otro cambio de actionsUsed.
  forceOutOfActions(unit) {
    if (!unit) return;
    this.actionsUsed[unit.id] = TURNS_MAX_ACTIONS;
    this._applyExhaustedClass(unit);
    if (Units.selectedId === unit.id && !this.canAct(unit)) {
      Units.deselect();
    }
    this._updateButtonState();
  },

  // Saturación reducida (pedido explícito) en cuanto una unidad agota sus 2
  // acciones — puramente visual, "un jugador inactivo puede recibir un
  // pase" así que no bloquea ningún clic aquí, solo lo hacen canAct/showFor.
  _applyExhaustedClass(unit) {
    if (!unit.el) return;
    const exhausted = (this.actionsUsed[unit.id] || 0) >= TURNS_MAX_ACTIONS;
    unit.el.classList.toggle("unit--exhausted", exhausted);
    // Indicador de acciones restantes (js/unitinfo.js) — se llama desde
    // AQUÍ (no desde useAction directamente) porque este método ya es el
    // único punto de paso de todos los sitios que tocan actionsUsed
    // (useAction, refreshExhaustedClass, _resetTeamActions y reset(), ver
    // cabecera del archivo), así el indicador se mantiene al día sin
    // duplicar el aviso en cada uno. Solo repinta si `unit` es la que está
    // seleccionada ahora mismo (refreshActionDots ya hace esa comprobación).
    if (typeof UnitInfo !== "undefined") UnitInfo.refreshActionDots();
    // Botón de habilidad especial (js/abilities.js) — mismo motivo que
    // UnitInfo arriba: aparece/desaparece según si la unidad SELECCIONADA
    // ahora mismo todavía puede actuar, así que se avisa desde este único
    // punto de paso en vez de repetirlo en cada sitio que toca actionsUsed.
    if (typeof Abilities !== "undefined") Abilities.refresh();
  },

  // Versión pública de lo de arriba — para archivos que a propósito
  // suprimieron el aviso visual un rato (ver Villages._playEpicSmash: "el
  // personaje no debe tener los colores de inactivo hasta que se haya
  // capturado el propio totem") y necesitan volver a ponerlo al día sin
  // tocar el conteo real de acciones (ese ya se actualizó al llamar a
  // useAction en su momento, esto solo repinta el classList).
  refreshExhaustedClass(unit) {
    this._applyExhaustedClass(unit);
  },

  // Vacía a 0 las acciones gastadas de TODAS las unidades de `team` y les
  // quita la saturación — se llama al EMPEZAR el turno de ese equipo (nunca
  // al terminarlo), así el otro equipo se queda viendo cómo de "gastadas"
  // dejaron a sus unidades hasta que vuelva a tocarles.
  _resetTeamActions(team) {
    Units.list
      .filter((u) => u.team === team)
      .forEach((u) => {
        // "Nudillos Rocosos" (PuñoRoca) y la trampa de TruenoEspora
        // (js/abilities.js) dejan a su víctima agotada DESDE EL PRINCIPIO
        // de su turno siguiente, en vez de con las 2 acciones normales de
        // cualquier otro turno — se consume aquí, una sola vez.
        if (u.forcedRestNextTurn) {
          u.forcedRestNextTurn = false;
          this.actionsUsed[u.id] = TURNS_MAX_ACTIONS;
        } else {
          this.actionsUsed[u.id] = 0;
        }
        this._applyExhaustedClass(u);
      });
  },

  // ---------- Botón "PASAR TURNO" ----------
  // Mismo patrón que UnitInfo/Gnome (botón fijo, position:fixed, añadido a
  // document.body una sola vez) — pero SIEMPRE visible durante la partida
  // (no ligado a ninguna selección): esquina inferior derecha, pedido
  // explícito.

  _ensureButton() {
    if (this._btn) return;
    const btn = document.createElement("button");
    btn.className = "end-turn-btn";
    btn.setAttribute("aria-label", "Pasar turno");
    // Capa de fondo aparte (ver style.css) — el recorte en banderín del
    // botón vive AQUÍ, no en el <button> en sí, para que el rombo del
    // icono (hermano suyo, no hijo) pueda salirse fuera de la caja de
    // texto sin que ese mismo clip-path le coma la punta. "Pasar turno" es
    // el texto de este span, no del botón entero.
    const bg = document.createElement("span");
    bg.className = "end-turn-btn__bg";
    // Pedido explícito: "arriba del texto PASAR TURNO del boton, debe
    // indicarse en que turno estamos...X/30" — una línea pequeña encima del
    // texto de siempre, dentro de la misma capa recortada (.end-turn-btn__bg)
    // para que se mueva/anime siempre junto con el resto del botón.
    const turnCounter = document.createElement("span");
    turnCounter.className = "end-turn-btn__turn-counter";
    bg.appendChild(turnCounter);
    this._turnCounterEl = turnCounter;
    // Pedido explícito: "aplica esa correccion [contorno de doble capa] a
    // TODOS LOS BOTONES...ya que tenian ese mismo defecto" — el rombo
    // (end-turn-btn__icon) pasa a ser un contenedor ESTABLE que nunca se
    // sustituye (lleva la silueta + el contorno de doble capa, ver
    // style.css), y el glifo en sí vive en su PROPIO <i> hijo
    // (end-turn-btn__icon-glyph) que SÍ se sustituye en cada cambio de
    // estado (ver _setIcon) — antes el icono ERA el rombo directamente,
    // pero el webfont de Phosphor pinta el glifo con el ::before de ese
    // mismo elemento, y el contorno de doble capa TAMBIÉN necesita su
    // propio ::before/::after libres, así que ya no pueden compartir un
    // único elemento.
    const iconWrap = document.createElement("span");
    iconWrap.className = "end-turn-btn__icon";
    const icon = document.createElement("i");
    icon.className = "ph ph-flag-checkered end-turn-btn__icon-glyph";
    iconWrap.appendChild(icon);
    const label = document.createElement("span");
    label.className = "end-turn-btn__label";
    bg.appendChild(label);
    btn.appendChild(bg);
    btn.appendChild(iconWrap);
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.endTurn();
    });
    document.body.appendChild(btn);
    this._btn = btn;
    this._btnLabelEl = label;
    this._btnIconEl = icon;
    this._btnIconWrapEl = iconWrap;
  },

  // Pedido explícito: "creo que el icono phosphor de pasar turno esta
  // duplicado...compruebalo y arreglalo" — investigado a fondo: el paquete
  // @phosphor-icons/web (el que carga index.html por CDN) es solo CSS puro,
  // un webfont con el glifo pintado vía ::before{content:...} — no inyecta
  // ni duplica ningún SVG por JS, así que no hay ningún proceso que pueda
  // "apilar" iconos por cambiar el className varias veces (se comprobó
  // bajando el paquete e inspeccionando su código fuente). La causa real es
  // visual, no un bug de DOM: el reloj de arena (que de por sí tiene una
  // silueta de "lazo"/doble triángulo) vive MUY pegado a los bordes de su
  // propia caja, que también es un rombo — dos formas de diamante casi
  // superpuestas a esa escala se leen como si hubiera un icono repetido.
  // Arreglo de verdad: más margen entre el glifo y el borde de la caja +
  // caja más grande (ver .end-turn-btn__icon en style.css) para que se
  // distingan como una sola pieza clara, no dos. Este método sigue siendo
  // la forma correcta y más robusta de cambiar el icono desde JS (crea un
  // <i> limpio en vez de mutar uno ya existente), así que se queda aunque
  // no fuera la causa del "duplicado".
  // `className` llega como "ph ph-xxx end-turn-btn__icon" desde las tres
  // llamadas de abajo (se queda así por no tocar esas tres líneas) — pero
  // desde que el rombo (end-turn-btn__icon) es un contenedor ESTABLE
  // aparte (ver _ensureButton), aquí solo hace falta la clase del GLIFO en
  // sí (end-turn-btn__icon-glyph), nunca la del rombo.
  _setIcon(className) {
    const glyphClassName = className.replace(
      "end-turn-btn__icon",
      "end-turn-btn__icon-glyph"
    );
    if (this._btnIconEl && this._btnIconEl.className === glyphClassName) return;
    const icon = document.createElement("i");
    icon.className = glyphClassName;
    if (this._btnIconEl && this._btnIconEl.parentNode) {
      this._btnIconEl.replaceWith(icon);
    } else if (this._btnIconWrapEl) {
      this._btnIconWrapEl.appendChild(icon);
    }
    this._btnIconEl = icon;
    // El giro al pasar el ratón (end-turn-hourglass-spin, ver style.css)
    // solo debe pasar con el reloj de arena — antes se seleccionaba con
    // ".end-turn-btn__icon.ph-hourglass-simple" porque ambas clases vivían
    // en el mismo elemento; ahora viven en elementos distintos, así que se
    // marca aparte en el rombo (el que de verdad gira).
    if (this._btnIconWrapEl) {
      this._btnIconWrapEl.classList.toggle(
        "end-turn-btn__icon--hourglass",
        glyphClassName.includes("ph-hourglass-simple")
      );
    }
  },

  // Se llama desde js/settingsmenu.js al salir de la partida (opción "Salir
  // de la partida" del popup de ajustes, ver ese archivo) — antes esto lo
  // hacía un listener propio sobre el back-btn del tablero, pero ese botón
  // ya no existe (lo tapaba el marcador de Puntos de Gloria, pedido
  // explícito: lo sustituye el icono de ajustes de la esquina superior
  // derecha). Mismo efecto de siempre: el botón deja de estar visible hasta
  // que la próxima partida lo vuelva a mostrar (Turns.reset -> _updateButtonState).
  hideButton() {
    if (this._btn) this._btn.classList.remove("end-turn-btn--visible");
  },

  // true si NINGUNA unidad del jugador puede ya actuar este turno (las 2
  // acciones de todas gastadas) — lo usa _updateButtonState para decidir
  // cuándo palpitar (pedido explícito, ver más abajo). false si el equipo
  // del jugador está vacío (no hay nada que avisar).
  _allPlayerUnitsExhausted() {
    const playerUnits = Units.list.filter((u) => u.team === "player");
    if (playerUnits.length === 0) return false;
    return playerUnits.every((u) => !this.canAct(u));
  },

  _updateButtonState() {
    if (!this._btn) return;
    this._btn.classList.add("end-turn-btn--visible");
    if (this._turnCounterEl) this._turnCounterEl.textContent = `Turno ${this.roundNumber} / ${TURNS_MAX_ROUNDS}`;
    const isPlayerTurn = this.activeTeam === "player" && !this._aiRunning;
    this._btn.disabled = !isPlayerTurn;
    this._btn.classList.toggle("end-turn-btn--thinking", !isPlayerTurn);

    // Pedido explícito: "cuando todos los personajes se hayan movido estaría
    // bien que palpitase para avisar visualmente al jugador" — solo mientras
    // es su turno de verdad (nunca durante el turno rival, aunque
    // técnicamente ya estén todos "agotados" de la ronda anterior).
    const ready = isPlayerTurn && this._allPlayerUnitsExhausted();
    this._btn.classList.toggle("end-turn-btn--ready", ready);

    if (!isPlayerTurn) {
      this._btnLabelEl.textContent = "Turno rival…";
      this._setIcon("ph ph-circle-notch end-turn-btn__icon");
    } else if (ready) {
      this._btnLabelEl.textContent = "¡Todos listos!";
      this._setIcon("ph ph-check-circle end-turn-btn__icon");
    } else {
      this._btnLabelEl.textContent = "Pasar turno";
      this._setIcon("ph ph-hourglass-simple end-turn-btn__icon");
    }
  },

  // ---------- Cambio de turno ----------

  // Cartel "¡ES TU TURNO!" (un jugador y multijugador).
  showTurnBanner() {
    if (typeof Tutorial !== "undefined" && Tutorial.active) return;
    if (typeof Obelisks !== "undefined" && Obelisks.gameOver) return;
    const old = document.querySelector(".turn-banner");
    if (old) old.remove();
    const el = document.createElement("div");
    el.className = "turn-banner";
    el.innerHTML = '<span class="turn-banner__text">' + I18N.t("your_turn") + "</span>";
    document.body.appendChild(el);
    if (typeof SFX !== "undefined" && SFX.enabled) { try { SFX.captureVillage(); } catch (e) {} }
    setTimeout(() => el.remove(), 2100);
  },

  async endTurn() {
    if (this._aiRunning || this.activeTeam !== "player") return;
    // Fin de partida por límite de turnos (ver Obelisks.checkTurnLimit,
    // js/obelisks.js) — ya se decidió un ganador, no se procesa ningún
    // turno más.
    if (typeof Obelisks !== "undefined" && Obelisks.gameOver) return;
    Units.deselect();
    if (typeof Villages !== "undefined") Villages.deselect();
    // Habilidad "Voluntad Quebrada" (UrgaMentes, js/abilities.js) —
    // "toma el control...durante el resto de este turno": el control
    // termina aquí, al pasar turno, tanto si se llegaron a gastar sus 2
    // acciones como si no (vuelve a su equipo, agotada, para que la IA
    // rival no la use este mismo round).
    if (typeof Abilities !== "undefined") Abilities.releaseMindControl();
    // Fin del turno del jugador (Torretas, js/skills.js): tablero bloqueado
    // mientras se animan las flechas.
    this._aiRunning = true;
    this._updateButtonState();
    await this._fireTurnEnd("player");
    this._aiRunning = false;
    if (typeof Obelisks !== "undefined" && Obelisks.gameOver) return;
    // Pedido explícito: "los gnomos que están sueltos... pierden 5 puntos
    // cada vez que alguien pulsa el botón PASAR TURNO" — CADA pulsación
    // cuenta, así que se llama aquí (la del jugador) Y otra vez más abajo,
    // cuando el ordenador "pulsa" el suyo automáticamente al terminar su
    // turno — dos veces por ronda completa, no una.
    if (typeof Gnome !== "undefined") Gnome.applyTurnPassDecay();
    this.activeTeam = "enemy";
    this._resetTeamActions("enemy");
    this._aiRunning = true;
    this._updateButtonState();
    // Puntos de Gloria (js/glory.js) — +2 al empezar el turno del rival
    // también: el marcador en pantalla es solo el del jugador (ver nota de
    // cabecera de glory.js), pero el rival igualmente acumula los suyos por
    // dentro para cuando su IA los pueda gastar más adelante.
    if (typeof Glory !== "undefined") Glory.grantTurnStart("enemy");
    await this._fireTurnStart("enemy");
    // El GnomOgro pudo destruir un Obelisco justo al empezar este turno.
    if (typeof Obelisks !== "undefined" && Obelisks.gameOver) {
      this._aiRunning = false;
      return;
    }

    await this._runEnemyTurn();
    await this._fireTurnEnd("enemy");

    if (typeof Gnome !== "undefined") Gnome.applyTurnPassDecay();
    this._aiRunning = false;
    this.activeTeam = "player";
    this._resetTeamActions("player");
    // "de momento habran un maximo de 30 turnos por partida" — una ronda
    // completa (jugador + rival) acaba de terminar, así que sube aquí,
    // ANTES de repintar el botón (para que ya muestre el número nuevo) y
    // antes de comprobar si toca acabar la partida.
    this.roundNumber++;
    this._updateButtonState();
    if (typeof Glory !== "undefined") Glory.grantTurnStart("player");
    // Se espera a los oyentes de inicio de turno (GnomOgro, plaga...) con el
    // tablero bloqueado, para que sus animaciones no se pisen con el jugador.
    this._aiRunning = true;
    this._updateButtonState();
    await this._fireTurnStart("player");
    this._aiRunning = false;
    this._updateButtonState();
    this.showTurnBanner();
    // "una vez por ronda completa" (ver registerTurnEndListener arriba) —
    // aquí, justo al terminar, no en ningún punto intermedio de la IA.
    this._turnEndListeners.forEach((l) => l.onRoundEnd && l.onRoundEnd());
    if (typeof Obelisks !== "undefined" && typeof Obelisks.checkTurnLimit === "function") {
      Obelisks.checkTurnLimit(this.roundNumber);
    }
  },

  // ---------- "Quién va perdiendo" ----------
  // Criterio compartido (Plaga Gnoma, js/plague.js, y la decisión de la IA de
  // invocar al GnomOgro): mismo orden que Obelisks.checkTurnLimit (vida del
  // Obelisco, luego tótems poseídos) más, como desempate, nº de personajes
  // vivos. Devuelve "player" | "enemy" (el que va peor) o null si van igual.
  standingOf(team) {
    const o = typeof Obelisks !== "undefined" ? Obelisks.byTeam(team) : null;
    const totems = typeof Villages !== "undefined" ? Villages.ownedCount(team) : 0;
    const units = Units.list.filter((u) => u.team === team).length;
    return [o ? o.hp : 0, totems, units];
  },

  losingTeam() {
    const a = this.standingOf("player");
    const b = this.standingOf("enemy");
    for (let i = 0; i < a.length; i++) {
      if (a[i] < b[i]) return "player";
      if (a[i] > b[i]) return "enemy";
    }
    return null;
  },

  // Pedido explícito: "los enemigos pueden tomar la decision de invocar al
  // gnomogro si ven que la partida asi lo requiere o estan perdiendo".
  // Con un gnomo cargado en la mano y el Altar en pie, la IA lo estampa si:
  //   - su gnomo (por sí solo) llena lo que falta: el GnomOgro sería suyo; o
  //   - va perdiendo: alimenta el altar sin más; o
  //   - la partida se alarga (ronda >= 20, "la partida lo requiere"): lo
  //     alimenta solo mientras no lo deje en "lleno" (70%), para no
  //     regalarle al jugador un remate fácil.
  // Un gnomo sin puntos no cuenta (no rellena nada): se sigue cargando.
  _aiShouldSacrificeAtAltar(unit, held) {
    if (typeof Altar === "undefined") return false;
    const altar = Altar.current();
    if (!altar || held.points <= 0) return false;
    const mine = altar.fills[unit.team === "enemy" ? "enemy" : "player"];
    if (held.points >= ALTAR_MAX_FILL - mine) return true;
    if (this.losingTeam() === unit.team) return true;
    if (this.roundNumber >= 20) return mine + held.points < ALTAR_LLENO_THRESHOLD;
    return false;
  },

  // ---------- IA del bando rival ----------
  // Deliberadamente simple (pedido explícito: "con el tiempo definiremos una
  // IA más compleja") — recorre a cada rival y, mientras le queden acciones,
  // hace lo más "razonable" disponible en este orden de prioridad:
  //   1. Si lleva el gnomo cogido: pasarlo a un aliado cercano (arriesgado
  //      pero da más puntos) o si no golpearlo para sumar puntos.
  //   2. Si puede atacar a algún personaje del jugador: atacarlo.
  //   3. Si hay un gnomo suelto a su alcance: cogerlo.
  //   4. Si no: acercarse al objetivo más interesante que tenga a la vista
  //      (un gnomo suelto o, si no, el personaje del jugador más cercano).
  // Si ninguna de las 4 aplica, esa unidad no hace nada más este turno (no
  // malgasta sus acciones moviéndose sin rumbo).
  async _runEnemyTurn() {
    if (typeof Tutorial !== "undefined" && Tutorial.active) return; // tutorial: rival pasivo
    const enemies = Units.list.filter((u) => u.team === "enemy");
    for (const unit of enemies) {
      for (let i = 0; i < TURNS_MAX_ACTIONS; i++) {
        if (!this.canAct(unit)) break;
        const acted = await this._aiActOnce(unit);
        if (!acted) break;
        // Pequeña pausa entre acciones para que el jugador pueda seguir lo
        // que hace cada rival, en vez de que las 2 acciones de cada uno se
        // resuelvan instantáneamente una detrás de otra.
        await new Promise((resolve) => setTimeout(resolve, 260));
      }
    }
    this._aiRunEconomyPhase();
  },

  // Pedido explícito: "los enemigos tambien pueden recoger recursos e
  // invertirlos en la armeria" + "los enemigos tambien pueden usar sus
  // puntos de gloria para comprar objetos en la tienda goblin" — al final
  // de CADA turno rival (ya con lo que hayan recolectado atacando nodos de
  // recurso este mismo turno, ver la rama nueva en _aiActOnce), gasta todo
  // lo que le llegue en mejoras de Armería y compras de la Tienda Goblin,
  // en ese orden y repitiendo mientras le siga alcanzando — nunca dentro
  // de ningún popup real (la IA no "abre" ninguna interfaz), ver
  // Armory.attemptAutoUpgrade/Shops.attemptAutoBuy.
  _aiRunEconomyPhase() {
    if (typeof Armory !== "undefined") {
      let bought = true;
      while (bought) bought = Armory.attemptAutoUpgrade("enemy");
    }
    if (typeof Shops !== "undefined") {
      let bought = true;
      while (bought) bought = Shops.attemptAutoBuy("enemy");
    }
  },

  // Ejecuta UNA acción para `unit` según la prioridad de arriba. Devuelve
  // true si de verdad hizo algo (y por tanto gastó una acción — ya la habrá
  // descontado la propia mecánica llamada, ver cabecera del archivo) o false
  // si no había nada razonable que hacer (para que _runEnemyTurn no siga
  // intentando en vano con la acción que le quedara).
  async _aiActOnce(unit) {
    if (!unit.el) return false; // pudo morir a mitad del propio turno rival

    // GnomOgro (js/gnomogro.js) — pedido explícito: "cuando el gnomogro
    // entra en juego los enemigos deben ir a intentar matarlo por todos los
    // medios, si no irá a su base y la romperá". Prioridad máxima para la
    // IA del bando CONTRARIO a la criatura: se acerca y la golpea (ataque
    // normal, o machacón si lleva un gnomo cargado de puntos) turno tras
    // turno hasta acabar con ella.
    if (typeof GnomOgro !== "undefined" && GnomOgro.current && GnomOgro.current.team !== unit.team) {
      const ogro = GnomOgro.current;
      const heldGnome = typeof Gnome !== "undefined" ? Gnome.list.find((x) => x.heldBy === unit.id) : null;
      // Un gnomo cogido a 0 puntos haría un machacón de 0 de daño: primero
      // se le golpea para cargarlo (igual que la rama de tótems de abajo).
      if (heldGnome && heldGnome.points <= 0) {
        heldGnome.hit(unit);
        return true;
      }
      if (GnomOgro.findApproachTile(unit, ogro)) {
        await GnomOgro.approachAndAttack(unit, ogro);
        return true;
      }
      // Aún no llega este turno: se acerca lo máximo posible.
      const dest = this._aiPickMoveTileToward(unit, { row: ogro.row, col: ogro.col });
      if (dest) {
        await Movement.moveTo(unit, dest.row, dest.col);
        return true;
      }
    }

    if (typeof Gnome !== "undefined") {
      const held = Gnome.list.find((g) => g.heldBy === unit.id);
      if (held) {
        // Altar de Sacrificios (js/altar.js) — pedido explícito de la
        // mecánica: "el gnomogro es del bando de la persona que le dio el
        // golpe de gracia al altar", así que la IA rival SÍ debe perseguir
        // el altar con un gnomo cogido igual que el jugador. Va antes
        // incluso que la caza de tótems de aquí abajo (spawnear una
        // criatura de 50 de vida/30 de ataque que puede acabar la partida
        // de un solo golpe pesa más que la gloria persistente de un
        // tótem), pero solo si el Altar sigue en pie (Altar.current()
        // devuelve null en cuanto se llena/desaparece).
        if (this._aiShouldSacrificeAtAltar(unit, held)) {
          const altar = Altar.current();
          const approach = Altar.findApproachTile(unit, altar);
          if (approach) {
            await Altar.approachAndSacrifice(unit, altar);
            return true;
          }
        }
        // "ahora el equipo enemigo tambien intenta capturar los totems"
        // (pedido explícito) — con el gnomo ya en la mano, un tótem que no
        // sea suyo pesa MÁS que pasar/golpear al gnomo de siempre (dan
        // gloria persistente CADA turno, no solo puntos sueltos), así que
        // esta comprobación va primero: atacar si ya está al alcance, o si
        // no acercarse un poco (la IA sigue intentándolo turno a turno en
        // vez de rendirse a la primera).
        if (typeof Villages !== "undefined") {
          const inRange = Villages.attackableBy(unit);
          // Pedido explícito: "los enemigos deben cargar de puntos al
          // gnomo antes de machacarlo contra los totems/obelisco rival. no
          // tiene sentido hacerlo si lleva 0 puntos cargados" — antes
          // atacaba en cuanto tenía un tótem al alcance sin mirar los
          // puntos del gnomo (un golpe de 0 de daño). Con un tótem al
          // alcance pero el gnomo todavía a 0, cae a la rama de
          // golpear/pasar de más abajo (misma que "sin tótem al alcance")
          // en vez de malgastar el turno en un golpe que no hace nada.
          if (inRange && held.points > 0) {
            await Villages.attack(unit, inRange);
            return true;
          }
          if (!inRange) {
            const nearest = Villages.nearestUnowned(unit);
            if (nearest) {
              const dest = this._aiPickMoveTileToward(unit, nearest);
              if (dest) {
                await Movement.moveTo(unit, dest.row, dest.col);
                return true;
              }
            }
          }
        }
        const ally = Units.list.find(
          (u) =>
            u.team === "enemy" &&
            u.id !== unit.id &&
            Math.max(Math.abs(u.row - unit.row), Math.abs(u.col - unit.col)) <=
              UNIT_TYPES[unit.typeId].movimiento + 2
        );
        if (ally && Math.random() < 0.5) {
          await held.executePass(unit, ally);
        } else {
          held.hit(unit);
        }
        return true;
      }
    }

    if (!TURNS_SANDBOX_NO_ENEMY_ATTACK && typeof Combat !== "undefined") {
      const targets = Combat.attackableEnemies(unit);
      if (targets.length > 0) {
        await Combat.approachAndAttack(unit, targets[0].target);
        return true;
      }
    }

    // Setas explosivas (js/mushrooms.js) — la IA la lleva al Altar si puede
    // llegar a tiempo; si no, la coge solo cuando el altar está cerca.
    if (typeof Mushrooms !== "undefined" && typeof Altar !== "undefined") {
      const carried = Mushrooms.carriedBy(unit);
      const altar = Altar.current();
      if (carried && altar) {
        if (Altar.findApproachTile(unit, altar)) {
          await Altar.approachAndSacrifice(unit, altar);
          return true;
        }
        const dest = this._aiPickMoveTileToward(unit, { row: altar.row, col: altar.col });
        if (dest) {
          await Movement.moveTo(unit, dest.row, dest.col);
          return true;
        }
      } else if (!carried && altar && !(typeof Gnome !== "undefined" && Gnome.isHeldBy(unit.id))) {
        const reach = UNIT_TYPES[unit.typeId].movimiento * 2 + 1;
        const m = Mushrooms.list.find(
          (x) =>
            !x.heldBy &&
            Math.max(Math.abs(x.row - altar.row), Math.abs(x.col - altar.col)) <= reach + 1 &&
            Mushrooms.canCatch(unit, x)
        );
        if (m) {
          await Mushrooms.catchBy(unit, m);
          return true;
        }
      }
    }

    if (typeof Gnome !== "undefined") {
      // Señuelo Explosivo (js/backpack.js) — "el enemigo lo ve con el
      // sprite normal del gnomo" así que la IA lo persigue exactamente
      // igual que a un gnomo de verdad (misma búsqueda de siempre, sin
      // tratarlo aparte), salvo su PROPIO señuelo: eso sería la IA cayendo
      // en su propia trampa, así que se excluye igual que
      // GnomeInstance._showCatchMarkerFor hace para el jugador.
      const looseGnome = Gnome.list.find(
        (g) => !g.heldBy && !(g.isDecoy && g.ownerTeam === unit.team) && g.findApproachTile(unit)
      );
      if (looseGnome) {
        await looseGnome.catchBy(unit);
        return true;
      }
    }

    // Pedido explícito: "los enemigos tambien pueden recoger recursos e
    // invertirlos en la armeria" — última prioridad antes de simplemente
    // acercarse (nunca antepone la economía a un enemigo/gnomo/tótem ya al
    // alcance, ver las ramas de arriba), pero mejor que no hacer nada:
    // ataca el nodo de recurso alcanzable más cercano, mismo mecanismo que
    // ya usa el jugador (Resources.findApproachTile/attack).
    if (typeof Resources !== "undefined" && Resources.list.length > 0) {
      const node = Resources.list
        .filter((n) => Resources.findApproachTile(unit, n))
        .reduce((best, n) => {
          const d = Math.max(Math.abs(n.row - unit.row), Math.abs(n.col - unit.col));
          return !best || d < best.d ? { node: n, d } : best;
        }, null);
      if (node) {
        await Resources.approachAndAttack(unit, node.node);
        return true;
      }
    }

    const dest = this._aiPickMoveTile(unit);
    if (dest) {
      await Movement.moveTo(unit, dest.row, dest.col);
      return true;
    }

    return false;
  },

  // Elige la loseta alcanzable (dentro del propio movimiento) que más
  // acerque a `unit` a su objetivo más interesante — un gnomo suelto si hay
  // alguno, o si no el personaje del jugador más cercano. Reutiliza
  // Movement.reachableTiles (mismo cálculo que ya usa el jugador) en vez de
  // duplicar la comprobación de casillas ocupadas/con niebla.
  _aiPickMoveTile(unit) {
    let target = null;
    // Señuelo Explosivo (js/backpack.js) — mismo criterio que arriba: nunca
    // se acerca a su propia trampa (sería un desperdicio de movimiento,
    // aparte de raro de ver).
    const looseGnomes =
      typeof Gnome !== "undefined" ? Gnome.list.filter((g) => !g.heldBy && !(g.isDecoy && g.ownerTeam === unit.team)) : [];
    if (looseGnomes.length > 0) {
      target = looseGnomes
        .reduce((best, g) => {
          const d = Math.max(Math.abs(g.row - unit.row), Math.abs(g.col - unit.col));
          return !best || d < best.d ? { row: g.row, col: g.col, d } : best;
        }, null);
    }
    if (!target) {
      target = Units.list
        .filter((u) => u.team === "player")
        .reduce((best, u) => {
          const d = Math.max(Math.abs(u.row - unit.row), Math.abs(u.col - unit.col));
          return !best || d < best.d ? { row: u.row, col: u.col, d } : best;
        }, null);
    }
    return this._aiPickMoveTileToward(unit, target);
  },

  // Misma elección de "la loseta alcanzable que más acerca a `unit` a
  // `target` (fila/columna)" de arriba, pero ya separada del cálculo de
  // CUÁL es el objetivo — así _aiPickMoveTile (gnomos sueltos / rival más
  // cercano) y la aproximación a un tótem (ver _aiActOnce) comparten el
  // mismo criterio de acercamiento sin duplicar el bucle.
  _aiPickMoveTileToward(unit, target) {
    if (typeof Movement === "undefined" || !target) return null;
    const tiles = Movement.reachableTiles(unit);
    if (tiles.length === 0) return null;

    let best = null;
    let bestDist = Infinity;
    tiles.forEach((t) => {
      const d = Math.max(Math.abs(t.row - target.row), Math.abs(t.col - target.col));
      if (d < bestDist) {
        bestDist = d;
        best = t;
      }
    });
    // Si ya está tan cerca como puede llegar a estar (ninguna loseta
    // alcanzable mejora la distancia actual), no malgasta la acción
    // moviéndose sin necesidad.
    const currentDist = Math.max(Math.abs(unit.row - target.row), Math.abs(unit.col - target.col));
    if (best && bestDist >= currentDist) return null;
    return best;
  },
};
