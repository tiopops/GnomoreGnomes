/* Gnomore Gnomes — mecánica de combate.
   Regla de oro: un archivo por mecánica. Este archivo solo sabe qué rivales
   puede atacar la unidad del jugador seleccionada, pintar la mira de
   ataque, acercarse (si hace falta) y resolver el golpe — todo lo demás
   (selección, pintado, desplazamiento paso a paso, marcadores genéricos,
   vida/feedback compartido) vive en js/units.js y se reutiliza desde aquí.

   Se registra como "proveedor de rango" igual que js/movement.js — ninguno
   de los dos archivos sabe que el otro existe, ambos hablan solo con
   Units. Esto es lo que permite, por ejemplo, cambiar el combate a distancia
   para otro tipo de unidad sin arriesgarse a romper el movimiento. */

const Combat = {
  // IDs de rivales que están mostrando su barra de vida "forzada" (por estar
  // dentro del rango de la unidad seleccionada, no por estar ellos mismos
  // seleccionados) — se limpia en onClear() para que Units.clearRangeOverlays
  // pueda deshacer este efecto secundario sin saber que existe.
  targetedIds: [],

  // IDs de rivales temblando de miedo ahora mismo por estar a punto de
  // morir del golpe de la unidad seleccionada (ver showFor/onClear más
  // abajo) — mismo patrón que targetedIds, una lista aparte porque no todo
  // objetivo válido está además condenado a morir de este golpe concreto.
  doomedIds: [],

  // Esta unidad pega cuerpo a cuerpo: para golpear tiene que terminar a 1
  // casilla del rival (attackRange), sea cual sea su alcance de movimiento.
  // Busca la loseta libre más cercana a `unit` desde la que `target` ya
  // esté dentro de attackRange; si `unit` ya está a esa distancia, devuelve
  // su propia casilla (no hace falta moverse). Devuelve null si ni
  // quedándose quieta ni movi��ndose puede llegar a pegarle.
  findApproachTile(unit, target) {
    const type = UNIT_TYPES[unit.typeId];
    const moveRange = type.movimiento;
    const attackRange = type.attackRange;

    const distToTarget = (row, col) =>
      Math.max(Math.abs(row - target.row), Math.abs(col - target.col));

    if (distToTarget(unit.row, unit.col) <= attackRange) {
      return { row: unit.row, col: unit.col };
    }

    let best = null;
    let bestDist = Infinity;
    for (let row = 0; row < Units.boardSize; row++) {
      for (let col = 0; col < Units.boardSize; col++) {
        if (row === unit.row && col === unit.col) continue;
        if (distToTarget(row, col) > attackRange) continue;
        if (Units.unitAt(row, col)) continue; // ocupada (por el propio rival u otra unidad)
        if (typeof Gnome !== "undefined" && Gnome.isAt(row, col)) continue; // ocupada por el gnomo (js/gnome.js)
        if (typeof Villages !== "undefined" && Villages.at(row, col)) continue; // poblado (js/villages.js)
        if (typeof Shops !== "undefined" && Shops.at(row, col)) continue; // Tienda Goblin (js/shops.js)
        if (typeof Obelisks !== "undefined" && Obelisks.at(row, col)) continue; // Obelisco Ancestral (js/obelisks.js)
        if (typeof Altar !== "undefined" && Altar.at(row, col)) continue; // Altar de Sacrificios (js/altar.js)
        if (typeof GnomOgro !== "undefined" && GnomOgro.at(row, col)) continue; // GnomOgro (js/gnomogro.js): casilla ocupada
        if (typeof Resources !== "undefined" && Resources.at(row, col)) continue; // Recursos de escenario (js/resources.js)
        if (typeof TerrainMap !== "undefined" && !(typeof Skills !== "undefined" ? Skills.walkableFor(unit.team, row, col) : TerrainMap.isWalkable(row, col))) continue; // agua (js/mapgen.js)
        const moveDist = Math.max(Math.abs(row - unit.row), Math.abs(col - unit.col));
        if (moveDist > moveRange || (typeof Skills !== "undefined" && Skills.moveCost(unit, row, col) > moveRange)) continue;
        // Pedido explícito: "bajo ningun concepto un personaje puede
        // moverse a traves de una casilla de agua" — ver Units.pathIsWalkable
        // (units.js): el destino ya se comprueba arriba, pero el camino recto
        // hasta él también tiene que estar libre de agua en cualquier punto
        // intermedio, no solo al llegar.
        if (!Units.pathIsWalkable(unit.row, unit.col, row, col, unit.team)) continue;
        if (moveDist < bestDist) {
          bestDist = moveDist;
          best = { row, col };
        }
      }
    }
    return best;
  },

  // Rivales que `unit` puede llegar a atacar este turno (quedándose quieta o
  // moviéndose), junto con la loseta desde la que golpearía cada uno.
  attackableEnemies(unit) {
    const targets = [];
    Units.list.forEach((other) => {
      if (other.team === unit.team) return;
      // Niebla de guerra (js/fog.js) — pedido explícito: "el jugador no
      // puede ver lo que hay tras ella... puede que haya un enemigo... pero
      // hasta que no se despeje no se sabrá". Un rival de pie sobre una
      // loseta todavía sin revelar no se puede atacar aunque caiga dentro
      // del alcance — ya está oculto visualmente por la propia niebla
      // (z-index por encima de todo, ver mapgen.js), esto evita además que
      // se pueda "atacar a ciegas" algo que no se ve.
      if (unit.team === "player" && typeof Fog !== "undefined" && Fog.isFogged(other.row, other.col)) return;
      // CORRECCIÓN (pedido explícito): "si un enemigo esta dentro de la
      // niebla de guerra no deberia poder atacarlo" — el Fog.isFogged de
      // arriba solo descarta una loseta que NUNCA se ha explorado; una
      // loseta ya explorada mucho antes pero fuera del alcance de
      // percepción ACTUAL de mis unidades también oculta al rival de pie
      // ahí (se vuelve invisible de verdad, unit--fog-hidden, ver
      // Fog.applyVisibility), pero seguía contando como "atacable" porque
      // técnicamente su loseta ya no está fogged. Un rival así no debe
      // poder atacarse a ciegas, igual que uno sobre niebla sin explorar.
      if (unit.team === "player" && other.el && other.el.classList.contains("unit--fog-hidden")) return;
      // Arbustos (js/bushes.js) — mismo criterio que la niebla: un rival
      // escondido dentro de un arbusto (a ojos de `unit`) tampoco se puede
      // atacar hasta que se revele (emboscada al pisarlo, o que se mueva por
      // su cuenta), aunque su loseta ya esté explorada de antes.
      if (typeof Bushes !== "undefined" && Bushes.isHiddenFromTeam(other.row, other.col, unit.team)) return;
      const approach = this.findApproachTile(unit, other);
      if (!approach) return;
      // Pedido explícito: "si un enemigo esta dentro del area de movimiento
      // y pulso atacar, el personaje se mueve y ataca, eso son dos
      // acciones" — si hace falta moverse primero (approach distinto de la
      // casilla actual), esta mira de ataque ya no se ofrece con una sola
      // acción restante: no llegaría para las dos (mover + golpear). Sin
      // moverse (ya está a distancia) sigue costando una sola acción, como
      // siempre — ver approachAndAttack/attack más abajo, que son quienes
      // de verdad gastan las acciones.
      const needsMove = approach.row !== unit.row || approach.col !== unit.col;
      if (needsMove && typeof Turns !== "undefined" && !(typeof Skills !== "undefined" ? Skills.canApproachAttack(unit) : Turns.remainingActions(unit) >= 2)) return;
      targets.push({ target: other, approach });
    });
    return targets;
  },

  // La mira de ataque se pinta sobre la PROPIA loseta del rival (como una
  // mira bajo sus pies) — quien se mueve es el atacante: al hacer clic, se
  // coloca en la casilla adyacente al rival más cercana a su posición
  // actual (ver approachAndAttack/findApproachTile) y golpea desde ahí,
  // todo en el mismo clic. zOffset se deja explícitamente por DEBAJO del
  // z-index con el que se pintan las unidades ((row+col)*10 + 5, ver
  // _placeInstant/hopTo en units.js) para que el sprite del rival quede por
  // delante de la mira, no al revés — la mira es más grande que el propio
  // sprite (ver .attack-marker en style.css) precisamente para que sus
  // bordes asomen por detrás del personaje y sigan siendo clicables ahí,
  // aunque la silueta central quede tapada por él.
  attackMarkerTile(target) {
    return { row: target.row, col: target.col };
  },

  showFor(unit) {
    // Turnos (js/turns.js) — pedido explícito: cada personaje tiene 2
    // acciones por turno ("pegar una vez a un enemigo" es una de ellas); si
    // ya no puede actuar (las gastó, o no es su turno) no se ofrece ninguna
    // mira de ataque. typeof por si turns.js todavía no ha cargado (o una
    // herramienta de debug no lo incluye) — igual que el resto de comprobaciones
    // "typeof X !== undefined" de este proyecto.
    if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return;
    // Mientras lleva al gnomo cogido (js/gnome.js) la unidad pierde la
    // capacidad de atacar — puede moverse, golpear al gnomo o pasarlo, pero
    // no repartir daño a la vez que lo lleva encima.
    if (typeof Gnome !== "undefined" && Gnome.isHeldBy(unit.id)) return;
    // Daño que haría ESTE golpe (misma fórmula que attack() más abajo) —
    // hace falta ya aquí, antes de golpear de verdad, para saber qué
    // rivales morirían con él (ver unit--doomed más abajo).
    const damage = UNIT_TYPES[unit.typeId].fuerza + (typeof Armory !== "undefined" ? Armory.attackBonus(unit.team) : 0);
    this.attackableEnemies(unit).forEach(({ target, approach }, i) => {
      const tile = this.attackMarkerTile(target);
      Units.addMarker({
        className: "attack-marker",
        row: tile.row,
        col: tile.col,
        zOffset: 2,
        delayIndex: i,
        visibleClass: "attack-marker--visible",
        buildContent: (marker) => {
          const icon = document.createElement("i");
          icon.className = "ph ph-crosshair-simple attack-marker__icon";
          marker.appendChild(icon);
        },
        onClick: () => this.approachAndAttack(unit, target),
      });

      target.el.classList.add("unit--targeted");
      this.targetedIds.push(target.id);

      // Pedido explícito: "si un enemigo está al alcance y ese enemigo
      // moriría por el ataque del personaje seleccionado, dicho enemigo
      // empiece a temblar de miedo y que se gire de un lado a otro como hace
      // el gnomo". target.hp <= damage -> este golpe (sin acumular ningún
      // otro) ya lo mataría del todo.
      const dmgHere = damage + (typeof Skills !== "undefined" ? Skills.attackBonus(unit, target) : 0);
      if (target.hp <= dmgHere) {
        target.el.classList.add("unit--doomed");
        Units.startFearLoop(target);
        this.doomedIds.push(target.id);
      }
    });
  },

  onClear() {
    this.targetedIds.forEach((id) => {
      const unit = Units.list.find((u) => u.id === id);
      if (unit) unit.el.classList.remove("unit--targeted");
    });
    this.targetedIds = [];

    this.doomedIds.forEach((id) => {
      const unit = Units.list.find((u) => u.id === id);
      if (unit) {
        unit.el.classList.remove("unit--doomed");
        Units.stopFearLoop(unit);
      }
    });
    this.doomedIds = [];
  },

  async approachAndAttack(unit, target) {
    Units.clearRangeOverlays();
    const approach = this.findApproachTile(unit, target);
    if (!approach) return; // el rival se movió/murió justo antes del clic
    if (approach.row !== unit.row || approach.col !== unit.col) {
      // Pedido explícito: "si un enemigo esta dentro del area de movimiento
      // y pulso atacar, el personaje se mueve y ataca, eso son dos
      // acciones" — attackableEnemies ya se aseguró de no ofrecer esta mira
      // si no quedaban las 2 acciones necesarias, pero se repite aquí por
      // seguridad (mismo patrón defensivo que el resto del archivo, ver
      // attack() más abajo) antes de gastar nada. El movimiento consume su
      // propia acción, igual que un movimiento normal (ver Movement.moveTo)
      // — la segunda la gasta attack() más abajo, en el golpe en sí.
      if (typeof Turns !== "undefined" && !Turns.canAct(unit)) return;
      const path = Units.stepPath(unit.row, unit.col, approach.row, approach.col);
      await Units.walkPath(unit, path);
      // Embestir (js/skills.js): mover + golpear por una sola acción, 1 vez por turno.
      if (typeof Skills !== "undefined") Skills.spendApproach(unit);
      else if (typeof Turns !== "undefined") Turns.useAction(unit);
      // Mismo bug que en GnomeInstance.catchBy (js/gnome.js): acercarse
      // para atacar tampoco revelaba niebla nueva al detenerse, por la
      // misma razón (Units.walkPath no revela, solo reevalúa lo ya
      // revelado). Se corrige igual aquí para que "acercarse + golpear" no
      // se quede corto de visión al llegar.
      if (typeof Fog !== "undefined" && unit.team === "player") Fog.revealForUnit(unit);
    }
    // Habilidad pasiva de PuñoRoca (Units.walkPath -> _applyPunorocaWobble,
    // js/units.js) — pedido explícito: "si atacase sin un urgamentes al
    // lado a un personaje y el segundo y tercer movimiento lo alejan del
    // area de la que pueda pegar...entonces no le pega al enemigo". El
    // camino real pudo acabar dando tumbos lejos de la casilla de
    // aproximación calculada arriba, así que se reconfirma la distancia YA
    // MOVIDO antes de golpear en vez de asumir que llegó donde tocaba.
    const type = UNIT_TYPES[unit.typeId];
    const distNow = Math.max(Math.abs(unit.row - target.row), Math.abs(unit.col - target.col));
    if (distNow > type.attackRange) return;
    await this.attack(unit, target);
  },

  async attack(attacker, target) {
    // Turnos (js/turns.js) — comprobación defensiva además del gate en
    // showFor: approachAndAttack puede llegar aquí desde un marcador que ya
    // estaba pintado en pantalla justo cuando se agotó la acción (p.ej. la
    // IA rival encadenando ataques), así que se repite aquí por seguridad.
    if (typeof Turns !== "undefined" && !Turns.canAct(attacker)) return;
    Units.faceTowardsTile(attacker, target.row, target.col);

    // Golpear cuenta como UNA de las 2 acciones del turno (pedido explícito:
    // "pegar una vez a un enemigo") — se gasta aquí, en el golpe en sí, no en
    // approachAndAttack: acercarse antes de golpear no es una acción aparte,
    // es parte de la misma.
    if (typeof Turns !== "undefined") Turns.useAction(attacker);

    // El daño depende de la FUERZA del atacante (una de sus 4 estadísticas,
    // ver UNIT_TYPES en units.js) en vez de ser siempre 1 — así cada tipo de
    // unidad pega de verdad distinto, no solo se mueve distinto.
    // Rama GUERRA (js/skills.js): Camaradas, Sed de Sangre, Último Aliento y
    // Emboscada suman ataque extra.
    const damage =
      UNIT_TYPES[attacker.typeId].fuerza +
      (typeof Armory !== "undefined" ? Armory.attackBonus(attacker.team) : 0) +
      (typeof Skills !== "undefined" ? Skills.attackBonus(attacker, target) : 0);
    // Habilidades de PROTECCIÓN (js/skills.js): Evasión/Escudo/Piel de Roca
    // pueden anular el golpe; si no, hace el daño de siempre (barra, texto,
    // temblor y sonido los pone Skills.resolveDamage).
    const outcome =
      typeof Skills !== "undefined"
        ? Skills.resolveDamage(target, damage, { melee: true })
        : (() => {
            target.hp = Math.max(0, target.hp - damage);
            Units.updateHpBar(target);
            Units.spawnFloatingText(target, `-${damage}`, { className: "dmg-popup" });
            Units.playShake(target);
            SFX.hit();
            return { prevented: false };
          })();

    // Retroalimentación en QUIEN GOLPEA, no solo en quien lo recibe (regla
    // de oro del proyecto: todo necesita sonido y/o animación coherente con
    // la acción) — reutiliza el mismo puñetazo corto que Gnome.hit
    // (unit--punching, ver style.css: sustituye a la respiración continua
    // mientras dura, nunca se mezcla con ella), sincronizado con el mismo
    // golpe de sonido y el temblor de quien lo recibe.
    if (attacker.el) {
      attacker.el.classList.remove("unit--punching");
      void attacker.spriteEl.offsetWidth;
      attacker.el.classList.add("unit--punching");
      setTimeout(() => attacker.el.classList.remove("unit--punching"), 320);
    }

    // Habilidad "Golem de Espinas" (GolemCorteza, js/abilities.js) — "si un
    // enemigo le golpea se hace un punto de daño a si mismo tambien":
    // target.thorny se comprueba en CADA golpe que reciba mientras dure
    // (caduca sola al llegar el siguiente turno de su equipo, ver
    // Abilities.onTurnStart en abilities.js). Si eso deja al propio
    // atacante a 0, muere IGUAL que cualquier otra baja (mismo
    // removeUnit/dropHeldBy/Gloria de abajo, solo que el crédito va para el
    // equipo de `target`, no el de `attacker` — fue su espina la que lo
    // mató).
    // Golpe anulado (esquiva/escudo/piel de roca): sin espinas ni empujón.
    if (outcome.prevented) {
      Units.refreshRange(attacker);
      return;
    }
    let attackerDiedFromThorns = false;
    // "Armadura de Espinas" (js/skills.js) funciona igual que las espinas del
    // GolemCorteza: 1 punto de daño al que golpea.
    if ((target.thorny || (typeof Skills !== "undefined" && Skills.hasThorns(target))) && attacker.hp > 0) {
      attacker.hp = Math.max(0, attacker.hp - 1);
      Units.updateHpBar(attacker);
      Units.spawnFloatingText(attacker, "-1", { className: "dmg-popup" });
      Units.playShake(attacker);
      if (attacker.hp <= 0) attackerDiedFromThorns = true;
    }
    if (attackerDiedFromThorns) {
      if (typeof Glory !== "undefined") Glory.queueKillBonus(target.team);
      await Units.removeUnit(attacker);
      if (typeof Gnome !== "undefined") await Gnome.dropHeldBy(attacker);
    }

    if (target.hp <= 0) {
      // Pedido explícito sobre el ORDEN: "primero, el enemigo muere, luego
      // el gnomo aparece en la casilla en la que murió y luego el gnomo
      // huye. en ese orden" — así que Units.removeUnit (animación de muerte
      // completa) va PRIMERO, y solo cuando termina se llama a
      // Gnome.dropHeldBy (que hace aparecer el gnomo y lo pone a huir).
      // Units.removeUnit NO borra target.row/target.col (solo quita el
      // elemento del DOM y de Units.list), así que dropFromDyingUnit sigue
      // pudiendo leer dónde murió aunque ya no esté en la lista — de ahí que
      // siga recibiendo `target` como parámetro en vez de tener que buscarlo.
      // Gnome.dropHeldBy no hace nada si `target` no llevaba ningún gnomo
      // encima, así que siempre es seguro llamarlo aquí sin comprobar antes.
      // Puntos de Gloria (js/glory.js) — pedido explícito: "matar a 1
      // enemigo genera +1 punto de gloria al comienzo del turno". Se
      // registra aquí, en el instante exacto en que la baja se confirma
      // (equipo de QUIEN ATACA, no de la víctima) — Glory ya se encarga de
      // no sumarlo a los puntos "de verdad" hasta el próximo inicio de
      // turno de ese equipo.
      if (typeof Glory !== "undefined") Glory.queueKillBonus(attacker.team);
      if (typeof Skills !== "undefined") Skills.onKill(attacker);
      await Units.removeUnit(target);
      if (typeof Gnome !== "undefined") await Gnome.dropHeldBy(target);
    } else if (!attackerDiedFromThorns) {
      // Si las espinas ya se lo llevaron por delante (ver arriba), no hay
      // quien empuje a `target` ni cuyo rango refrescar más abajo.
      await this.pushBack(attacker, target);
    }

    if (typeof Skills !== "undefined") Skills.refreshCohesion();
    if (!attackerDiedFromThorns) Units.refreshRange(attacker);
  },

  // Empujón: se restan las FUERZAs (atacante - objetivo) y, si sale positivo,
  // el objetivo retrocede esa cantidad de casillas en línea recta en la
  // dirección del golpe (desde el atacante hacia el objetivo, prolongada más
  // allá) — un atacante mucho más fuerte aparta al rival de un golpe, uno
  // más débil o igual de fuerte no consigue moverlo ni un poco (0 o menos =
  // sin efecto). Se para en el primer obstáculo (borde del tablero, otra
  // unidad o el gnomo) en vez de saltárselo.
  async pushBack(attacker, target) {
    const attackerBonus = typeof Armory !== "undefined" ? Armory.attackBonus(attacker.team) : 0;
    const push = UNIT_TYPES[attacker.typeId].fuerza + attackerBonus - UNIT_TYPES[target.typeId].fuerza;
    if (push <= 0) return;

    const dRow = Math.sign(target.row - attacker.row);
    const dCol = Math.sign(target.col - attacker.col);
    if (dRow === 0 && dCol === 0) return;

    const path = [];
    let drowns = false;
    let row = target.row;
    let col = target.col;
    for (let i = 0; i < push; i++) {
      const nextRow = row + dRow;
      const nextCol = col + dCol;
      if (nextRow < 0 || nextCol < 0 || nextRow >= Units.boardSize || nextCol >= Units.boardSize) break;
      if (Units.unitAt(nextRow, nextCol)) break;
      if (typeof Gnome !== "undefined" && Gnome.isAt(nextRow, nextCol)) break;
      if (typeof Villages !== "undefined" && Villages.at(nextRow, nextCol)) break; // poblado (js/villages.js)
      if (typeof Shops !== "undefined" && Shops.at(nextRow, nextCol)) break; // Tienda Goblin (js/shops.js)
      if (typeof Obelisks !== "undefined" && Obelisks.at(nextRow, nextCol)) break; // Obelisco Ancestral (js/obelisks.js)
      if (typeof Altar !== "undefined" && Altar.at(nextRow, nextCol)) break; // Altar de Sacrificios (js/altar.js)
      if (typeof GnomOgro !== "undefined" && GnomOgro.at(nextRow, nextCol)) break; // GnomOgro (js/gnomogro.js): casilla ocupada
      if (typeof Resources !== "undefined" && Resources.at(nextRow, nextCol)) break; // Recursos de escenario (js/resources.js)
      path.push({ row: nextRow, col: nextCol });
      row = nextRow;
      col = nextCol;
      // Cae al agua: sin Anfibio no puede seguir, se ahoga ahí (ver _drown).
      if (typeof TerrainMap !== "undefined" && !TerrainMap.isWalkable(nextRow, nextCol)) {
        if (!(typeof Skills !== "undefined" && Skills.has(target.team, "anfibio"))) drowns = true;
        break;
      }
    }
    if (path.length === 0) return;

    // Empuje propio (no Units.walkPath): un empujón no es una decisión del
    // propio personaje, así que NO se le hace girar para "mirar" hacia donde
    // retrocede (a diferencia de un movimiento normal) — se queda mirando de
    // frente a quien le ha golpeado, solo que unas casillas más atrás. Más
    // rápido que un paso normal (140ms) para que se lea como un golpe seco,
    // no como una decisión pausada.
    const PUSH_MS = 140;
    target.el.classList.add("unit--moving");
    for (const step of path) {
      // Pedido explícito (con capturas): "algunas unidades se siguen
      // asomando a traves de la niebla" — este bucle tenía su propio
      // setTimeout adivinando cuándo terminaba la transición CSS de
      // left/top (igual que tenía Units.hopTo antes de arreglarlo, ver la
      // nota larga junto a Units.awaitPositionSettle), así que se reutiliza
      // el mismo mecanismo en vez de duplicar el problema aquí.
      const prevLeft = target.el.style.left;
      const prevTop = target.el.style.top;
      if (typeof Bushes !== "undefined") Bushes.clearHiddenUnit(target.id); // empujado fuera del arbusto
      target.row = step.row;
      target.col = step.col;
      const { x, y } = getTileCenter(step.row, step.col, Units.boardSize);
      target.el.style.left = `${x}px`;
      target.el.style.top = `${y}px`;
      target.el.style.zIndex = String((step.row + step.col) * 10 + 5);
      target.spriteEl.classList.remove("unit__sprite--hop");
      void target.spriteEl.offsetWidth;
      target.spriteEl.classList.add("unit__sprite--hop");
      SFX.hop();
      await Units.awaitPositionSettle(target.el, prevLeft, prevTop, PUSH_MS);
    }
    target.el.classList.remove("unit--moving");
    target.spriteEl.classList.remove("unit__sprite--hop");
    // Niebla de guerra y demás "oclusión detrás de..." (js/fog.js,
    // js/villages.js, js/obelisks.js, js/bushes.js, js/shops.js) — pedido
    // explícito (con capturas): "algunas unidades se siguen asomando a
    // traves de la niebla". Este empujón puede terminar dejando a `target`
    // en una loseta nueva (fogosa, detrás de un tótem/Obelisco, junto a un
    // arbusto o la Tienda Goblin) igual que cualquier otro desplazamiento
    // del proyecto, pero al no pasar por Units.walkPath (ver la nota de
    // arriba: un empujón no gira al personaje, walkPath sí) se había
    // quedado sin el mismo refresco final que ese sí hace siempre — mismo
    // conjunto exacto de llamadas, mismo orden.
    if (path.length > 0) {
      if (typeof Fog !== "undefined") Fog.applyVisibility();
      if (typeof Villages !== "undefined") Villages.refreshOcclusion();
      if (typeof Obelisks !== "undefined") Obelisks.refreshOcclusion();
    if (typeof Altar !== "undefined") Altar.refreshOcclusion();
      if (typeof Bushes !== "undefined") Bushes.refreshOcclusion();
      if (typeof Units !== "undefined") Units.refreshUnitOcclusion();
      if (typeof Shops !== "undefined") Shops.refreshAll();
    }
    if (drowns) await this._drown(attacker, target);
  },

  // Pedido explícito: empujado al agua sin la habilidad Anfibio -> chapuzón y
  // muere ahogado (sin charco de sangre). Si llevaba un gnomo, este cae a la
  // casilla seca libre más cercana y hace su huida de siempre.
  async _drown(attacker, target) {
    const row = target.row;
    const col = target.col;
    if (typeof SFX !== "undefined" && SFX.splash) SFX.splash();
    this._spawnSplash(row, col);
    if (typeof Glory !== "undefined") Glory.queueKillBonus(attacker.team);
    if (typeof Skills !== "undefined") Skills.onKill(attacker);
    await Units.removeUnit(target, { drowned: true });
    if (typeof Gnome !== "undefined" && Gnome.isHeldBy && Gnome.isHeldBy(target.id)) {
      const land = this._findDryTileNear(row, col);
      await Gnome.dropHeldBy(land ? { id: target.id, row: land.row, col: land.col } : target);
    }
  },

  _findDryTileNear(row, col) {
    let best = null;
    let bestD = Infinity;
    for (let r = 0; r < Units.boardSize; r++) {
      for (let c = 0; c < Units.boardSize; c++) {
        const d = Math.max(Math.abs(r - row), Math.abs(c - col));
        if (d === 0 || d >= bestD || d > 4) continue;
        if (typeof TerrainMap !== "undefined" && !TerrainMap.isWalkable(r, c)) continue;
        if (Units.unitAt(r, c)) continue;
        if (typeof Gnome !== "undefined" && Gnome.isAt(r, c)) continue;
        if (typeof Villages !== "undefined" && Villages.at(r, c)) continue;
        if (typeof Shops !== "undefined" && Shops.at(r, c)) continue;
        if (typeof Obelisks !== "undefined" && Obelisks.at(r, c)) continue;
        if (typeof Altar !== "undefined" && Altar.at(r, c)) continue;
        if (typeof GnomOgro !== "undefined" && GnomOgro.at(r, c)) continue;
        if (typeof Resources !== "undefined" && Resources.at(r, c)) continue;
        bestD = d;
        best = { row: r, col: c };
      }
    }
    return best;
  },

  _spawnSplash(row, col) {
    const el = document.createElement("div");
    el.className = "water-splash";
    for (let i = 0; i < 2; i++) {
      const ring = document.createElement("span");
      ring.className = "water-splash__ring";
      ring.style.animationDelay = `${i * 0.18}s`;
      el.appendChild(ring);
    }
    for (let i = 0; i < 7; i++) {
      const drop = document.createElement("i");
      drop.className = "water-splash__drop";
      drop.style.setProperty("--dx", `${(i - 3) * 11}px`);
      drop.style.animationDelay = `${(i % 3) * 0.04}s`;
      el.appendChild(drop);
    }
    Units.container.appendChild(el);
    const { x, y } = getTileCenter(row, col, Units.boardSize);
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    el.style.zIndex = String((row + col) * 10 + 8);
    setTimeout(() => el.remove(), 1200);
  },
};

Units.registerRangeProvider(Combat);
