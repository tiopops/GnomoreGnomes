/* Gnomore Gnomes — Puntos de Gloria.
   Regla de oro: un archivo por mecánica. Este archivo SOLO sabe:
     - Cuántos Puntos de Gloria tiene cada equipo ("player" | "enemy").
     - Pintar el marcador de la esquina superior izquierda para cada equipo,
       con el icono de SU raza (RACES[].gloryIcon, ver js/races.js).
     - Sumar puntos al empezar cada turno (Glory.grantTurnStart, llamado
       desde js/turns.js — ver Turns.reset/Turns.endTurn), incluyendo el
       bonus por bajas conseguidas durante el turno anterior
       (Glory.queueKillBonus, llamado desde js/combat.js al matar).

   Pedido explícito: "Vamos a introducir la mecanica de PUNTOS DE GLORIA, un
   marcador situado arriba la izquierda con un icono distinto para cada raza
   indicara los puntos de gloria, estos puntos permitiran construir
   unidades/edificios desde la base principal cuando las haya y comprar
   mejoras en el arbol de talentos, de momento vamos a implementar el icono
   qye muestre los puntos en una interfaz con un diseño espectacular, lo
   demas lo haremos mas tarde" — así que, DE MOMENTO, este archivo es
   puramente de visualización + generación automática; gastar puntos
   (construir, mejorar) se añadirá más adelante en otra pasada.

   Pedido explícito: "al comienzo de cada turno se generan automaticamente 2
   puntos de gloria... luego añadiremos mecanicas que van sumando mas puntos
   de gloria al comienzo del turno" — GLORY_PER_TURN_START vive como
   constante aparte a propósito, para que sumar más fuentes en el futuro sea
   tocar esto, no reescribir la lógica de turno.

   Pedido explícito (segunda pasada): "matar a 1 enemigo genera +1 punto de
   gloria al comienzo del turno" — el bonus se ACUMULA en cuanto se
   confirma la baja (queueKillBonus, llamado desde Combat.attack) pero no
   se suma a los puntos "de verdad" hasta que empieza el turno de ese
   equipo (grantTurnStart), exactamente igual que el resto de fuentes de
   este archivo: todo pasa por el mismo grifo del inicio de turno.

   Los puntos se llevan la cuenta para LOS DOS equipos (el rival también los
   necesitará el día que su IA construya/mejore algo), pero el marcador en
   pantalla ("un marcador situado arriba la izquierda", en singular) es solo
   el del JUGADOR — como el resto de HUD de este juego, no se le enseña al
   jugador el recurso del rival. */

const GLORY_PER_TURN_START = 2;
const GLORY_PER_KILL = 1;

// Pedido explícito: "vamos a limitarlo a 30... se marcarán como X/30; al llegar a
// 30/30 ya no podrán subir más, se verán en rojo y el marcador palpitará" —
// tope de gloria guardada: lo que sobra al empezar el turno se pierde, así
// que acumular sin gastar no sirve de nada (ver Glory.grantTurnStart).
const GLORY_CAP = 30;

const Glory = {
  points: { player: 0, enemy: 0 },
  // Bonus ya "ganado" (bajas conseguidas) pero todavía sin sumar a points —
  // se vuelca entero en el próximo grantTurnStart de ESE equipo y se vacía.
  pendingBonus: { player: 0, enemy: 0 },
  _els: { player: null, enemy: null },
  _valueEls: { player: null, enemy: null },
  _previewEls: { player: null, enemy: null },

  // Se llama al empezar cada partida nueva (spawnTestUnits, ver
  // newgame-flow.js), justo después de Turns.reset() — recibe la raza de
  // cada equipo para poder pintar el icono correcto de cada uno.
  init(playerRaceId, enemyRaceId) {
    this.points = Teams.keyed(0);
    this.pendingBonus = Teams.keyed(0);
    this._raceIds = Object.assign({}, Teams.raceIds);
    // Solo el marcador del JUGADOR se pinta en pantalla (ver nota de
    // cabecera) — el del rival se lleva por dentro sin HUD propio.
    this._ensureHud("player", playerRaceId);
    this._els.player.style.display = "flex";
    this._render("player");
    this._renderPreview("player");
  },

  // Se llama desde js/settingsmenu.js al salir de la partida — mismo motivo
  // que Turns.hideButton() (ver ese archivo): el marcador vive fuera del
  // tablero y persiste entre partidas (se reutiliza el mismo elemento, ver
  // _ensureHud), así que hay que ocultarlo a mano al volver al menú en vez
  // de esperar a que se destruya solo con el resto del tablero.
  hideHud() {
    if (this._els.player) this._els.player.style.display = "none";
  },

  // Pedido explícito: "matar a 1 enemigo genera +1 punto de gloria al
  // comienzo del turno" — se llama desde Combat.attack en el momento exacto
  // en que se confirma la baja (target.hp <= 0), con el equipo de QUIEN
  // MATA (no de la víctima). No toca `points` todavía, solo la reserva que
  // grantTurnStart recogerá para ese equipo en su próximo turno — y refresca
  // el indicador discreto de "próximo turno" al momento, para que el
  // jugador vea reflejada la baja enseguida aunque los puntos de verdad
  // tarden hasta el inicio del turno en aparecer.
  queueKillBonus(team) {
    if (!(team in this.pendingBonus)) return;
    this.pendingBonus[team] += GLORY_PER_KILL;
    this._renderPreview(team);
  },

  // Gastar puntos — pedido explícito (js/shops.js, Tienda Goblin): "al
  // comprar un objeto, se descuentan los puntos de gloria". Primer (y de
  // momento único) sitio del juego que RESTA puntos en vez de sumarlos, así
  // que vive aparte de grantTurnStart en vez de reutilizarlo con un valor
  // negativo — ese método también dispara el "bump" visual/sonido de
  // recompensa de cada inicio de turno, que no pega aquí (gastar no es un
  // logro). Devuelve false sin tocar nada si no hay suficientes puntos —
  // quien llama a esto (Shops._buySelected) ya comprueba esto antes, pero
  // se repite aquí por seguridad, mismo patrón que Turns.canAct en el resto
  // del proyecto.
  spend(team, amount) {
    if (!(team in this.points) || amount <= 0) return false;
    if (this.points[team] < amount) return false;
    this.points[team] -= amount;
    this._render(team);
    return true;
  },

  // Lo llama Villages._capture (js/villages.js) justo al cambiar el dueño
  // de un poblado — el bonus persistente por poblado (ver _villagesBonus)
  // depende de Villages.ownedCount, que cambia en ese momento, así que el
  // indicador discreto de "próximo turno" debe refrescarse ahí mismo para
  // reflejarlo al instante, igual que queueKillBonus hace con las bajas.
  refreshPreview(team) {
    this._renderPreview(team);
  },

  // Pedido explícito: "+2 al comienzo de cada turno" (ahora +2, lo que se
  // haya acumulado en pendingBonus, y +1 por cada poblado neutral que
  // posea ese equipo — ver villagesBonus más abajo) — lo llama Turns.js en
  // cada cambio de equipo activo (incluida la primera vez que empieza el
  // jugador). `team` es "player" | "enemy".
  grantTurnStart(team) {
    if (!(team in this.points)) return;
    const gained = GLORY_PER_TURN_START + this.pendingBonus[team] + this._villagesBonus(team) + this._relicBonus(team);
    const room = Math.max(0, GLORY_CAP - this.points[team]);
    const added = Math.min(gained, room);
    const lost = gained - added;
    this.points[team] += added;
    this.pendingBonus[team] = 0;
    this._render(team, { bump: added > 0, gained: added });
    if (lost > 0) this._showLost(team, lost);
    this._renderPreview(team);
  },

  // Pedido explícito (js/villages.js, mecánica de poblados neutrales):
  // "tener un poblado otorga +1 punto de gloria persistentes a todos los
  // turnos" — y, si se conquistó de un golpe mortal en un solo golpe, +2 en
  // vez de +1 (ver Villages._playEpicSmash). Villages.gloryBonusFor ya suma
  // el bonus fijado en cada poblado que posea ese equipo (1 o 2 según cómo
  // se conquistó), así que basta con preguntárselo aquí en cada inicio de
  // turno en vez de llevar la cuenta por duplicado en este archivo (regla de
  // oro: un archivo por mecánica — Glory no sabe nada de cómo se conquista
  // un poblado, solo cuánto suma).
  // Gnomeda de la Suerte (js/relics.js): +2 de gloria por turno por cada moneda activa.
  _relicBonus(team) {
    return typeof Relics !== "undefined" ? Relics.gloryBonus(team) : 0;
  },

  _villagesBonus(team) {
    return typeof Villages !== "undefined" ? Villages.gloryBonusFor(team) : 0;
  },

  _raceFor(raceId) {
    const list = typeof RACES !== "undefined" ? RACES : [];
    return list.find((r) => r.id === raceId) || null;
  },

  // Pedido explícito (quinta pasada): "puedes poner el icono de puntos de
  // gloria directamente sin estar dentro de un circulo y la barra de la
  // derecha saliendo desde la mitad del icono por detras hacia la derecha
  // para integrarla" — fuera el medallón circular de antes: ahora el PNG
  // de la raza (RACES[].gloryIcon) se pinta suelto, sin fondo/borde propio,
  // y el banderín de número queda DETRÁS suyo en el z-index (ver
  // glory-hud__icon/__main en style.css), con un margen negativo para que
  // nazca justo a la mitad del icono y se lea como una sola pieza, no dos
  // pegadas.
  _ensureHud(team, raceId) {
    if (this._els[team]) return;
    const race = this._raceFor(raceId);

    const el = document.createElement("div");
    el.className = `glory-hud glory-hud--${team}`;
    if (!race || !race.gloryIcon) el.classList.add("glory-hud--no-icon");

    if (race && race.gloryIcon) {
      const icon = document.createElement("img");
      icon.decoding = "async"; // pedido de rendimiento: no bloquear el hilo principal decodificando
      icon.className = "glory-hud__icon";
      icon.src = race.gloryIcon;
      icon.alt = "";
      el.appendChild(icon);
    }

    const main = document.createElement("div");
    main.className = "glory-hud__main";

    const value = document.createElement("span");
    value.className = "glory-hud__value";
    value.textContent = "0";

    // Indicador discreto — pedido explícito: "debe haber algun indicador que
    // diga cuando puntos de gloria se generan por turno (algo mas
    // discreto)" — a diferencia de __value (el total actual, el que "hay
    // que destacar más"), este va pequeño y apagado, justo debajo.
    const preview = document.createElement("span");
    preview.className = "glory-hud__preview";
    preview.textContent = `+${GLORY_PER_TURN_START} / turno`;

    main.appendChild(value);
    main.appendChild(preview);

    el.appendChild(main);
    document.body.appendChild(el);

    this._els[team] = el;
    this._valueEls[team] = value;
    this._previewEls[team] = preview;

    // Pedido explícito: "si hago clic en la zona donde estan los puntos de
    // gloria aparecieses un popup...donde me indicase los puntos que estoy
    // consiguiendo por turno y sus origenes" — solo el marcador del
    // JUGADOR es interactivo (el del rival ni siquiera se pinta, ver nota
    // de cabecera), mismo patrón de overlay+panel que Backpack/UnitInfo
    // (ver openPopup más abajo).
    if (team === "player") {
      el.classList.add("glory-hud--clickable");
      el.setAttribute("role", "button");
      el.setAttribute("aria-label", "Ver el origen de tus puntos de gloria");
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        this.openPopup();
      });
    }
  },

  _render(team, { bump = false, gained = 0 } = {}) {
    const valueEl = this._valueEls[team];
    if (!valueEl) return;
    valueEl.innerHTML = `${this.points[team]}<small class="glory-hud__cap">/${GLORY_CAP}</small>`;
    const full = this.points[team] >= GLORY_CAP;
    if (this._els[team]) this._els[team].classList.toggle("glory-hud--full", full);
    if (this._previewEls[team]) this._renderPreview(team);
    if (bump) {
      const el = this._els[team];
      el.classList.remove("glory-hud--bump");
      void el.offsetWidth;
      el.classList.add("glory-hud--bump");
      // Sonido de recompensa — pedido explícito: "cuando alguna cosa genera
      // +X puntos de gloria... debe escucharse un sonido de recompensa".
      // Solo aquí (no en queueKillBonus): la baja en sí ya suena a golpe/
      // victoria con SFX.death(), este chime específico de gloria es para
      // el momento en que los puntos de verdad "entran en la cuenta".
      if (gained > 0 && typeof SFX !== "undefined") SFX.glory();
    }
  },

  // "-N perdidos": aviso rojo que sube junto al marcador cuando el turno
  // da más gloria de la que cabe (solo el marcador del jugador se pinta).
  _showLost(team, lost) {
    const hud = this._els[team];
    if (!hud || team !== "player") return;
    const r = hud.getBoundingClientRect();
    const e = document.createElement("div");
    e.className = "glory-lost";
    e.textContent = `-${lost} perdidos`;
    e.style.left = `${Math.round(r.left + r.width * 0.55)}px`;
    e.style.top = `${Math.round(r.bottom - 6)}px`;
    document.body.appendChild(e);
    setTimeout(() => e.remove(), 1700);
  },

  _renderPreview(team) {
    const previewEl = this._previewEls[team];
    if (!previewEl) return;
    const next = GLORY_PER_TURN_START + this.pendingBonus[team] + this._villagesBonus(team) + this._relicBonus(team);
    previewEl.textContent = this.points[team] >= GLORY_CAP ? "LLENO" : `+${next} / turno`;
  },

  // Una fila del desglose del popup: icono + etiqueta + valor con signo,
  // mismo espíritu que UnitInfo.statRow (js/unitinfo.js) — una función
  // compartida en vez de repetir el marcado por cada fuente de puntos.
  _sourceRow(icon, label, amount, { muted = false } = {}) {
    const sign = amount > 0 ? "+" : "";
    return `
      <div class="glory-popup-row${muted ? " glory-popup-row--muted" : ""}">
        <i class="ph-fill ${icon} glory-popup-row__icon"></i>
        <span class="glory-popup-row__label">${label}</span>
        <span class="glory-popup-row__amount">${sign}${amount}</span>
      </div>`;
  },

  // Pedido explícito: "un popup (con el mismo estilo visual que el resto de
  // interfaces del juego) donde me indicase los puntos que estoy
  // consiguiendo por turno y sus origenes. todo bien especificado" — mismo
  // patrón overlay+panel que Backpack.openPopup/UnitInfo.openPopup (clic
  // fuera o botón de cerrar para cerrar, .p5-banner para el marco). Solo
  // existe para "player" (ver _ensureHud), así que no hace falta parámetro
  // de equipo.
  openPopup() {
    if (this.overlayEl) return;
    const team = "player";
    SFX.click();

    const villages = typeof Villages !== "undefined" ? Villages.ownedCount(team) : 0;
    const villagesBonus = this._villagesBonus(team);
    const killBonus = this.pendingBonus[team];
    const relicBonus = this._relicBonus(team);
    const nextTotal = GLORY_PER_TURN_START + killBonus + villagesBonus + relicBonus;

    const hudImg = this._els[team] && this._els[team].querySelector(".glory-hud__icon");
    const iconSrc = hudImg ? hudImg.getAttribute("src") : "";
    const overlay = document.createElement("div");
    overlay.className = "glory-popup-overlay";
    overlay.addEventListener("click", () => this.closePopup());

    overlay.innerHTML = `
      <div class="p5-banner glory-popup-card">
        <div class="glory-popup-card__content">
          <button class="backpack-close-btn" aria-label="Cerrar">
            <i class="ph ph-x backpack-close-btn__icon"></i>
          </button>
          <h2 class="glory-popup-title">Puntos de Gloria</h2>
          <div class="glory-popup-total">
            ${iconSrc ? `<img class="glory-popup-total__img" src="${iconSrc}" alt="">` : `<i class="ph-fill ph-trophy"></i>`}
            <span>${this.points[team]}<small class="glory-hud__cap">/${GLORY_CAP}</small></span>
          </div>
          <p class="glory-popup-subtitle">${this.points[team] >= GLORY_CAP ? "Tu gloria está llena: lo que ganes ahora se pierde. ¡Gástala!" : "Vas a ganar esto al empezar tu próximo turno:"}</p>
          <div class="glory-popup-sources">
            ${this._sourceRow("ph-sparkle", "Base de cada turno", GLORY_PER_TURN_START)}
            ${this._sourceRow(
              "ph-skull",
              killBonus > 0 ? "Bajas conseguidas este turno" : "Sin bajas conseguidas este turno",
              killBonus,
              { muted: killBonus === 0 }
            )}
            ${this._sourceRow(
              "ph-house-simple",
              // Pedido explícito: "indica 'sin poblados conquistados'...poblados?
              // son Totems!" — Villages.js sigue llamándose así por dentro (el
              // nombre del archivo/mecánica no ha cambiado), pero el propio
              // juego ya no usa la palabra "poblado" en ningún otro texto
              // visible, todo dice "tótem" (ver races.js, backpack.js...).
              villages > 0 ? `Tótems conquistados (${villages})` : "Sin tótems conquistados",
              villagesBonus,
              { muted: villagesBonus === 0 }
            )}
            ${relicBonus > 0 ? this._sourceRow("ph-coin", "Gnomeda de la Suerte", relicBonus) : ""}
          </div>
          <div class="glory-popup-row glory-popup-row--next">
            <span class="glory-popup-row__label">Próximo turno</span>
            <span class="glory-popup-row__amount">+${nextTotal}</span>
          </div>
        </div>
      </div>`;

    overlay.querySelector(".glory-popup-card").addEventListener("click", (e) => e.stopPropagation());
    overlay.querySelector(".backpack-close-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      this.closePopup();
    });

    document.body.appendChild(overlay);
    this.overlayEl = overlay;
    requestAnimationFrame(() => overlay.classList.add("glory-popup-overlay--visible"));
  },

  closePopup() {
    if (!this.overlayEl) return;
    const el = this.overlayEl;
    this.overlayEl = null;
    SFX.back();
    el.classList.remove("glory-popup-overlay--visible");
    setTimeout(() => el.remove(), 220);
  },
};
