/* Gnomore Gnomes — turnos por equipo.
   Regla de oro: un archivo por mecánica. Este archivo NO sabe cómo se mueve,
   se ataca, se coge o se pasa el gnomo — eso sigue viviendo tal cual en
   js/movement.js, js/combat.js y js/gnome.js. Lo único que sabe es:
     - A quién le toca ahora mismo (Turns.activeTeam).
     - Cuántas acciones lleva gastadas cada unidad esta ronda suya
       (Turns.actionsUsed) y si todavía puede actuar (Turns.canAct).
   Cada mecánica llama a Turns.canAct(unit) antes de ofrecer sus marcadores
   (ver el gate al principio de showFor en movement.js/combat.js/gnome.js) y
   a Turns.useAction(unit) justo cuando la acción se confirma de verdad
   (Movement.moveTo, Combat.attack, GnomeInstance.hit/executePass/catchBy) —
   así este archivo no necesita saber CUÁNDO ocurre cada una, solo que se lo
   avisen.

   Pedido explícito: "cada personaje tiene 2 acciones, las acciones son...
   moverse una vez, pegar una vez a un enemigo, pegar al gnomo una vez, pasar
   el gnomo una vez o usar una habilidad una vez cuando las haya, una vez un
   personaje haya usado 2 acciones... perderá un poco de saturación para
   indicar que está inactivo (un jugador inactivo puede recibir un pase)...
   el jugador deberá pulsar el botón PASAR TURNO... entonces será el turno de
   mover del jugador enemigo... el ordenador simulará el turno del enemigo
   moviendo a los personajes, cogiendo gnomos... con el tiempo definiremos
   una IA más compleja." — la IA de aquí es deliberadamente simple (ver
   _runEnemyTurn/_aiActOnce más abajo), a la espera de esa IA más completa
   futura que el propio pedido ya anticipa. */

const TURNS_MAX_ACTIONS = 2;

// Pedido explícito: "de momento habran un maximo de 30 turnos por partida".
// Un "turno" aquí es una RONDA COMPLETA (jugador + rival, un único pulso del
// botón PASAR TURNO) — mismo criterio que ya usa registerTurnEndListener/
// onRoundEnd (ver su comentario más abajo), así el contador que se muestra
// sobre el botón cuenta lo mismo que ya cuentan los oyentes existentes.
const TURNS_MAX_ROUNDS = 30;

// Pedido explícito: "de momento para hacer pruebas, que los enemigos no
// ataquen estamos en modo sandbox" — la IA rival (_aiActOnce más abajo)
// sigue moviéndose y cogiendo/golpeando/pasando gnomos con total normalidad,
// solo se le desactiva la prioridad de ATACAR a los personajes del jugador.
// Poner a false el día que se quiera que el rival ataque de verdad.
const TURNS_SANDBOX_NO_ENEMY_ATTACK = true;

const Turns = {
  activeTeam: "player", // "player" | "enemy"
  actionsUsed: {}, // unitId -> nº de acciones gastadas en SU turno actual
  _btn: null,
  _btnLabelEl: null,
  _aiRunning: false,
  _turnEndListeners: [],

  // Igual que Units.registerSelectionListener pero para cualquier mecánica
  // que necesite contar RONDAS COMPLETAS (jugador + rival, un único pulso
  // del botón de pasar turno) sin tener que reimplementar ese conteo por su
  // cuenta — ver js/backpack.js (cuenta atrás de la Setarcoiris). Se avisa
  // al final de endTurn(), cuando ya ha vuelto a ser el turno del jugador.
  registerTurnEndListener(listener) {
    this._turnEndListeners.push(listener);
  },

  // Igual que registerTurnEndListener pero para el INICIO de CADA turno
  // individual (el del jugador Y el del rival, no solo una vez por ronda
  // completa) — lo usa js/shops.js para la reposición de existencias cada
  // 5 turnos ("se avisara con un mensaje en pantalla al empezar el turno").
  // Se llama con el equipo (team) al que le toca justo ahora: una vez en
  // reset() (el primer turno de la partida, del jugador) y dos veces por
  // cada vuelta de endTurn() (al pasar al rival y al volver al jugador).
  _turnStartListeners: [],
  registerTurnStartListener(listener) {
    this._turnStartListeners.push(listener);
  },
  _fireTurnStart(team) {
    this._turnStartListeners.forEach((l) => l.onTurnStart && l.onTurnStart(team));
  },

  // Se llama al empezar cada partida nueva (spawnTestUnits, ver
  // newgame-flow.js), DESPUÉS de crear todos los personajes y gnomos —
  // deja limpio el contador, siempre empieza el jugador, y (re)crea/muestra
  // el botón de PASAR TURNO.
  reset() {
    this.activeTeam = "player";
    this.actionsUsed = {};
    this._aiRunning = false;
    // "de momento habran un maximo de 30 turnos por partida" — empieza en
    // el turno 1, sube una vez por cada ronda completa (ver endTurn).
    this.roundNumber = 1;
    // Habilidades especiales (js/abilities.js) — partida nueva, quita
    // cualquier mina/apuntado/control mental que hubiera quedado de una
    // partida anterior.
    if (typeof Abilities !== "undefined") Abilities.resetAll();
    Units.list.forEach((u) => this._applyExhaustedClass(u));
    this._ensureButton();
    this._updateButtonState();
    // Puntos de Gloria (js/glory.js) — pedido explícito: "al comienzo de
    // cada turno se generan automaticamente 2 puntos de gloria", y el
    // primer turno de la partida (el del jugador) no es una excepción.
    if (typeof Glory !== "undefined") Glory.grantTurnStart("player");
    this._fireTurnStart("player");
  },

  // true si `unit` puede gastar todavía alguna de sus 2 acciones ESTE turno
  // — falso tanto si ya las gastó como si no es el turno de su equipo. Toda
  // mecánica (Movement/Combat/Gnome) comprueba esto antes de ofrecer nada.
  canAct(unit) {
    if (!unit || !unit.el) return false;
    if (unit.team !== this.activeTeam) return false;
    return (this.actionsUsed[unit.id] || 0) < TURNS_MAX_ACTIONS;
  },

  // Descuenta una acción de `unit` — lo llama cada mecánica justo cuando la
  // acción se confirma de verdad (ver cabecera del archivo). Si con esto
  // llega a las 2 y esa unidad es la seleccionada ahora mismo, se
  // deselecciona sola para que sus marcadores/botones desaparezcan sin que
  // cada mecánica tenga que acordarse de ocultarlos a mano.
  useAction(unit) {
    this.actionsUsed[unit.id] = (this.actionsUsed[unit.id] || 0) + 1;
    this._applyExhaustedClass(unit);
    if (Units.selectedId === unit.id && !this.canAct(unit)) {
      Units.deselect();
    }
    // Pedido explícito: "cuando todos los personajes se hayan movido estaría
    // bien que palpitase para avisar visualmente al jugador" — se comprueba
    // después de CADA acción (no solo al cambiar de turno) para que el botón
    // se ponga a palpitar en el instante exacto en que la ÚLTIMA unidad del
    // jugador se queda sin acciones, no un paso más tarde.
    this._updateButtonState();
  },

  // Saturación reducida (pedido explícito) en cuanto una unidad agota sus 2
  // acciones — puramente visual, "un jugador inactivo puede recibir un
  // pase" así que no bloquea ningún clic aquí, solo lo hacen canAct/showFor.
  _applyExhaustedClass(unit) {
    if (!unit.el) return;
    const exhausted = (this.actionsUsed[unit.id] || 0) >= TURNS_MAX_ACTIONS;
    unit.el.classList.toggle("unit--exhausted", exhausted);
    // Indicador de acciones restantes (js/unitinfo.js) — se llama desde
    // AQUÍ (no desde useAction directamente) porque este método ya es el
    // único punto de paso de todos los sitios que tocan actionsUsed
    // (useAction, refreshExhaustedClass, _resetTeamActions y reset(), ver
    // cabecera del archivo), así el indicador se mantiene al día sin
    // duplicar el aviso en cada uno. Solo repinta si `unit` es la que está
    // seleccionada ahora mismo (refreshActionDots ya hace esa comprobación).
    if (typeof UnitInfo !== "undefined") UnitInfo.refreshActionDots();
    // Botón de habilidad especial (js/abilities.js) — mismo motivo que
    // UnitInfo arriba: aparece/desaparece según si la unidad SELECCIONADA
    // ahora mismo todavía puede actuar, así que se avisa desde este único
    // punto de paso en vez de repetirlo en cada sitio que toca actionsUsed.
    if (typeof Abilities !== "undefined") Abilities.refresh();
  },

  // Versión pública de lo de arriba — para archivos que a propósito
  // suprimieron el aviso visual un rato (ver Villages._playEpicSmash: "el
  // personaje no debe tener los colores de inactivo hasta que se haya
  // capturado el propio totem") y necesitan volver a ponerlo al día sin
  // tocar el conteo real de acciones (ese ya se actualizó al llamar a
  // useAction en su momento, esto solo repinta el classList).
  refreshExhaustedClass(unit) {
    this._applyExhaustedClass(unit);
  },

  // Vacía a 0 las acciones gastadas de TODAS las unidades de `team` y les
  // quita la saturación — se llama al EMPEZAR el turno de ese equipo (nunca
  // al terminarlo), así el otro equipo se queda viendo cómo de "gastadas"
  // dejaron a sus unidades hasta que vuelva a tocarles.
  _resetTeamActions(team) {
    Units.list
      .filter((u) => u.team === team)
      .forEach((u) => {
        // "Nudillos Rocosos" (PuñoRoca) y la trampa de TruenoEspora
        // (js/abilities.js) dejan a su víctima agotada DESDE EL PRINCIPIO
        // de su turno siguiente, en vez de con las 2 acciones normales de
        // cualquier otro turno — se consume aquí, una sola vez.
        if (u.forcedRestNextTurn) {
          u.forcedRestNextTurn = false;
          this.actionsUsed[u.id] = TURNS_MAX_ACTIONS;
        } else {
          this.actionsUsed[u.id] = 0;
        }
        this._applyExhaustedClass(u);
      });
  },

  // ---------- Botón "PASAR TURNO" ----------
  // Mismo patrón que UnitInfo/Gnome (botón fijo, position:fixed, añadido a
  // document.body una sola vez) — pero SIEMPRE visible durante la partida
  // (no ligado a ninguna selección): esquina inferior derecha, pedido
  // explícito.

  _ensureButton() {
    if (this._btn) return;
    const btn = document.createElement("button");
    btn.className = "end-turn-btn";
    btn.setAttribute("aria-label", "Pasar turno");
    // Capa de fondo aparte (ver style.css) — el recorte en banderín del
    // botón vive AQUÍ, no en el <button> en sí, para que el rombo del
    // icono (hermano suyo, no hijo) pueda salirse fuera de la caja de
    // texto sin que ese mismo clip-path le coma la punta. "Pasar turno" es
    // el texto de este span, no del botón entero.
    const bg = document.createElement("span");
    bg.className = "end-turn-btn__bg";
    // Pedido explícito: "arriba del texto PASAR TURNO del boton, debe
    // indicarse en que turno estamos...X/30" — una línea pequeña encima del
    // texto de siempre, dentro de la misma capa recortada (.end-turn-btn__bg)
    // para que se mueva/anime siempre junto con el resto del botón.
    const turnCounter = document.createElement("span");
    turnCounter.className = "end-turn-btn__turn-counter";
    bg.appendChild(turnCounter);
    this._turnCounterEl = turnCounter;
    // Pedido explícito: "aplica esa correccion [contorno de doble capa] a
    // TODOS LOS BOTONES...ya que tenian ese mismo defecto" — el rombo
    // (end-turn-btn__icon) pasa a ser un contenedor ESTABLE que nunca se
    // sustituye (lleva la silueta + el contorno de doble capa, ver
    // style.css), y el glifo en sí vive en su PROPIO <i> hijo
    // (end-turn-btn__icon-glyph) que SÍ se sustituye en cada cambio de
    // estado (ver _setIcon) — antes el icono ERA el rombo directamente,
    // pero el webfont de Phosphor pinta el glifo con el ::before de ese
    // mismo elemento, y el contorno de doble capa TAMBIÉN necesita su
    // propio ::before/::after libres, así que ya no pueden compartir un
    // único elemento.
    const iconWrap = document.createElement("span");
    iconWrap.className = "end-turn-btn__icon";
    const icon = document.createElement("i");
    icon.className = "ph ph-flag-checkered end-turn-btn__icon-glyph";
    iconWrap.appendChild(icon);
    const label = document.createElement("span");
    label.className = "end-turn-btn__label";
    bg.appendChild(label);
    btn.appendChild(bg);
    btn.appendChild(iconWrap);
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.endTurn();
    });
    document.body.appendChild(btn);
    this._btn = btn;
    this._btnLabelEl = label;
    this._btnIconEl = icon;
    this._btnIconWrapEl = iconWrap;
  },

  // Pedido explícito: "creo que el icono phosphor de pasar turno esta
  // duplicado...compruebalo y arreglalo" — investigado a fondo: el paquete
  // @phosphor-icons/web (el que carga index.html por CDN) es solo CSS puro,
  // un webfont con el glifo pintado vía ::before{content:...} — no inyecta
  // ni duplica ningún SVG por JS, así que no hay ningún proceso que pueda
  // "apilar" iconos por cambiar el className varias veces (se comprobó
  // bajando el paquete e inspeccionando su código fuente). La causa real es
  // visual, no un bug de DOM: el reloj de arena (que de por sí tiene una
  // silueta de "lazo"/doble triángulo) vive MUY pegado a los bordes de su
  // propia caja, que también es un rombo — dos formas de diamante casi
  // superpuestas a esa escala se leen como si hubiera un icono repetido.
  // Arreglo de verdad: más margen entre el glifo y el borde de la caja +
  // caja más grande (ver .end-turn-btn__icon en style.css) para que se
  // distingan como una sola pieza clara, no dos. Este método sigue siendo
  // la forma correcta y más robusta de cambiar el icono desde JS (crea un
  // <i> limpio en vez de mutar uno ya existente), así que se queda aunque
  // no fuera la causa del "duplicado".
  // `className` llega como "ph ph-xxx end-turn-btn__icon" desde las tres
  // llamadas de abajo (se queda así por no tocar esas tres líneas) — pero
  // desde que el rombo (end-turn-btn__icon) es un contenedor ESTABLE
  // aparte (ver _ensureButton), aquí solo hace falta la clase del GLIFO en
  // sí (end-turn-btn__icon-glyph), nunca la del rombo.
  _setIcon(className) {
    const glyphClassName = className.replace(
      "end-turn-btn__icon",
      "end-turn-btn__icon-glyph"
    );
    if (this._btnIconEl && this._btnIconEl.className === glyphClassName) return;
    const icon = document.createElement("i");
    icon.className = glyphClassName;
    if (this._btnIconEl && this._btnIconEl.parentNode) {
      this._btnIconEl.replaceWith(icon);
    } else if (this._btnIconWrapEl) {
      this._btnIconWrapEl.appendChild(icon);
    }
    this._btnIconEl = icon;
    // El giro al pasar el ratón (end-turn-hourglass-spin, ver style.css)
    // solo debe pasar con el reloj de arena — antes se seleccionaba con
    // ".end-turn-btn__icon.ph-hourglass-simple" porque ambas clases vivían
    // en el mismo elemento; ahora viven en elementos distintos, así que se
    // marca aparte en el rombo (el que de verdad gira).
    if (this._btnIconWrapEl) {
      this._btnIconWrapEl.classList.toggle(
        "end-turn-btn__icon--hourglass",
        glyphClassName.includes("ph-hourglass-simple")
      );
    }
  },

  // Se llama desde js/settingsmenu.js al salir de la partida (opción "Salir
  // de la partida" del popup de ajustes, ver ese archivo) — antes esto lo
  // hacía un listener propio sobre el back-btn del tablero, pero ese botón
  // ya no existe (lo tapaba el marcador de Puntos de Gloria, pedido
  // explícito: lo sustituye el icono de ajustes de la esquina superior
  // derecha). Mismo efecto de siempre: el botón deja de estar visible hasta
  // que la próxima partida lo vuelva a mostrar (Turns.reset -> _updateButtonState).
  hideButton() {
    if (this._btn) this._btn.classList.remove("end-turn-btn--visible");
  },

  // true si NINGUNA unidad del jugador puede ya actuar este turno (las 2
  // acciones de todas gastadas) — lo usa _updateButtonState para decidir
  // cuándo palpitar (pedido explícito, ver más abajo). false si el equipo
  // del jugador está vacío (no hay nada que avisar).
  _allPlayerUnitsExhausted() {
    const playerUnits = Units.list.filter((u) => u.team === "player");
    if (playerUnits.length === 0) return false;
    return playerUnits.every((u) => !this.canAct(u));
  },

  _updateButtonState() {
    if (!this._btn) return;
    this._btn.classList.add("end-turn-btn--visible");
    if (this._turnCounterEl) this._turnCounterEl.textContent = `Turno ${this.roundNumber} / ${TURNS_MAX_ROUNDS}`;
    const isPlayerTurn = this.activeTeam === "player" && !this._aiRunning;
    this._btn.disabled = !isPlayerTurn;
    this._btn.classList.toggle("end-turn-btn--thinking", !isPlayerTurn);

    // Pedido explícito: "cuando todos los personajes se hayan movido estaría
    // bien que palpitase para avisar visualmente al jugador" — solo mientras
    // es su turno de verdad (nunca durante el turno rival, aunque
    // técnicamente ya estén todos "agotados" de la ronda anterior).
    const ready = isPlayerTurn && this._allPlayerUnitsExhausted();
    this._btn.classList.toggle("end-turn-btn--ready", ready);

    if (!isPlayerTurn) {
      this._btnLabelEl.textContent = "Turno rival…";
      this._setIcon("ph ph-circle-notch end-turn-btn__icon");
    } else if (ready) {
      this._btnLabelEl.textContent = "¡Todos listos!";
      this._setIcon("ph ph-check-circle end-turn-btn__icon");
    } else {
      this._btnLabelEl.textContent = "Pasar turno";
      this._setIcon("ph ph-hourglass-simple end-turn-btn__icon");
    }
  },

  // ---------- Cambio de turno ----------

  async endTurn() {
    if (this._aiRunning || this.activeTeam !== "player") return;
    // Fin de partida por límite de turnos (ver Obelisks.checkTurnLimit,
    // js/obelisks.js) — ya se decidió un ganador, no se procesa ningún
    // turno más.
    if (typeof Obelisks !== "undefined" && Obelisks.gameOver) return;
    Units.deselect();
    // Habilidad "Voluntad Quebrada" (UrgaMentes, js/abilities.js) —
    // "toma el control...durante el resto de este turno": el control
    // termina aquí, al pasar turno, tanto si se llegaron a gastar sus 2
    // acciones como si no (vuelve a su equipo, agotada, para que la IA
    // rival no la use este mismo round).
    if (typeof Abilities !== "undefined") Abilities.releaseMindControl();
    // Pedido explícito: "los gnomos que están sueltos... pierden 5 puntos
    // cada vez que alguien pulsa el botón PASAR TURNO" — CADA pulsación
    // cuenta, así que se llama aquí (la del jugador) Y otra vez más abajo,
    // cuando el ordenador "pulsa" el suyo automáticamente al terminar su
    // turno — dos veces por ronda completa, no una.
    if (typeof Gnome !== "undefined") Gnome.applyTurnPassDecay();
    this.activeTeam = "enemy";
    this._resetTeamActions("enemy");
    this._aiRunning = true;
    this._updateButtonState();
    // Puntos de Gloria (js/glory.js) — +2 al empezar el turno del rival
    // también: el marcador en pantalla es solo el del jugador (ver nota de
    // cabecera de glory.js), pero el rival igualmente acumula los suyos por
    // dentro para cuando su IA los pueda gastar más adelante.
    if (typeof Glory !== "undefined") Glory.grantTurnStart("enemy");
    this._fireTurnStart("enemy");

    await this._runEnemyTurn();

    if (typeof Gnome !== "undefined") Gnome.applyTurnPassDecay();
    this._aiRunning = false;
    this.activeTeam = "player";
    this._resetTeamActions("player");
    // "de momento habran un maximo de 30 turnos por partida" — una ronda
    // completa (jugador + rival) acaba de terminar, así que sube aquí,
    // ANTES de repintar el botón (para que ya muestre el número nuevo) y
    // antes de comprobar si toca acabar la partida.
    this.roundNumber++;
    this._updateButtonState();
    if (typeof Glory !== "undefined") Glory.grantTurnStart("player");
    this._fireTurnStart("player");
    // "una vez por ronda completa" (ver registerTurnEndListener arriba) —
    // aquí, justo al terminar, no en ningún punto intermedio de la IA.
    this._turnEndListeners.forEach((l) => l.onRoundEnd && l.onRoundEnd());
    if (typeof Obelisks !== "undefined" && typeof Obelisks.checkTurnLimit === "function") {
      Obelisks.checkTurnLimit(this.roundNumber);
    }
  },

  // ---------- IA del bando rival ----------
  // Deliberadamente simple (pedido explícito: "con el tiempo definiremos una
  // IA más compleja") — recorre a cada rival y, mientras le queden acciones,
  // hace lo más "razonable" disponible en este orden de prioridad:
  //   1. Si lleva el gnomo cogido: pasarlo a un aliado cercano (arriesgado
  //      pero da más puntos) o si no golpearlo para sumar puntos.
  //   2. Si puede atacar a algún personaje del jugador: atacarlo.
  //   3. Si hay un gnomo suelto a su alcance: cogerlo.
  //   4. Si no: acercarse al objetivo más interesante que tenga a la vista
  //      (un gnomo suelto o, si no, el personaje del jugador más cercano).
  // Si ninguna de las 4 aplica, esa unidad no hace nada más este turno (no
  // malgasta sus acciones moviéndose sin rumbo).
  async _runEnemyTurn() {
    const enemies = Units.list.filter((u) => u.team === "enemy");
    for (const unit of enemies) {
      for (let i = 0; i < TURNS_MAX_ACTIONS; i++) {
        if (!this.canAct(unit)) break;
        const acted = await this._aiActOnce(unit);
        if (!acted) break;
        // Pequeña pausa entre acciones para que el jugador pueda seguir lo
        // que hace cada rival, en vez de que las 2 acciones de cada uno se
        // resuelvan instantáneamente una detrás de otra.
        await new Promise((resolve) => setTimeout(resolve, 260));
      }
    }
  },

  // Ejecuta UNA acción para `unit` según la prioridad de arriba. Devuelve
  // true si de verdad hizo algo (y por tanto gastó una acción — ya la habrá
  // descontado la propia mecánica llamada, ver cabecera del archivo) o false
  // si no había nada razonable que hacer (para que _runEnemyTurn no siga
  // intentando en vano con la acción que le quedara).
  async _aiActOnce(unit) {
    if (!unit.el) return false; // pudo morir a mitad del propio turno rival

    if (typeof Gnome !== "undefined") {
      const held = Gnome.list.find((g) => g.heldBy === unit.id);
      if (held) {
        // "ahora el equipo enemigo tambien intenta capturar los totems"
        // (pedido explícito) — con el gnomo ya en la mano, un tótem que no
        // sea suyo pesa MÁS que pasar/golpear al gnomo de siempre (dan
        // gloria persistente CADA turno, no solo puntos sueltos), así que
        // esta comprobación va primero: atacar si ya está al alcance, o si
        // no acercarse un poco (la IA sigue intentándolo turno a turno en
        // vez de rendirse a la primera).
        if (typeof Villages !== "undefined") {
          const inRange = Villages.attackableBy(unit);
          if (inRange) {
            await Villages.attack(unit, inRange);
            return true;
          }
          const nearest = Villages.nearestUnowned(unit);
          if (nearest) {
            const dest = this._aiPickMoveTileToward(unit, nearest);
            if (dest) {
              await Movement.moveTo(unit, dest.row, dest.col);
              return true;
            }
          }
        }
        const ally = Units.list.find(
          (u) =>
            u.team === "enemy" &&
            u.id !== unit.id &&
            Math.max(Math.abs(u.row - unit.row), Math.abs(u.col - unit.col)) <=
              UNIT_TYPES[unit.typeId].movimiento + 2
        );
        if (ally && Math.random() < 0.5) {
          await held.executePass(unit, ally);
        } else {
          held.hit(unit);
        }
        return true;
      }
    }

    if (!TURNS_SANDBOX_NO_ENEMY_ATTACK && typeof Combat !== "undefined") {
      const targets = Combat.attackableEnemies(unit);
      if (targets.length > 0) {
        await Combat.approachAndAttack(unit, targets[0].target);
        return true;
      }
    }

    if (typeof Gnome !== "undefined") {
      const looseGnome = Gnome.list.find((g) => !g.heldBy && g.findApproachTile(unit));
      if (looseGnome) {
        await looseGnome.catchBy(unit);
        return true;
      }
    }

    const dest = this._aiPickMoveTile(unit);
    if (dest) {
      await Movement.moveTo(unit, dest.row, dest.col);
      return true;
    }

    return false;
  },

  // Elige la loseta alcanzable (dentro del propio movimiento) que más
  // acerque a `unit` a su objetivo más interesante — un gnomo suelto si hay
  // alguno, o si no el personaje del jugador más cercano. Reutiliza
  // Movement.reachableTiles (mismo cálculo que ya usa el jugador) en vez de
  // duplicar la comprobación de casillas ocupadas/con niebla.
  _aiPickMoveTile(unit) {
    let target = null;
    if (typeof Gnome !== "undefined" && Gnome.list.some((g) => !g.heldBy)) {
      target = Gnome.list
        .filter((g) => !g.heldBy)
        .reduce((best, g) => {
          const d = Math.max(Math.abs(g.row - unit.row), Math.abs(g.col - unit.col));
          return !best || d < best.d ? { row: g.row, col: g.col, d } : best;
        }, null);
    }
    if (!target) {
      target = Units.list
        .filter((u) => u.team === "player")
        .reduce((best, u) => {
          const d = Math.max(Math.abs(u.row - unit.row), Math.abs(u.col - unit.col));
          return !best || d < best.d ? { row: u.row, col: u.col, d } : best;
        }, null);
    }
    return this._aiPickMoveTileToward(unit, target);
  },

  // Misma elección de "la loseta alcanzable que más acerca a `unit` a
  // `target` (fila/columna)" de arriba, pero ya separada del cálculo de
  // CUÁL es el objetivo — así _aiPickMoveTile (gnomos sueltos / rival más
  // cercano) y la aproximación a un tótem (ver _aiActOnce) comparten el
  // mismo criterio de acercamiento sin duplicar el bucle.
  _aiPickMoveTileToward(unit, target) {
    if (typeof Movement === "undefined" || !target) return null;
    const tiles = Movement.reachableTiles(unit);
    if (tiles.length === 0) return null;

    let best = null;
    let bestDist = Infinity;
    tiles.forEach((t) => {
      const d = Math.max(Math.abs(t.row - target.row), Math.abs(t.col - target.col));
      if (d < bestDist) {
        bestDist = d;
        best = t;
      }
    });
    // Si ya está tan cerca como puede llegar a estar (ninguna loseta
    // alcanzable mejora la distancia actual), no malgasta la acción
    // moviéndose sin necesidad.
    const currentDist = Math.max(Math.abs(unit.row - target.row), Math.abs(unit.col - target.col));
    if (best && bestDist >= currentDist) return null;
    return best;
  },
};
